<!-- katalyst-skills:start -->
## Katalyst design system

Before building, changing or reviewing any user interface, read and follow these guides from
`@kalvi-education/katalyst` (installed under `node_modules/@kalvi-education/katalyst/skills/`):

- `katalyst-design.md` — Use when designing, building, restyling or translating a design into user interface for Kalvium products. Covers how to compose screens from Katalyst components and which colour, spacing, shape, type and layout rules to follow.
- `katalyst-components.md` — Use when choosing, importing or composing Katalyst components, including picking between similar components, wiring forms, overlays, feedback, data views and navigation, meeting each component's accessibility obligations, and the behaviour and wording around them: forms and feedback, navigation, data-view states and UI copy.
- `katalyst-product-pages.md` — Use when building a read-heavy product page for Kalvium (a student showcase, public profile, portfolio, report or dossier) that should look crafted rather than bare, a sign-off flow where someone reads a document and proves who they are (agreement, consent, policy), or an app launcher home inside the AppShell rail. Gives the page anatomy, the tray and card layering, the one colour language, the document-and-checklist modal, the launcher, and how to work from a design the person supplies, with copy-ready code.
- `katalyst-review.md` — Use when reviewing, auditing or checking a user interface or a pull request that changes UI, to find violations of the Katalyst design system and report them in a consistent format.
- `katalyst-figma.md` — Use when reading a Figma design to implement it, or when mapping Figma tokens, styles, components and icons to Katalyst code. Covers how to read frames, how Figma variables map to Katalyst tokens, and what to do when a design's bindings are wrong or missing.

Start with `AGENTS.md` in that folder. Build every element from Katalyst components, style only
with Katalyst tokens, and report a gap instead of improvising.
<!-- katalyst-skills:end -->
