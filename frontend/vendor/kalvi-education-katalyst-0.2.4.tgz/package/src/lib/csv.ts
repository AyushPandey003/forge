// CSV helpers shared by CsvUpload and DataTable. No dependencies; safe to import from server code.

export type CsvRow = Record<string, string>

export type CsvColumn = {
  /** The header the file must carry, matched exactly after trimming. */
  name: string
  required?: boolean
  /** One line shown in the template and the column list. */
  description?: string
  /** A realistic value for the downloadable template. */
  example?: string
}

export type CsvRowValidator = (row: CsvRow, index: number, rows: CsvRow[]) => string | null | undefined

export type CsvValidation = {
  valid: boolean
  /** File-level problem, such as an empty file. */
  error?: string
  missingColumns: string[]
  /** Headers in the file that the config does not list. They are kept, not rejected. */
  extraColumns: string[]
  /** One message per bad row, numbered as they appear in a spreadsheet (header is row 1). */
  rowErrors: string[]
}

/**
 * Parses CSV text (RFC 4180): quoted fields, doubled quotes, commas and newlines inside quotes, CRLF or LF,
 * and a leading byte-order mark. The first record is the header. Blank lines are skipped.
 */
export function parseCsv(text: string): CsvRow[] {
  const source = text.replace(/^﻿/, "")
  const records: string[][] = []
  let field = ""
  let record: string[] = []
  let quoted = false

  for (let i = 0; i < source.length; i++) {
    const char = source[i]
    if (quoted) {
      if (char === '"') {
        if (source[i + 1] === '"') {
          field += '"'
          i++
        } else quoted = false
      } else field += char
    } else if (char === '"' && field === "") {
      quoted = true
    } else if (char === ",") {
      record.push(field)
      field = ""
    } else if (char === "\n" || char === "\r") {
      if (char === "\r" && source[i + 1] === "\n") i++
      record.push(field)
      field = ""
      if (record.some((value) => value.trim() !== "")) records.push(record)
      record = []
    } else field += char
  }
  if (quoted) throw new Error("A quoted value is never closed.")
  record.push(field)
  if (record.some((value) => value.trim() !== "")) records.push(record)

  const [header, ...body] = records
  if (!header) return []
  const names = header.map((name) => name.trim())
  return body.map((values) =>
    Object.fromEntries(names.map((name, index) => [name, (values[index] ?? "").trim()]))
  )
}

/** Checks parsed rows against the expected columns and any per-row rules. */
export function validateCsv(
  rows: CsvRow[],
  columns: CsvColumn[],
  rules: CsvRowValidator[] = []
): CsvValidation {
  if (rows.length === 0) {
    return {
      valid: false,
      error: "The file has no data rows.",
      missingColumns: columns.filter((c) => c.required).map((c) => c.name),
      extraColumns: [],
      rowErrors: [],
    }
  }
  const headers = Object.keys(rows[0]!)
  const missingColumns = columns.filter((c) => c.required && !headers.includes(c.name)).map((c) => c.name)
  const known = new Set(columns.map((c) => c.name))
  const extraColumns = headers.filter((h) => !known.has(h))

  const rowErrors: string[] = []
  if (missingColumns.length === 0) {
    rows.forEach((row, index) => {
      for (const column of columns) {
        if (column.required && !row[column.name]) {
          rowErrors.push(`Row ${index + 2}: ${column.name} is empty.`)
        }
      }
      for (const rule of rules) {
        const message = rule(row, index, rows)
        if (message) rowErrors.push(`Row ${index + 2}: ${message}`)
      }
    })
  }

  return {
    valid: missingColumns.length === 0 && rowErrors.length === 0,
    missingColumns,
    extraColumns,
    rowErrors,
  }
}

/** Quotes a value when it holds a comma, quote or line break. */
export function escapeCsvValue(value: unknown): string {
  const text = value === null || value === undefined ? "" : String(value)
  return /[",\r\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text
}

/** Serialises headers and rows to CSV text. Rows are arrays in header order. */
export function toCsv(headers: string[], rows: unknown[][]): string {
  return [headers, ...rows].map((row) => row.map(escapeCsvValue).join(",")).join("\r\n")
}

/** The text of a template file for these columns: the header plus one example row. */
export function sampleCsv(columns: CsvColumn[]): string {
  return toCsv(
    columns.map((c) => c.name),
    [columns.map((c) => c.example ?? "")]
  )
}

/** Saves text as a file through the browser. Browser only. */
export function saveCsv(filename: string, text: string): void {
  const url = URL.createObjectURL(new Blob(["﻿" + text], { type: "text/csv;charset=utf-8" }))
  const link = document.createElement("a")
  link.href = url
  link.download = filename
  document.body.appendChild(link)
  link.click()
  link.remove()
  URL.revokeObjectURL(url)
}
