"use client";

// Katalyst Design System — public entry point (auto-generated barrel).
// Marked "use client": the barrel re-exports components that use hooks, so the bundled root entry
// must carry the directive for Next.js App Router. Server code should import utilities from their
// own paths (`@kalvi-education/katalyst/lib/utils`), not from this entry.
// Components are also importable individually via `@kalvi-education/katalyst/components/<name>`.

// Components
export * from "./components/accordion";
export * from "./components/alert";
export * from "./components/alert-dialog";
export * from "./components/app-switcher";
export * from "./components/aspect-ratio";
export * from "./components/attachment";
export * from "./components/avatar";
export * from "./components/badge";
export * from "./components/breadcrumb";
export * from "./components/bubble";
export * from "./components/button";
export * from "./components/button-group";
export * from "./components/calendar";
export * from "./components/card";
export * from "./components/carousel";
export * from "./components/chart";
export * from "./components/checkbox";
export * from "./components/collapsible";
export * from "./components/combobox";
export * from "./components/command";
export * from "./components/context-menu";
export * from "./components/csv-upload";
export * from "./components/data-table";
export * from "./components/date-range-picker";
export * from "./components/date-time-picker";
export * from "./components/dialog";
export * from "./components/direction";
export * from "./components/drawer";
export * from "./components/dropdown-menu";
export * from "./components/empty";
export * from "./components/field";
export * from "./components/file-upload";
export * from "./components/fullscreen-modal";
export * from "./components/hover-card";
export * from "./components/input";
export * from "./components/input-group";
export * from "./components/input-otp";
export * from "./components/item";
export * from "./components/kalvi-grid-v4";
export * from "./components/kbd";
export * from "./components/label";
export * from "./components/logo";
export * from "./components/markdown-editor";
export * from "./components/marker";
export * from "./components/menubar";
export * from "./components/message";
export * from "./components/message-scroller";
export * from "./components/multi-select";
export * from "./components/native-select";
export * from "./components/navigation-menu";
export * from "./components/pagination";
export * from "./components/popover";
export * from "./components/progress";
export * from "./components/questionnaire";
export * from "./components/radio-group";
export * from "./components/resizable";
export * from "./components/scroll-area";
export * from "./components/select";
export * from "./components/separator";
export * from "./components/sheet";
export * from "./components/sidebar";
export * from "./components/skeleton";
export * from "./components/slider";
export * from "./components/sonner";
export * from "./components/spinner";
export * from "./components/stat-card";
export * from "./components/switch";
export * from "./components/table";
export * from "./components/tabs";
export * from "./components/textarea";
export * from "./components/toggle";
export * from "./components/toggle-group";
export * from "./components/tooltip";
export * from "./components/app-shell";

// Hooks
export * from "./hooks/use-mobile";

// Utilities
export * from "./lib/utils";
export * from "./lib/csv";
export * from "./lib/app-shell-backdrop";
