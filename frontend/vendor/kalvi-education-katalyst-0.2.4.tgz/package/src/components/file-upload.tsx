"use client"

import * as React from "react"
import { HugeiconsIcon, type IconSvgElement } from "@hugeicons/react"
import {
  AlertCircleIcon,
  Cancel01Icon,
  CheckmarkCircle02Icon,
  CloudUploadIcon,
  Doc01Icon,
  File01Icon,
  FileZipIcon,
  Image01Icon,
  Pdf01Icon,
  Ppt01Icon,
  Txt01Icon,
  Video01Icon,
  Xls01Icon,
} from "@hugeicons/core-free-icons"

import { cn } from "@kalvi-education/katalyst/lib/utils"
import { Alert, AlertAction, AlertDescription, AlertTitle } from "@kalvi-education/katalyst/components/alert"
import {
  Attachment,
  AttachmentAction,
  AttachmentActions,
  AttachmentContent,
  AttachmentDescription,
  AttachmentGroup,
  AttachmentMedia,
  AttachmentTitle,
} from "@kalvi-education/katalyst/components/attachment"
import { Button } from "@kalvi-education/katalyst/components/button"
import { Spinner } from "@kalvi-education/katalyst/components/spinner"

type FileUploadItem = {
  /** Stable key for the row. */
  id: string
  name: string
  /** Size in bytes. */
  size?: number
  /** MIME type. Picks the icon; taken from `file` when omitted. */
  type?: string
  /** The picked file. An image file gets a thumbnail, made and released by the component. */
  file?: File
  /** A thumbnail address, for files already on the server. Wins over `file`. */
  previewUrl?: string
  /** `processing` is for work after the upload: a virus scan, a conversion, text extraction. */
  status?: "idle" | "uploading" | "processing" | "complete" | "error"
  /** 0 to 100. Shown while `status` is "uploading". */
  progress?: number
  /** Why this file failed. Shown under the name when `status` is "error". */
  error?: string
}

type FileRejection = {
  file: File
  reason: "type" | "size" | "empty" | "count"
  message: string
}

type FileUploadProps = Omit<React.ComponentProps<"div">, "onChange"> & {
  /** The files to list. The component does not upload; the app owns this list and its progress. */
  files: FileUploadItem[]
  /** Called with the files that passed validation. */
  onFilesAdded: (files: File[]) => void
  /** Called when the remove button of a file is pressed. */
  onRemove?: (item: FileUploadItem) => void | Promise<void>
  /** Called with the files that failed validation, after the messages are shown. */
  onReject?: (rejections: FileRejection[]) => void
  /**
   * `lg` is a tall drop area with the files as thumbnail cards in a row below. `sm` is a one-line drop bar with the
   * files as compact chips, for forms and side panels.
   */
  size?: "sm" | "lg"
  /** Accepted extensions (".pdf") or MIME types ("image/*"). Anything is accepted when omitted. */
  accept?: string[]
  /** Largest file in bytes. */
  maxSize?: number
  /** Most files the list may hold, counting `files`. */
  maxFiles?: number
  /** Allow choosing several files at once. */
  multiple?: boolean
  /** Accept files pasted (Cmd or Ctrl + V) while the drop area has focus, such as a copied screenshot. */
  pasteable?: boolean
  disabled?: boolean
  title?: string
  description?: string
  /** Name for the hidden file input, for native form posts. */
  name?: string
}

function formatFileSize(bytes: number, locale?: string) {
  const units = ["B", "KB", "MB", "GB"]
  let size = bytes
  let unit = 0
  while (size >= 1024 && unit < units.length - 1) {
    size /= 1024
    unit++
  }
  const number = new Intl.NumberFormat(locale, {
    maximumFractionDigits: unit === 0 ? 0 : 1,
  }).format(size)
  return `${number} ${units[unit]}`
}

function matchesAccept(file: { name: string; type: string }, accept: string[]) {
  const name = file.name.toLowerCase()
  return accept.some((rule) => {
    const r = rule.trim().toLowerCase()
    if (r.startsWith(".")) return name.endsWith(r)
    if (r.endsWith("/*")) return file.type.toLowerCase().startsWith(r.slice(0, -1))
    return file.type.toLowerCase() === r
  })
}

/**
 * Checks files against the rules. Exported so an app can run the same check on files that arrive some other way.
 * `existing` is how many files the list already holds.
 */
function validateFiles(
  incoming: File[],
  rules: { accept?: string[]; maxSize?: number; maxFiles?: number; existing?: number }
): { accepted: File[]; rejections: FileRejection[] } {
  const { accept, maxSize, maxFiles, existing = 0 } = rules
  const accepted: File[] = []
  const rejections: FileRejection[] = []

  for (const file of incoming) {
    if (file.size <= 0) {
      rejections.push({ file, reason: "empty", message: `${file.name} is empty. Choose a file with content.` })
    } else if (accept?.length && !matchesAccept(file, accept)) {
      rejections.push({
        file,
        reason: "type",
        message: `${file.name} is not a supported type. Use ${accept.join(", ")}.`,
      })
    } else if (maxSize !== undefined && file.size > maxSize) {
      rejections.push({
        file,
        reason: "size",
        message: `${file.name} is ${formatFileSize(file.size)}. The limit is ${formatFileSize(maxSize)}.`,
      })
    } else if (maxFiles !== undefined && existing + accepted.length >= maxFiles) {
      rejections.push({
        file,
        reason: "count",
        message: `${file.name} was not added. You can add up to ${maxFiles} ${maxFiles === 1 ? "file" : "files"}.`,
      })
    } else {
      accepted.push(file)
    }
  }
  return { accepted, rejections }
}

/** Extension rules that a drag can be checked against, since a drag only exposes MIME types. */
const EXTENSION_TYPES: Record<string, string> = {
  ".pdf": "application/pdf",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".gif": "image/gif",
  ".webp": "image/webp",
  ".svg": "image/svg+xml",
  ".csv": "text/csv",
  ".txt": "text/plain",
  ".zip": "application/zip",
  ".mp4": "video/mp4",
}

/** Whether every dragged item will be accepted. `undefined` when the browser does not say enough to judge. */
function judgeDrag(items: DataTransferItemList, accept?: string[]): boolean | undefined {
  if (!accept?.length) return true
  const files = [...items].filter((item) => item.kind === "file")
  if (files.length === 0 || files.some((item) => !item.type)) return undefined
  const rules = accept.map((rule) => EXTENSION_TYPES[rule.trim().toLowerCase()] ?? rule)
  if (rules.some((rule) => rule.startsWith("."))) return undefined
  return files.every((item) => matchesAccept({ name: "", type: item.type }, rules))
}

function fileIcon(name: string, type = ""): IconSvgElement {
  const ext = name.toLowerCase().split(".").pop() ?? ""
  if (type.startsWith("image/") || ["png", "jpg", "jpeg", "gif", "webp", "svg", "heic"].includes(ext)) return Image01Icon
  if (type === "application/pdf" || ext === "pdf") return Pdf01Icon
  if (type.startsWith("video/") || ["mp4", "mov", "webm"].includes(ext)) return Video01Icon
  if (["xls", "xlsx", "csv", "ods"].includes(ext)) return Xls01Icon
  if (["doc", "docx", "odt", "rtf"].includes(ext)) return Doc01Icon
  if (["ppt", "pptx", "key", "odp"].includes(ext)) return Ppt01Icon
  if (["zip", "rar", "7z", "tar", "gz"].includes(ext)) return FileZipIcon
  if (["txt", "md"].includes(ext)) return Txt01Icon
  return File01Icon
}

/** A thumbnail address for an image file, released when the file changes or the row unmounts. */
function useImagePreview(item: FileUploadItem) {
  const [url, setUrl] = React.useState<string | undefined>()
  const file = item.previewUrl ? undefined : item.file

  React.useEffect(() => {
    if (!file || !file.type.startsWith("image/")) {
      setUrl(undefined)
      return
    }
    const next = URL.createObjectURL(file)
    setUrl(next)
    return () => URL.revokeObjectURL(next)
  }, [file])

  return item.previewUrl ?? url
}

const ATTACHMENT_STATE = {
  idle: "idle",
  uploading: "uploading",
  processing: "processing",
  complete: "done",
  error: "error",
} as const

function FileUploadCard({
  item,
  size,
  disabled,
  onRemove,
}: {
  item: FileUploadItem
  size: "sm" | "lg"
  disabled?: boolean
  onRemove?: FileUploadProps["onRemove"]
}) {
  const [removing, setRemoving] = React.useState(false)
  const status = item.status ?? "idle"
  const preview = useImagePreview(item)
  const progress = Math.round(item.progress ?? 0)
  const busy = status === "uploading" || status === "processing"
  const large = size === "lg"

  const detail =
    status === "error"
      ? (item.error ?? "Upload failed")
      : status === "uploading"
        ? `Uploading ${progress}%`
        : status === "processing"
          ? "Processing"
          : item.size !== undefined
            ? formatFileSize(item.size)
            : "Size unavailable"

  return (
    <Attachment
      role="listitem"
      data-slot="file-upload-item"
      data-status={status}
      state={ATTACHMENT_STATE[status]}
      size={large ? "default" : "sm"}
      orientation={large ? "vertical" : "horizontal"}
      className={cn(large ? "w-36" : "max-w-64 min-w-48")}
    >
      <AttachmentMedia variant={preview ? "image" : "icon"} className={cn(large && "aspect-[4/3] *:[img]:aspect-auto *:[img]:h-full")}>
        {preview ? (
          <img src={preview} alt="" />
        ) : (
          <HugeiconsIcon icon={fileIcon(item.name, item.type ?? item.file?.type)} strokeWidth={1.75} />
        )}
        {busy && large && (
          <span className="absolute inset-0 flex items-center justify-center bg-background/40">
            <Spinner aria-hidden />
          </span>
        )}
        {status === "uploading" && (
          <span
            aria-hidden
            className="absolute inset-x-0 bottom-0 h-1 bg-foreground/10"
          >
            <span className="block h-full bg-primary transition-[width]" style={{ width: `${progress}%` }} />
          </span>
        )}
        {status === "complete" && large && (
          <span className="absolute bottom-1.5 left-1.5 flex size-5 items-center justify-center rounded-full bg-background shadow-sm">
            <HugeiconsIcon icon={CheckmarkCircle02Icon} strokeWidth={2} className="size-4 text-green-bold dark:text-green-main" aria-hidden />
          </span>
        )}
      </AttachmentMedia>
      <AttachmentContent>
        <AttachmentTitle title={item.name}>{item.name}</AttachmentTitle>
        <AttachmentDescription
          title={status === "error" ? detail : undefined}
          className={cn("tabular-nums", status === "error" && large && "line-clamp-2 whitespace-normal")}
        >
          {status === "error" && (
            <HugeiconsIcon icon={AlertCircleIcon} strokeWidth={2} className="mr-1 inline size-3 align-[-2px]" aria-hidden />
          )}
          {detail}
        </AttachmentDescription>
        {status === "complete" && <span className="sr-only">Uploaded</span>}
      </AttachmentContent>
      {onRemove && status !== "uploading" && (
        <AttachmentActions>
          <AttachmentAction
            type="button"
            variant={large ? "secondary" : "ghost"}
            disabled={disabled || removing}
            aria-label={`Remove ${item.name}`}
            className={cn(large && "rounded-full shadow-sm")}
            onClick={async () => {
              setRemoving(true)
              try {
                await onRemove(item)
              } finally {
                setRemoving(false)
              }
            }}
          >
            {removing ? <Spinner /> : <HugeiconsIcon icon={Cancel01Icon} strokeWidth={2} />}
          </AttachmentAction>
        </AttachmentActions>
      )}
    </Attachment>
  )
}

/** Three tilted file cards, drawn with role tokens so the art follows the theme. */
function DropArt({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 120 72" aria-hidden className={cn("h-16 w-28", className)}>
      <g transform="rotate(-12 34 44)">
        <rect x="16" y="16" width="36" height="46" rx="5" className="fill-card stroke-border" strokeWidth="1.5" />
        <rect x="22" y="44" width="16" height="8" rx="2" className="fill-red-medium" />
        <rect x="22" y="24" width="22" height="3" rx="1.5" className="fill-muted" />
        <rect x="22" y="31" width="16" height="3" rx="1.5" className="fill-muted" />
      </g>
      <g transform="rotate(12 86 44)">
        <rect x="68" y="16" width="36" height="46" rx="5" className="fill-card stroke-border" strokeWidth="1.5" />
        <rect x="74" y="24" width="24" height="3" rx="1.5" className="fill-muted" />
        <rect x="74" y="31" width="18" height="3" rx="1.5" className="fill-muted" />
        <rect x="74" y="44" width="16" height="8" rx="2" className="fill-blue-medium" />
      </g>
      <g className="transition-transform duration-200 group-data-dragging/dropzone:-translate-y-1.5">
        <rect x="41" y="6" width="38" height="50" rx="5" className="fill-card stroke-border" strokeWidth="1.5" />
        <rect x="46" y="11" width="28" height="22" rx="3" className="fill-green-soft" />
        <circle cx="53" cy="18" r="3" className="fill-green-main" />
        <path d="M46 33l9-9 6 6 4-3 9 6v0H46z" className="fill-green-main" />
        <rect x="46" y="39" width="24" height="3" rx="1.5" className="fill-muted" />
        <rect x="46" y="46" width="16" height="3" rx="1.5" className="fill-muted" />
      </g>
    </svg>
  )
}

function FileUpload({
  files,
  onFilesAdded,
  onRemove,
  onReject,
  size = "lg",
  accept,
  maxSize,
  maxFiles,
  multiple = true,
  pasteable = false,
  disabled = false,
  title,
  description,
  name,
  className,
  ...props
}: FileUploadProps) {
  const inputRef = React.useRef<HTMLInputElement>(null)
  const dragDepth = React.useRef(0)
  const hintId = React.useId()
  const [drag, setDrag] = React.useState<{ count: number; ok: boolean | undefined } | null>(null)
  const [messages, setMessages] = React.useState<string[]>([])

  const hint =
    description ??
    [
      accept?.length ? accept.map((rule) => rule.replace(/^\./, "").toUpperCase()).join(", ") : null,
      maxSize !== undefined ? `up to ${formatFileSize(maxSize)}` : null,
      maxFiles !== undefined && maxFiles > 1 ? `${maxFiles} files at most` : null,
      pasteable ? "or paste" : null,
    ]
      .filter(Boolean)
      .join(", ")

  const full = maxFiles !== undefined && files.length >= maxFiles
  const blocked = disabled || full
  const large = size === "lg"
  const noun = multiple ? "files" : "a file"

  const handle = (list: FileList | File[]) => {
    const incoming = Array.from(list)
    if (incoming.length === 0) return
    const { accepted, rejections } = validateFiles(incoming, {
      accept,
      maxSize,
      maxFiles,
      existing: files.length,
    })
    setMessages(rejections.map((r) => r.message))
    if (rejections.length) onReject?.(rejections)
    if (accepted.length) onFilesAdded(accepted)
  }

  const heading = full
    ? "File limit reached"
    : drag
      ? drag.ok === false
        ? "Some of these files are not supported"
        : `Drop to add ${drag.count > 1 ? `${drag.count} files` : "the file"}`
      : (title ?? (large ? `Drag ${noun} here or browse` : `Drop ${noun} or browse`))

  return (
    <div data-slot="file-upload" data-size={size} className={cn("flex flex-col gap-3", className)} {...props}>
      <button
        type="button"
        data-slot="file-upload-dropzone"
        data-dragging={drag ? "" : undefined}
        data-reject={drag?.ok === false ? "" : undefined}
        disabled={blocked}
        aria-describedby={hint ? hintId : undefined}
        onClick={() => inputRef.current?.click()}
        onPaste={(event) => {
          if (!pasteable || blocked) return
          const pasted = [...event.clipboardData.files]
          if (pasted.length) {
            event.preventDefault()
            handle(multiple ? pasted : pasted.slice(0, 1))
          }
        }}
        onDragEnter={(event) => {
          event.preventDefault()
          if (blocked) return
          dragDepth.current++
          const count = [...event.dataTransfer.items].filter((item) => item.kind === "file").length
          setDrag({ count: multiple ? count : Math.min(count, 1), ok: judgeDrag(event.dataTransfer.items, accept) })
        }}
        onDragOver={(event) => {
          event.preventDefault()
          if (!blocked) event.dataTransfer.dropEffect = "copy"
        }}
        onDragLeave={(event) => {
          event.preventDefault()
          dragDepth.current = Math.max(0, dragDepth.current - 1)
          if (dragDepth.current === 0) setDrag(null)
        }}
        onDrop={(event) => {
          event.preventDefault()
          dragDepth.current = 0
          setDrag(null)
          if (!blocked) handle(multiple ? event.dataTransfer.files : [...event.dataTransfer.files].slice(0, 1))
        }}
        className={cn(
          "group/dropzone relative flex w-full rounded-xl border border-dashed border-border bg-muted/30 text-left transition-colors outline-none",
          "hover:border-ring/60 hover:bg-muted/60 focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50",
          "data-dragging:border-solid data-dragging:border-primary data-dragging:bg-primary/5",
          "data-reject:border-destructive data-reject:bg-destructive/5",
          "disabled:pointer-events-none disabled:opacity-50",
          large ? "flex-col items-center gap-3 px-6 py-8 text-center" : "items-center gap-3 px-3 py-2.5"
        )}
      >
        {large ? (
          <DropArt />
        ) : (
          <span className="flex size-8 shrink-0 items-center justify-center rounded-lg bg-background text-muted-foreground ring-1 ring-border group-data-dragging/dropzone:text-primary">
            <HugeiconsIcon icon={CloudUploadIcon} strokeWidth={2} className="size-4" aria-hidden />
          </span>
        )}
        <span className={cn("flex min-w-0 flex-col gap-0.5", !large && "flex-1")}>
          <span aria-live="polite" className="text-sm font-medium">
            {heading}
          </span>
          {hint && (
            <span id={hintId} className="text-xs text-pretty text-muted-foreground">
              {hint}
            </span>
          )}
        </span>
        {!full && (
          <span
            aria-hidden
            className={cn(
              "inline-flex h-7 shrink-0 items-center rounded-md border border-border bg-background px-2.5 text-xs font-medium shadow-xs",
              drag && "invisible"
            )}
          >
            Browse
          </span>
        )}
      </button>
      <input
        ref={inputRef}
        type="file"
        name={name}
        className="sr-only"
        tabIndex={-1}
        aria-hidden
        multiple={multiple}
        disabled={blocked}
        accept={accept?.join(",")}
        onChange={(event) => {
          if (event.target.files) handle(event.target.files)
          event.target.value = ""
        }}
      />

      {messages.length > 0 && (
        <Alert variant="destructive">
          <HugeiconsIcon icon={AlertCircleIcon} strokeWidth={2} />
          <AlertTitle>
            {messages.length === 1 ? "1 file was not added" : `${messages.length} files were not added`}
          </AlertTitle>
          <AlertDescription>
            <ul className="list-disc pl-4">
              {messages.map((message) => (
                <li key={message}>{message}</li>
              ))}
            </ul>
          </AlertDescription>
          <AlertAction>
            <Button type="button" variant="ghost" size="icon-xs" aria-label="Dismiss" onClick={() => setMessages([])}>
              <HugeiconsIcon icon={Cancel01Icon} strokeWidth={2} />
            </Button>
          </AlertAction>
        </Alert>
      )}

      {files.length > 0 &&
        (large ? (
          <AttachmentGroup role="list" aria-label="Files" data-slot="file-upload-list" className="pt-1">
            {files.map((item) => (
              <FileUploadCard key={item.id} item={item} size="lg" disabled={disabled} onRemove={onRemove} />
            ))}
          </AttachmentGroup>
        ) : (
          <div role="list" aria-label="Files" data-slot="file-upload-list" className="flex flex-wrap gap-2">
            {files.map((item) => (
              <FileUploadCard key={item.id} item={item} size="sm" disabled={disabled} onRemove={onRemove} />
            ))}
          </div>
        ))}
    </div>
  )
}

export { FileUpload, formatFileSize, validateFiles }
export type { FileRejection, FileUploadItem, FileUploadProps }
