"use client"

import * as React from "react"

import { HugeiconsIcon, type IconSvgElement } from "@hugeicons/react"
import { ArrowDown01Icon, Logout01Icon, Menu01Icon, Search01Icon } from "@hugeicons/core-free-icons"

import { cn } from "@kalvi-education/katalyst/lib/utils"
import { appShellBackdrop } from "@kalvi-education/katalyst/lib/app-shell-backdrop"
import { Avatar, AvatarFallback, AvatarImage } from "@kalvi-education/katalyst/components/avatar"
import { Button } from "@kalvi-education/katalyst/components/button"
import { KalviumMark } from "@kalvi-education/katalyst/components/logo"
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@kalvi-education/katalyst/components/collapsible"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@kalvi-education/katalyst/components/dropdown-menu"
import {
  Drawer,
  DrawerContent,
  DrawerDescription,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
} from "@kalvi-education/katalyst/components/drawer"
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@kalvi-education/katalyst/components/sheet"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarInset,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
  SidebarProvider,
  SidebarRail,
  SidebarTrigger,
} from "@kalvi-education/katalyst/components/sidebar"
import { InputGroup, InputGroupAddon, InputGroupInput } from "@kalvi-education/katalyst/components/input-group"
import { Kbd, KbdGroup } from "@kalvi-education/katalyst/components/kbd"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@kalvi-education/katalyst/components/tooltip"

type AppShellLinkProps = React.ComponentProps<"a"> & { href: string }

/**
 * The consuming app's router link — `next/link`, react-router's `Link`, or anything
 * else that accepts an `href`. Katalyst has no framework dependency, so routing is
 * injected rather than imported.
 */
type AppShellLink = React.ComponentType<AppShellLinkProps>

/** Fallback when no router is supplied: a plain anchor, so the header still navigates. */
function DefaultLink(props: AppShellLinkProps) {
  return <a {...props} />
}

/* -------------------------------------------------------------------------- */
/* Image slots                                                                 */
/* -------------------------------------------------------------------------- */

/**
 * How an image slot is filled: the app icon and the page pattern both take this shape.
 *
 * ```tsx
 * backgroundImage={{ default: true }}                     // the Kalvium artwork
 * backgroundImage={{ custom: "https://cdn.example/p.svg" }} // your own image
 * backgroundImage={{ default: false, custom: url }}       // explicit: only your own
 * ```
 *
 * `custom` wins over `default` when it is a non-empty URL. With neither, the slot stays empty. The
 * plain-string forms (`"default"`, or a URL) still work as a shorthand.
 */
type AppShellAsset = {
  /** Use the artwork that ships with Katalyst: the backdrop for the page, the Kalvium mark for the icon. */
  default?: boolean
  /** The URL of your own image. When it is set it replaces the default. */
  custom?: string
}

function isAssetConfig(value: unknown): value is AppShellAsset {
  return (
    typeof value === "object" &&
    value !== null &&
    !Array.isArray(value) &&
    !React.isValidElement(value) &&
    ("default" in value || "custom" in value)
  )
}

/** The URL to use, `"default"` for the bundled artwork, or nothing. */
function resolveAsset(config: AppShellAsset): string | undefined {
  const custom = config.custom?.trim()
  if (custom) return custom
  return config.default ? "default" : undefined
}

/** The app icon: a config picks the Kalvium mark or your image; a string is an image URL. */
function renderIcon(icon: React.ReactNode | AppShellAsset) {
  if (isAssetConfig(icon)) {
    const resolved = resolveAsset(icon)
    if (!resolved) return null
    // The frame's mark is padded inside its box; KalviumMark fills its box, so size it down.
    return resolved === "default" ? <KalviumMark label={null} className="size-6.5" /> : <img src={resolved} alt="" />
  }
  return typeof icon === "string" ? <img src={icon} alt="" /> : icon
}

/** Safe to put inside a CSS `url("...")`: a quote or backslash in a URL cannot end the string early. */
const cssUrl = (url: string) => `url("${url.replace(/["\\\n\r]/g, encodeURIComponent)}")`

/* -------------------------------------------------------------------------- */
/* Root                                                                        */
/* -------------------------------------------------------------------------- */

/**
 * The textured page ground a workspace sits on.
 *
 * `backgroundImage="default"` uses the Kalvium backdrop that ships with the package;
 * any other string is treated as a URL, so an app that already serves its own artwork
 * passes that instead and never pulls the embedded copy into its bundle.
 */
function AppShellRoot({
  backgroundImage,
  className,
  style,
  ...props
}: React.ComponentProps<"div"> & {
  /**
   * The pattern on the page ground, as a config: `{ default: true }` for the Kalvium backdrop or
   * `{ custom: "https://…" }` for the URL of your own tiling image. The strings `"default"` and a
   * bare URL are accepted as shorthand. Omit for a plain ground.
   */
  backgroundImage?: "default" | (string & {}) | AppShellAsset
}) {
  const requested = isAssetConfig(backgroundImage) ? resolveAsset(backgroundImage) : backgroundImage
  const isDefault = requested === "default"
  const image = isDefault ? appShellBackdrop : requested || undefined

  return (
    <div
      data-slot="app-shell"
      data-backdrop={image ? (isDefault ? "default" : "custom") : undefined}
      className={cn(
        // No gap: the header carries its own bottom padding, exactly as the
        // Livebooks route layout does. `h-full` rather than the app's `h-screen`,
        // so this fills whatever region the app gives it. 16px at the sides and 20px
        // top and bottom, per the Figma frame, at every width.
        "flex h-full min-h-0 flex-col overflow-y-auto bg-background bg-repeat px-4 py-5",
        // The stock backdrop is light-on-light artwork, so it is dropped in dark mode
        // rather than washing pale shapes over a dark ground — the same call the
        // Livebooks route layout makes with `dark:bg-none`.
        // The image arrives through a variable rather than an inline `background-image`, because an
        // inline style beats `dark:bg-none` and the backdrop would stay on in dark mode.
        image && "bg-[image:var(--app-shell-backdrop)]",
        isDefault && "dark:bg-none",
        className
      )}
      style={
        image
          ? ({ "--app-shell-backdrop": isDefault ? `url("${image}")` : cssUrl(image), ...style } as React.CSSProperties)
          : style
      }
      {...props}
    />
  )
}

/* -------------------------------------------------------------------------- */
/* Header                                                                      */
/* -------------------------------------------------------------------------- */

function AppShellHeader({
  leading,
  logo,
  divider = Boolean(logo),
  icon,
  title,
  href,
  linkComponent: Link = DefaultLink,
  actions,
  search,
  searchTriggerLabel = "Open search",
  searchCollapseBelow = 720,
  className,
  children,
  ...props
}: Omit<React.ComponentProps<"header">, "title"> & {
  /**
   * Mark shown before the title. A string is treated as an image URL — the usual case
   * for a product logo an app already serves. Anything else renders as given. Either
   * way the header sizes it, so pass it unsized.
   */
  icon?: React.ReactNode | AppShellAsset
  /** Page title, rendered at the shell's title step (`text-3xl font-bold`, per the Figma frame). */
  title?: React.ReactNode
  /** Rendered before the icon — where `AppShell` puts the sidebar trigger. */
  leading?: React.ReactNode
  /**
   * A logo shown before the divider and title, for a surface with no rail to carry it.
   * Unsized artwork fills a 32px slot; pass a `size-*` class to set it yourself.
   */
  logo?: React.ReactNode
  /**
   * The slash between what comes before the title (the rail's logo, or `logo`) and the
   * title itself. On when `logo` is set; `AppShell` also turns it on beside a `rail`.
   */
  divider?: boolean
  /** Makes the icon and title a link — usually back to the surface's own root. */
  href?: string
  /**
   * The app's router link, used when `href` is set. Defaults to a plain anchor, so
   * the header navigates without a router.
   */
  linkComponent?: AppShellLink
  /** Trailing controls: filters, a primary action. */
  actions?: React.ReactNode
  /**
   * The surface's search control. Rendered inline while the header is wide enough,
   * and collapsed to an icon that opens a bottom sheet when it is not — measured from
   * the header's own width, so it responds to the space it actually has rather than
   * to the viewport.
   */
  search?: React.ReactNode
  /** Accessible name for the icon that opens the search sheet. */
  searchTriggerLabel?: string
  /** Header width, in px, below which the search collapses to its icon. */
  searchCollapseBelow?: number
}) {
  const headerRef = React.useRef<HTMLElement>(null)
  const [compactSearch, setCompactSearch] = React.useState(false)
  const [searchSheetOpen, setSearchSheetOpen] = React.useState(false)

  React.useLayoutEffect(() => {
    const node = headerRef.current
    if (!node || !search) return
    const measure = () => setCompactSearch(node.getBoundingClientRect().width < searchCollapseBelow)
    measure()
    const observer = new ResizeObserver(measure)
    observer.observe(node)
    return () => observer.disconnect()
  }, [search, searchCollapseBelow])

  const searchSlot = search ? (
    compactSearch ? (
      <>
        <Button
          variant="outline"
          size="icon-sm"
          aria-label={searchTriggerLabel}
          onClick={() => setSearchSheetOpen(true)}
        >
          <HugeiconsIcon icon={Search01Icon} strokeWidth={2} className="size-4" />
        </Button>
        <Sheet open={searchSheetOpen} onOpenChange={setSearchSheetOpen}>
          <SheetContent side="bottom" className="gap-0 rounded-t-xl p-0">
            <SheetHeader className="border-b">
              <SheetTitle>Search</SheetTitle>
              <SheetDescription>Search within this surface.</SheetDescription>
            </SheetHeader>
            <div className="p-4">{search}</div>
          </SheetContent>
        </Sheet>
      </>
    ) : (
      // w-full with a cap, not flex-1: the wrapper then shrinks to the cap and the
      // container's justify-end holds it against the right edge. 220px, per the Figma frame.
      // The slot is solid (the page ground), so the pattern behind the header never shows through
      // a search field that is transparent in light mode; in dark mode the field's own tint sits
      // on top, which is the frame's "background, dark: input/30" fill.
      <div data-slot="app-shell-header-search" className="w-full min-w-0 max-w-55 rounded-lg bg-background">
        {search}
      </div>
    )
  ) : null


  // A config can resolve to nothing (neither default nor custom), so decide on the result, not the prop.
  const iconNode = icon ? renderIcon(icon) : null

  const heading = (
    // 16px between the icon and the title, per the Figma frame.
    <span className="flex items-center gap-4">
      {iconNode ? (
        <span
          data-slot="app-shell-header-icon"
          className="flex size-8 shrink-0 items-center justify-center [&_img]:size-8 [&_svg]:size-8"
        >
          {/* Decorative: the title beside it already names the surface. */}
          {iconNode}
        </span>
      ) : null}
      {title ? (
        // The shell's title step is the Figma frame's: 30px on a 36px line, bold. That is
        // heavier than the page-title step in DESIGN.md §3 (`text-2xl font-semibold`), which
        // is for titles inside the canvas. This one names the whole surface.
        // base/primary in the frame, the strongest text role: near-black in light mode, near-white in dark.
        <span className="font-heading text-3xl font-bold text-primary">{title}</span>
      ) : null}
    </span>
  )

  return (
    <header
      ref={headerRef}
      data-slot="app-shell-header"
      className={cn("w-full shrink-0 pb-4", className)}
      {...props}
    >
      <div className="flex w-full items-center justify-between gap-3">
        {/* leading, logo, divider and heading are one cluster, or justify-between strands
            the title in the middle of the row. 12px between them, per the Figma frame. */}
        <div className="flex items-center gap-3">
          {leading ? <div className="flex items-center">{leading}</div> : null}
          {logo ? (
            <div
              data-slot="app-shell-header-logo"
              className="flex h-9 items-center [&_img:not([class*='size-'])]:size-8 [&_svg:not([class*='size-'])]:size-8"
            >
              {logo}
            </div>
          ) : null}
          {divider ? (
            // The frame's divider is a drawn line, not a "/" character: a 1px stroke from the
            // upper right to the lower left of a 12 by 36 box, in a muted neutral.
            <svg
              data-slot="app-shell-header-divider"
              aria-hidden="true"
              width="12"
              height="36"
              viewBox="0 0 12 36"
              fill="none"
              className="h-9 w-3 shrink-0 text-muted-foreground/65"
            >
              <path d="M10.1042 6.72369L1.89576 29.2763" stroke="currentColor" />
            </svg>
          ) : null}
          {href ? (
            <Link
              href={href}
              className="flex items-center rounded-lg transition-opacity outline-none hover:opacity-80 focus-visible:ring-3 focus-visible:ring-ring/50"
            >
              {heading}
            </Link>
          ) : (
            <div className="flex items-center">{heading}</div>
          )}
        </div>
        {children}
        {searchSlot || actions ? (
          <div className="flex min-w-0 flex-1 items-center justify-end gap-2 pl-3">
            {searchSlot}
          </div>
        ) : null}
        {actions ? (
          <div
            data-slot="app-shell-header-actions"
            // Pinned to the right and sized to its content, so a narrow header keeps
            // the actions beside the title instead of wrapping them onto a new row.
            // gap-2 is invisible with a single child and keeps multiple controls apart.
            className="flex shrink-0 items-center gap-2"
          >
            {actions}
          </div>
        ) : null}
      </div>
    </header>
  )
}

/* -------------------------------------------------------------------------- */
/* Panel                                                                       */
/* -------------------------------------------------------------------------- */

/**
 * The working surface holding the rail and canvas. A hairline edge (DESIGN.md §6's "delineated"
 * step) on the page's own background, with the md radius, as the Figma frame's BodyContainer.
 *
 * The backdrop lives here rather than on the canvas because the rail is translucent
 * and the pattern shows faintly through it, as it does in the app. The dot grid is
 * drawn in CSS from `--border`, so it needs no image asset and follows the theme.
 */
function AppShellPanel({
  pattern = "dots",
  className,
  ...props
}: React.ComponentProps<"div"> & {
  pattern?: "dots" | "none"
}) {
  return (
    <div
      data-slot="app-shell-panel"
      data-pattern={pattern}
      className={cn(
        // The frame's BodyContainer: the page's own background (not the raised card surface), a hairline,
        // and the md radius. On the dark ground it therefore stays the ground, as drawn.
        "flex min-h-0 flex-1 flex-col overflow-y-auto rounded-md border border-border bg-background md:flex-row",
        // Dots 18px apart, measured from the frame, 1px, in the border colour so they follow the theme.
        pattern === "dots" &&
          "[background-image:radial-gradient(var(--border)_1px,transparent_1px)] [background-size:1.125rem_1.125rem]",
        className
      )}
      {...props}
    />
  )
}

/* -------------------------------------------------------------------------- */
/* Aside                                                                       */
/* -------------------------------------------------------------------------- */

/**
 * Secondary rail inside the panel — a filter list, a chapter index, a table of
 * contents. Hidden below `md`, where `AppShell` moves it into a bottom sheet.
 * Translucent, so the panel's pattern shows through. Width is one scoped variable,
 * per DESIGN.md §4, so it retunes in a single place.
 */
function AppShellAside({ className, ...props }: React.ComponentProps<"aside">) {
  return (
    <aside
      data-slot="app-shell-aside"
      className={cn(
        "hidden min-h-0 shrink-0 overflow-x-hidden overflow-y-auto border-border bg-card/50 [--app-shell-aside-width:--spacing(69)] md:block md:w-(--app-shell-aside-width) md:border-r",
        className
      )}
      {...props}
    />
  )
}

/* -------------------------------------------------------------------------- */
/* Canvas                                                                      */
/* -------------------------------------------------------------------------- */

/**
 * The primary work area. Transparent, so the panel's backdrop reads through it.
 *
 * Deliberately a `div`, not a `main`. The surrounding shell owns that landmark —
 * the page owns that landmark — and nesting a second one inside it
 * is invalid. Used without a shell, wrap the workspace in your own `main`.
 */
function AppShellCanvas({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="app-shell-canvas"
      className={cn(
        "min-h-[54vh] flex-1 overflow-y-auto bg-transparent p-4 lg:p-8",
        className
      )}
      {...props}
    />
  )
}

/* -------------------------------------------------------------------------- */
/* Rail                                                                        */
/* -------------------------------------------------------------------------- */

/**
 * The compact app rail: a 32px column on the page ground with the brand at the top and
 * a few controls pinned to the bottom. It has no surface of its own, so the backdrop shows
 * through, and it never expands. Use `AppShellSidebar` when the app needs labelled navigation.
 *
 * Geometry is the Figma frame's: a 32px column, 12px between its groups, the brand level
 * with the header's first row, the actions flush with no gap between them, and the account
 * mark below them.
 */
function AppShellRail({
  brand,
  actions,
  footer,
  className,
  ...props
}: React.ComponentProps<"nav"> & {
  /**
   * Mark at the top, in a 32px slot. Unsized artwork fills the slot; pass a `size-*` class to set
   * it yourself (the frame's mark is padded inside its 32px box, so `KalviumMark` wants `size-6.5`).
   * Link it home in the app, with an accessible name.
   */
  brand?: React.ReactNode
  /** Icon-only controls pinned to the bottom, one 32px square each. Each needs an accessible name. */
  actions?: React.ReactNode
  /** Below the actions, usually a small `Avatar` for the signed-in account. */
  footer?: React.ReactNode
}) {
  return (
    <nav
      data-slot="app-shell-rail"
      aria-label="Primary"
      className={cn("flex w-8 shrink-0 flex-col items-center gap-3 self-stretch pt-0.5 pb-1", className)}
      {...props}
    >
      {brand ? (
        <div
          data-slot="app-shell-rail-brand"
          className="flex size-8 shrink-0 items-center justify-center [&_img:not([class*='size-'])]:size-8 [&_svg:not([class*='size-'])]:size-8"
        >
          {brand}
        </div>
      ) : null}
      <div className="flex min-h-0 flex-1 flex-col items-center justify-end gap-3">
        {actions ? (
          <div data-slot="app-shell-rail-actions" className="flex flex-col items-center">
            {actions}
          </div>
        ) : null}
        {footer}
      </div>
    </nav>
  )
}

/**
 * One icon control in the rail: a ghost button, 32px square with the md radius and a 16px icon,
 * flush against the next one, with its name as a tooltip on the right. Icon-only, so `label` is required
 * and becomes the accessible name. `unread` adds the small dot and says so in the name.
 *
 * It mounts its own tooltip provider, so it works in a rail with no sidebar around it. Give it an
 * `href` (and your router's `linkComponent`) to make it a link instead of a button.
 */
function AppShellRailAction({
  label,
  icon,
  unread = false,
  href,
  linkComponent: Link = DefaultLink,
  className,
  ...props
}: Omit<React.ComponentProps<typeof Button>, "variant" | "size" | "asChild" | "children"> & {
  /** Visible in the tooltip and read out as the control's name. */
  label: string
  /** HugeIcons glyph. Sized by the action (16px), so pass it unsized. */
  icon: IconSvgElement
  /** Shows a small dot for something unread. */
  unread?: boolean
  /** Makes the action a link. */
  href?: string
  /** The app's router link, used when `href` is set. */
  linkComponent?: AppShellLink
}) {
  const name = unread ? `${label}, unread` : label
  const body = (
    <>
      <HugeiconsIcon icon={icon} strokeWidth={2} />
      {unread ? (
        <span
          aria-hidden="true"
          data-slot="app-shell-rail-action-dot"
          className="absolute top-1.5 right-1.5 size-2 rounded-full bg-sky-main ring-2 ring-background"
        />
      ) : null}
    </>
  )
  const classes = cn("relative rounded-md [&_svg:not([class*='size-'])]:size-4", className)

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          {href ? (
            <Button asChild variant="ghost" size="icon" data-slot="app-shell-rail-action" className={classes} {...props}>
              <Link href={href} aria-label={name}>
                {body}
              </Link>
            </Button>
          ) : (
            <Button
              type="button"
              variant="ghost"
              size="icon"
              data-slot="app-shell-rail-action"
              aria-label={name}
              className={classes}
              {...props}
            >
              {body}
            </Button>
          )}
        </TooltipTrigger>
        <TooltipContent side="right">{label}</TooltipContent>
      </Tooltip>
    </TooltipProvider>
  )
}

/**
 * The header's search, as the Figma frame draws it: an InputGroup with a search icon 10px in from the
 * edge, the placeholder, and the shortcut as separate key chips (⌘ and K) 6px apart. It is a trigger for a
 * command palette or a search surface, not a field: it is read-only, and click, Enter and Space call
 * `onOpen`. Pass it as the shell's `search`; the header holds it to 220px and collapses it to an icon when
 * the header is narrow. In dark mode the field takes the input tint over the page ground.
 *
 * Wiring the shortcut itself is the app's job. This only shows it.
 */
function AppShellSearch({
  placeholder = "Search...",
  shortcut = ["⌘", "K"],
  label = "Search",
  onOpen,
  className,
  ...props
}: Omit<React.ComponentProps<typeof InputGroupInput>, "readOnly" | "value" | "children"> & {
  placeholder?: string
  /** The keys of the shortcut, one chip each. An empty list hides the chips. */
  shortcut?: string[]
  /** Accessible name. Defaults to "Search". */
  label?: string
  /** Called on click, Enter or Space. */
  onOpen?: () => void
}) {
  return (
    <InputGroup data-slot="app-shell-search" className={className}>
      <InputGroupAddon className="pl-2.5">
        <HugeiconsIcon icon={Search01Icon} strokeWidth={2} />
      </InputGroupAddon>
      <InputGroupInput
        readOnly
        placeholder={placeholder}
        aria-label={label}
        className="cursor-pointer"
        onClick={onOpen}
        onKeyDown={(event) => {
          if (event.key === "Enter" || event.key === " ") {
            event.preventDefault()
            onOpen?.()
          }
        }}
        {...props}
      />
      {shortcut.length > 0 ? (
        <InputGroupAddon align="inline-end">
          <KbdGroup className="gap-1.5">
            {shortcut.map((key) => (
              <Kbd key={key}>{key}</Kbd>
            ))}
          </KbdGroup>
        </InputGroupAddon>
      ) : null}
    </InputGroup>
  )
}

/* -------------------------------------------------------------------------- */
/* Sidebar                                                                     */
/* -------------------------------------------------------------------------- */

type AppShellNavItem = {
  /** Visible label, and the tooltip shown when the sidebar collapses to a rail. */
  title: string
  /** Destination. Omit for a pure group header whose children carry the links. */
  url?: string
  /** HugeIcons glyph, per DESIGN.md §8.1. Sized by the sidebar, not by the caller. */
  icon?: IconSvgElement
  /** Nested links, revealed by a disclosure. Hidden while collapsed to the rail. */
  items?: { title: string; url: string }[]
}

type AppShellUserProfile = {
  name?: string
  email?: string
  /** Avatar image URL. Falls back to the name's initials. */
  avatar?: string
}

/** A row is active on an exact match, or when the path is a descendant of its url. */
function isNavItemActive(activePath: string, url?: string) {
  if (!url || !activePath) return false
  const current = activePath.replace(/\/+$/, "")
  const item = url.replace(/\/+$/, "")
  return current === item || current.startsWith(`${item}/`)
}

/**
 * Data-driven navigation for the sidebar. Rows with `items` render as a disclosure
 * that opens when one of its children is the active path; the rest are plain links.
 */
function AppShellNav({
  items,
  label,
  activePath = "",
  linkComponent: Link = DefaultLink,
  ...props
}: Omit<React.ComponentProps<typeof SidebarGroup>, "children"> & {
  items: AppShellNavItem[]
  /** Optional heading above the group. */
  label?: React.ReactNode
  /** Current route, used to mark the active row. */
  activePath?: string
  /** The app's router link. Defaults to a plain anchor. */
  linkComponent?: AppShellLink
}) {
  return (
    <SidebarGroup {...props}>
      {label ? <SidebarGroupLabel>{label}</SidebarGroupLabel> : null}
      <SidebarGroupContent>
        <SidebarMenu>
          {items.map((item) => {
            const active = isNavItemActive(activePath, item.url)
            const childActive = item.items?.some((sub) => isNavItemActive(activePath, sub.url))
            const glyph = item.icon ? (
              <HugeiconsIcon icon={item.icon} strokeWidth={2} />
            ) : null

            if (item.items?.length) {
              return (
                <Collapsible asChild key={item.title} defaultOpen={childActive} className="group/collapsible">
                  <SidebarMenuItem>
                    <CollapsibleTrigger asChild>
                      <SidebarMenuButton tooltip={item.title} isActive={active || childActive}>
                        {glyph}
                        <span>{item.title}</span>
                        <HugeiconsIcon
                          icon={ArrowDown01Icon}
                          strokeWidth={2}
                          className="ml-auto transition-transform group-data-[state=open]/collapsible:rotate-180"
                        />
                      </SidebarMenuButton>
                    </CollapsibleTrigger>
                    <CollapsibleContent>
                      <SidebarMenuSub>
                        {item.items.map((sub) => (
                          <SidebarMenuSubItem key={sub.title}>
                            <SidebarMenuSubButton asChild isActive={isNavItemActive(activePath, sub.url)}>
                              <Link href={sub.url}>{sub.title}</Link>
                            </SidebarMenuSubButton>
                          </SidebarMenuSubItem>
                        ))}
                      </SidebarMenuSub>
                    </CollapsibleContent>
                  </SidebarMenuItem>
                </Collapsible>
              )
            }

            return (
              <SidebarMenuItem key={item.title}>
                <SidebarMenuButton asChild={Boolean(item.url)} tooltip={item.title} isActive={active}>
                  {item.url ? (
                    <Link href={item.url}>
                      {glyph}
                      <span>{item.title}</span>
                    </Link>
                  ) : (
                    <>
                      {glyph}
                      <span>{item.title}</span>
                    </>
                  )}
                </SidebarMenuButton>
              </SidebarMenuItem>
            )
          })}
        </SidebarMenu>
      </SidebarGroupContent>
    </SidebarGroup>
  )
}

/**
 * The signed-in account row, for the sidebar footer. Collapses to just the avatar
 * on the icon rail, so it stays recognisable without the text.
 */
function AppShellUser({
  user,
  onSignOut,
  signOutLabel = "Sign out",
  ...props
}: Omit<React.ComponentProps<typeof SidebarMenuButton>, "children"> & {
  user: AppShellUserProfile
  /** Omit to render the row without a menu. */
  onSignOut?: () => void
  signOutLabel?: string
}) {
  const initials = (user.name ?? user.email ?? "?")
    .split(" ")
    .map((part) => part[0])
    .slice(0, 2)
    .join("")
    .toUpperCase()

  const row = (
    <SidebarMenuButton size="lg" {...props}>
      <Avatar className="size-8 rounded-lg">
        {user.avatar ? <AvatarImage src={user.avatar} alt="" /> : null}
        {/* text-foreground, not the Avatar default: muted-foreground on muted is 4.34:1, just under AA at
            this 12px size. */}
        <AvatarFallback className="rounded-lg text-xs text-foreground">{initials}</AvatarFallback>
      </Avatar>
      <div className="grid flex-1 text-left leading-tight">
        <span className="truncate text-sm font-medium">{user.name}</span>
        <span className="truncate text-xs text-muted-foreground">{user.email}</span>
      </div>
    </SidebarMenuButton>
  )

  return (
    <SidebarMenu>
      <SidebarMenuItem>
        {onSignOut ? (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>{row}</DropdownMenuTrigger>
            <DropdownMenuContent side="top" align="start" className="w-56">
              <DropdownMenuItem onClick={onSignOut}>
                <HugeiconsIcon icon={Logout01Icon} strokeWidth={2} />
                {signOutLabel}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        ) : (
          row
        )}
      </SidebarMenuItem>
    </SidebarMenu>
  )
}

/**
 * The app's primary navigation, collapsing to an icon rail. Modelled on the sidebar
 * the Livebooks app owns: a brand header, navigation, and the account row pinned to
 * the footer. Pass it to `AppShell`'s `sidebar` prop.
 */
function AppShellSidebar({
  brand,
  footer,
  children,
  ...props
}: React.ComponentProps<typeof Sidebar> & {
  /** Logo or wordmark for the header. */
  brand?: React.ReactNode
  /** Pinned to the bottom — usually an `AppShellUser`. */
  footer?: React.ReactNode
}) {
  return (
    // The sidebar is the app's primary navigation, so it is a navigation landmark. Without one, the
    // brand, the links and the account row sit outside every landmark and screen-reader users cannot
    // jump to them. Callers can override the role or label through props.
    <Sidebar collapsible="icon" role="navigation" aria-label="Primary" {...props}>
      {brand ? (
        <SidebarHeader data-slot="app-shell-sidebar-brand">
          <div className="flex h-12 items-center px-2 group-data-[collapsible=icon]:justify-center">
            {brand}
          </div>
        </SidebarHeader>
      ) : null}
      <SidebarContent>{children}</SidebarContent>
      {footer ? <SidebarFooter>{footer}</SidebarFooter> : null}
      <SidebarRail />
    </Sidebar>
  )
}

/* -------------------------------------------------------------------------- */
/* Assembled shell                                                             */
/* -------------------------------------------------------------------------- */

function AppShell({
  sidebar,
  defaultSidebarOpen = true,
  rail,
  logo,
  icon,
  title,
  href,
  linkComponent,
  actions,
  search,
  aside,
  asideTitle = "Filters",
  asideDescription = "Narrow what the canvas shows.",
  asideTriggerLabel = "Open filters",
  pattern,
  backgroundImage,
  className,
  children,
  ...props
}: React.ComponentProps<typeof AppShellRoot> & {
  /**
   * The app's primary navigation — usually an `AppShellSidebar`. When set the shell
   * wraps itself in a `SidebarProvider` and puts its own content in the inset, and
   * the header grows a trigger. Omit for a surface with no app chrome.
   */
  sidebar?: React.ReactNode
  /** Whether the sidebar starts expanded rather than collapsed to its icon rail. */
  defaultSidebarOpen?: boolean
  /**
   * The compact app rail — an `AppShellRail`. It sits beside the header and panel on the
   * page ground, and the header gains a divider after it. Use this or `sidebar`, not both.
   */
  rail?: React.ReactNode
  /** A logo in the header before the divider, for a surface with no rail to carry it. */
  logo?: React.ReactNode
  icon?: React.ReactNode | AppShellAsset
  title?: React.ReactNode
  href?: string
  /** The app's router link, used when `href` is set. Defaults to a plain anchor. */
  linkComponent?: AppShellLink
  actions?: React.ReactNode
  /**
   * The surface's search control. Collapses to an icon that opens a bottom sheet
   * once the header runs short of room, measured from the header's own width.
   */
  search?: React.ReactNode
  /** Secondary rail inside the panel. Omit for a full-width canvas. */
  aside?: React.ReactNode
  /** Accessible title for the rail's bottom sheet below `md`. */
  asideTitle?: React.ReactNode
  /** Supporting line under the sheet's title. */
  asideDescription?: React.ReactNode
  /** Accessible name for the icon-only button that opens the sheet. */
  asideTriggerLabel?: string
  pattern?: "dots" | "none"
}) {
  // Below md the rail is hidden, as in the app, and reached through a bottom sheet.
  // Drawer already caps itself at 80vh, so no height class is needed here.
  const asideSheet = aside ? (
    <Drawer>
      <DrawerTrigger asChild>
        <Button
          variant="outline"
          size="icon-sm"
          aria-label={asideTriggerLabel}
          className="md:hidden"
        >
          <HugeiconsIcon icon={Menu01Icon} strokeWidth={2} />
        </Button>
      </DrawerTrigger>
      <DrawerContent data-slot="app-shell-aside-sheet">
        <DrawerHeader className="text-left">
          <DrawerTitle>{asideTitle}</DrawerTitle>
          <DrawerDescription>{asideDescription}</DrawerDescription>
        </DrawerHeader>
        <div className="overflow-y-auto">{aside}</div>
      </DrawerContent>
    </Drawer>
  ) : null

  const header =
    sidebar || icon || title || actions || search || aside || logo || rail ? (
      <AppShellHeader
        leading={sidebar ? <SidebarTrigger /> : undefined}
        logo={logo}
        divider={Boolean(logo || rail)}
        icon={icon}
        title={title}
        href={href}
        linkComponent={linkComponent}
        search={search}
        actions={
          actions || asideSheet ? (
            <>
              {asideSheet}
              {actions}
            </>
          ) : undefined
        }
      />
    ) : null

  const panel = (
    <AppShellPanel pattern={pattern}>
      {aside ? <AppShellAside>{aside}</AppShellAside> : null}
      <AppShellCanvas>{children}</AppShellCanvas>
    </AppShellPanel>
  )

  const surface = (
    <AppShellRoot
      backgroundImage={backgroundImage}
      // With a rail the root is a row: the rail, then the header and panel as one column.
      className={cn(rail && "flex-row gap-4", className)}
      {...props}
    >
      {rail ? (
        <>
          {rail}
          <div data-slot="app-shell-body" className="flex min-h-0 min-w-0 flex-1 flex-col">
            {header}
            {panel}
          </div>
        </>
      ) : (
        <>
          {header}
          {panel}
        </>
      )}
    </AppShellRoot>
  )

  // Without a sidebar the shell is just the surface, so no provider is mounted and
  // nothing about the standalone layout changes.
  if (!sidebar) return surface

  return (
    // SidebarMenuButton renders a Tooltip on the collapsed rail, and SidebarProvider
    // does not supply a provider for it, so the shell brings its own.
    <TooltipProvider>
      <SidebarProvider defaultOpen={defaultSidebarOpen}>
        {sidebar}
        {/* SidebarInset is the page's `main`, which is why the canvas is only a div. */}
        <SidebarInset className="min-h-0 overflow-hidden">{surface}</SidebarInset>
      </SidebarProvider>
    </TooltipProvider>
  )
}

export {
  AppShell,
  AppShellRoot,
  AppShellHeader,
  AppShellPanel,
  AppShellAside,
  AppShellCanvas,
  AppShellRail,
  AppShellRailAction,
  AppShellSearch,
  AppShellSidebar,
  AppShellNav,
  AppShellUser,
  isNavItemActive,
  type AppShellLink,
  type AppShellLinkProps,
  type AppShellAsset,
  type AppShellNavItem,
  type AppShellUserProfile,
}
