"use client"

import * as React from "react"
import { HugeiconsIcon } from "@hugeicons/react"
import { Calendar03Icon } from "@hugeicons/core-free-icons"
import type { DateRange, Matcher } from "react-day-picker"

import { cn } from "@kalvi-education/katalyst/lib/utils"
import { Button } from "@kalvi-education/katalyst/components/button"
import { Calendar } from "@kalvi-education/katalyst/components/calendar"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@kalvi-education/katalyst/components/popover"

type DateRangePickerProps = Omit<
  React.ComponentProps<typeof Button>,
  "value" | "defaultValue" | "onChange" | "children"
> & {
  /** The selected range (controlled). Either end can be missing while a range is being picked. */
  value?: DateRange
  /** Initial range when uncontrolled. */
  defaultValue?: DateRange
  /** Called each time the range changes, including a half-picked range with only `from`. */
  onValueChange?: (range: DateRange | undefined) => void
  placeholder?: string
  /** What the range is for ("Report period"). Read out with the chosen dates, so the button never loses its value to a bare label. */
  label?: string
  /** Months shown side by side; they stack on narrow screens. */
  numberOfMonths?: 1 | 2
  /** Dates that cannot be picked: a Date, a range, or a function. */
  disabledDates?: Matcher | Matcher[]
  /** Earliest pickable day. */
  fromDate?: Date
  /** Latest pickable day. */
  toDate?: Date
  /** BCP 47 tag for the button text. Defaults to the viewer's locale. */
  locale?: string
}

function DateRangePicker({
  value: valueProp,
  defaultValue,
  onValueChange,
  placeholder = "Pick a date range",
  label: contextLabel,
  numberOfMonths = 2,
  disabledDates,
  fromDate,
  toDate,
  locale,
  className,
  disabled,
  ...props
}: DateRangePickerProps) {
  const [internal, setInternal] = React.useState<DateRange | undefined>(
    defaultValue
  )
  const [open, setOpen] = React.useState(false)
  const range = valueProp !== undefined ? valueProp : internal

  const format = React.useMemo(() => {
    const f = new Intl.DateTimeFormat(locale, {
      day: "2-digit",
      month: "short",
      year: "numeric",
    })
    return (d: Date) => f.format(d)
  }, [locale])

  const label = range?.from
    ? range.to
      ? `${format(range.from)} to ${format(range.to)}`
      : format(range.from)
    : null

  const matchers: Matcher[] = [
    ...(disabledDates ? ([] as Matcher[]).concat(disabledDates) : []),
    ...(fromDate ? [{ before: fromDate }] : []),
    ...(toDate ? [{ after: toDate }] : []),
  ]

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          type="button"
          variant="outline"
          data-slot="date-range-picker"
          data-empty={!label || undefined}
          aria-label={contextLabel ? `${contextLabel}, ${label ?? "none chosen"}` : undefined}
          disabled={disabled}
          className={cn(
            "w-64 justify-start text-left font-normal data-empty:text-muted-foreground",
            className
          )}
          {...props}
        >
          <HugeiconsIcon icon={Calendar03Icon} strokeWidth={2} data-icon="inline-start" />
          <span className="truncate tabular-nums">{label ?? placeholder}</span>
        </Button>
      </PopoverTrigger>
      <PopoverContent align="start" className="w-auto p-0">
        <Calendar
          mode="range"
          defaultMonth={range?.from}
          selected={range}
          onSelect={(next) => {
            if (valueProp === undefined) setInternal(next)
            onValueChange?.(next)
            if (next?.from && next?.to && next.to.getTime() !== next.from.getTime()) {
              setOpen(false)
            }
          }}
          numberOfMonths={numberOfMonths}
          disabled={matchers.length ? matchers : undefined}
        />
      </PopoverContent>
    </Popover>
  )
}

export { DateRangePicker }
export type { DateRange, DateRangePickerProps }
