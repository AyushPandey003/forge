"use client"

import * as React from "react"
import {
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
  type ColumnDef,
  type SortingState,
} from "@tanstack/react-table"
import { HugeiconsIcon } from "@hugeicons/react"
import {
  AlertCircleIcon,
  ArrowDown01Icon,
  ArrowLeft01Icon,
  ArrowRight01Icon,
  ArrowUp01Icon,
  ArrowUpDownIcon,
  Download04Icon,
  Search01Icon,
} from "@hugeicons/core-free-icons"

import { cn } from "@kalvi-education/katalyst/lib/utils"
import { saveCsv, toCsv } from "@kalvi-education/katalyst/lib/csv"
import { Alert, AlertAction, AlertDescription, AlertTitle } from "@kalvi-education/katalyst/components/alert"
import { Button } from "@kalvi-education/katalyst/components/button"
import {
  Empty,
  EmptyDescription,
  EmptyHeader,
  EmptyTitle,
} from "@kalvi-education/katalyst/components/empty"
import {
  InputGroup,
  InputGroupAddon,
  InputGroupInput,
} from "@kalvi-education/katalyst/components/input-group"
import { Skeleton } from "@kalvi-education/katalyst/components/skeleton"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@kalvi-education/katalyst/components/table"

type DataTableProps<TData> = Omit<React.ComponentProps<"div">, "children"> & {
  /** TanStack column definitions. Give a column `enableSorting: false` to take it out of sorting. */
  columns: ColumnDef<TData, any>[]
  data: TData[]
  /** Show a search box that filters across every column. */
  searchable?: boolean
  searchPlaceholder?: string
  /** Rows per page. Defaults to 10. */
  pageSize?: number
  /** Show an export button. The value is the downloaded file name without extension. */
  exportName?: string
  /** Show skeleton rows in place of the data. */
  loading?: boolean
  /** A failure to load. Shown above an empty table, with a retry when `onRetry` is given. */
  error?: React.ReactNode
  onRetry?: () => void
  emptyTitle?: string
  emptyDescription?: string
  /** Extra controls placed at the end of the toolbar. */
  toolbar?: React.ReactNode
  /** Accessible name for the table. */
  caption?: string
}

function SortIcon({ state }: { state: false | "asc" | "desc" }) {
  const icon = state === "asc" ? ArrowUp01Icon : state === "desc" ? ArrowDown01Icon : ArrowUpDownIcon
  return (
    <HugeiconsIcon
      icon={icon}
      strokeWidth={2}
      className={cn("size-3.5", state ? "text-foreground" : "text-muted-foreground")}
      data-icon="inline-end"
      aria-hidden
    />
  )
}

function DataTable<TData>({
  columns,
  data,
  searchable = false,
  searchPlaceholder = "Search",
  pageSize = 10,
  exportName,
  loading = false,
  error,
  onRetry,
  emptyTitle = "No results",
  emptyDescription = "Nothing matches yet. Change the search or add data.",
  toolbar,
  caption,
  className,
  ...props
}: DataTableProps<TData>) {
  const [sorting, setSorting] = React.useState<SortingState>([])
  const [query, setQuery] = React.useState("")

  const table = useReactTable({
    data,
    columns,
    state: { sorting, globalFilter: query },
    onSortingChange: setSorting,
    onGlobalFilterChange: setQuery,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    initialState: { pagination: { pageIndex: 0, pageSize } },
  })

  const rows = table.getRowModel().rows
  const filteredCount = table.getFilteredRowModel().rows.length
  const { pageIndex } = table.getState().pagination
  const pageCount = table.getPageCount()
  const first = filteredCount === 0 ? 0 : pageIndex * pageSize + 1
  const last = Math.min((pageIndex + 1) * pageSize, filteredCount)
  const columnCount = table.getVisibleLeafColumns().length

  const exportCsv = () => {
    const leaf = table.getVisibleLeafColumns()
    const headers = leaf.map((column) =>
      typeof column.columnDef.header === "string" ? column.columnDef.header : column.id
    )
    // The sorted model is built on the filtered one, so this is every row that matches, in the order shown.
    const body = table
      .getSortedRowModel()
      .rows.map((row) => leaf.map((column) => row.getValue(column.id)))
    saveCsv(`${exportName}.csv`, toCsv(headers, body))
  }

  return (
    <div data-slot="data-table" className={cn("flex flex-col gap-3", className)} {...props}>
      {(searchable || exportName || toolbar) && (
        <div className="flex flex-wrap items-center gap-2">
          {searchable && (
            <InputGroup className="max-w-xs">
              <InputGroupAddon>
                <HugeiconsIcon icon={Search01Icon} strokeWidth={2} />
              </InputGroupAddon>
              <InputGroupInput
                type="search"
                aria-label={searchPlaceholder}
                placeholder={`${searchPlaceholder}…`}
                value={query}
                autoComplete="off"
                spellCheck={false}
                onChange={(event) => {
                  setQuery(event.target.value)
                  table.setPageIndex(0)
                }}
              />
            </InputGroup>
          )}
          <div className="ml-auto flex items-center gap-2">
            {toolbar}
            {exportName && (
              <Button
                type="button"
                variant="outline"
                size="sm"
                disabled={loading || filteredCount === 0}
                onClick={exportCsv}
              >
                <HugeiconsIcon icon={Download04Icon} strokeWidth={2} data-icon="inline-start" />
                Export CSV
              </Button>
            )}
          </div>
        </div>
      )}

      {error && (
        <Alert variant="destructive">
          <HugeiconsIcon icon={AlertCircleIcon} strokeWidth={2} />
          <AlertTitle>The data could not be loaded</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
          {onRetry && (
            <AlertAction>
              <Button type="button" variant="outline" size="xs" onClick={onRetry}>
                Try again
              </Button>
            </AlertAction>
          )}
        </Alert>
      )}

      <div className="overflow-hidden rounded-lg border border-border">
        <Table aria-label={caption} aria-busy={loading || undefined}>
          <TableHeader>
            {table.getHeaderGroups().map((group) => (
              <TableRow key={group.id}>
                {group.headers.map((header) => {
                  const sorted = header.column.getIsSorted()
                  const sortable = header.column.getCanSort()
                  return (
                    <TableHead
                      key={header.id}
                      colSpan={header.colSpan}
                      aria-sort={
                        sorted === "asc" ? "ascending" : sorted === "desc" ? "descending" : undefined
                      }
                    >
                      {header.isPlaceholder ? null : sortable ? (
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="-ml-2.5 font-medium"
                          onClick={header.column.getToggleSortingHandler()}
                        >
                          {flexRender(header.column.columnDef.header, header.getContext())}
                          <SortIcon state={sorted} />
                        </Button>
                      ) : (
                        flexRender(header.column.columnDef.header, header.getContext())
                      )}
                    </TableHead>
                  )
                })}
              </TableRow>
            ))}
          </TableHeader>
          <TableBody>
            {loading ? (
              Array.from({ length: Math.min(pageSize, 5) }, (_, row) => (
                <TableRow key={row}>
                  {Array.from({ length: columnCount }, (_, cell) => (
                    <TableCell key={cell}>
                      <Skeleton className="h-4 w-full max-w-40" />
                    </TableCell>
                  ))}
                </TableRow>
              ))
            ) : rows.length ? (
              rows.map((row) => (
                <TableRow key={row.id} data-state={row.getIsSelected() ? "selected" : undefined}>
                  {row.getVisibleCells().map((cell) => (
                    <TableCell key={cell.id}>
                      {flexRender(cell.column.columnDef.cell, cell.getContext())}
                    </TableCell>
                  ))}
                </TableRow>
              ))
            ) : (
              <TableRow className="hover:bg-transparent">
                <TableCell colSpan={columnCount}>
                  <Empty className="border-0 py-10">
                    <EmptyHeader>
                      <EmptyTitle>{query ? "No matches" : emptyTitle}</EmptyTitle>
                      <EmptyDescription>
                        {query ? `Nothing matches “${query}”. Try a different search.` : emptyDescription}
                      </EmptyDescription>
                    </EmptyHeader>
                  </Empty>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      {!loading && filteredCount > 0 && (
        <div className="flex flex-wrap items-center justify-between gap-2 text-sm text-muted-foreground">
          <p className="tabular-nums" aria-live="polite">
            Showing {first} to {last} of {filteredCount}
          </p>
          {pageCount > 1 && (
            <div className="flex items-center gap-2">
              <span className="tabular-nums">
                Page {pageIndex + 1} of {pageCount}
              </span>
              <Button
                type="button"
                variant="outline"
                size="icon-sm"
                aria-label="Previous page"
                disabled={!table.getCanPreviousPage()}
                onClick={() => table.previousPage()}
              >
                <HugeiconsIcon icon={ArrowLeft01Icon} strokeWidth={2} />
              </Button>
              <Button
                type="button"
                variant="outline"
                size="icon-sm"
                aria-label="Next page"
                disabled={!table.getCanNextPage()}
                onClick={() => table.nextPage()}
              >
                <HugeiconsIcon icon={ArrowRight01Icon} strokeWidth={2} />
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

export { DataTable }
export type { ColumnDef, DataTableProps }
