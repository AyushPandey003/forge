"use client"

import * as React from "react"
import {
  type ColumnDef,
  type ColumnFiltersState,
  type ColumnPinningState,
  type ColumnResizeMode,
  type Row,
  type SortingState,
  type Updater,
  type VisibilityState,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
} from "@tanstack/react-table"
import { HugeiconsIcon } from "@hugeicons/react"
import {
  ArrowDown01Icon,
  ArrowLeft01Icon,
  ArrowRight01Icon,
  ArrowUp01Icon,
  ArrowUpDownIcon,
  Cancel02Icon,
  FilterHorizontalIcon,
  MoreHorizontalIcon,
  MoreVerticalIcon,
  Refresh01Icon,
  Search01Icon,
} from "@hugeicons/core-free-icons"
import { toast } from "sonner"

import { Badge } from "@kalvi-education/katalyst/components/badge"
import { Button } from "@kalvi-education/katalyst/components/button"
import { ButtonGroup } from "@kalvi-education/katalyst/components/button-group"
import { Checkbox } from "@kalvi-education/katalyst/components/checkbox"
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@kalvi-education/katalyst/components/dropdown-menu"
import { Empty, EmptyContent, EmptyDescription, EmptyHeader, EmptyMedia, EmptyTitle } from "@kalvi-education/katalyst/components/empty"
import { Input } from "@kalvi-education/katalyst/components/input"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@kalvi-education/katalyst/components/select"
import { Skeleton } from "@kalvi-education/katalyst/components/skeleton"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@kalvi-education/katalyst/components/dialog"
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetFooter,
  SheetHeader,
  SheetTitle,
} from "@kalvi-education/katalyst/components/sheet"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@kalvi-education/katalyst/components/table"
import { cn } from "@kalvi-education/katalyst/lib/utils"

export type SearchOperator =
  | "contains"
  | "equals"
  | "not_equals"
  | "startswith"
  | "endswith"
  | "gt"
  | "gte"
  | "lt"
  | "lte"
  | "between"
  | "in"
  | "not_in"
  | "is_null"
  | "is_not_null"

export interface SearchCriteria {
  id: string
  columnName: string
  columnOperator: SearchOperator
  columnValue: string | number | boolean | string[] | null | { from?: unknown; to?: unknown }
  isOrCondition?: boolean
  _quickSearch?: boolean
  _advancedSearch?: boolean
}

export interface SortCriteria {
  columnName: string
  columnOrder: "asc" | "desc"
}

export interface GridDataParams {
  gridId?: string
  page: number
  limit: number
  searchCriterias?: SearchCriteria[]
  sortCriterias?: SortCriteria[]
  select?: string
  dateRange?: Array<{ startDate: string | Date; endDate: string | Date }>
  dbName?: string
  tableName?: string
  schemaName?: string
  relations?: unknown
}

export interface GridPaginationResult<TData> {
  docs: TData[]
  pagination?: { total?: number; totalPages?: number }
  total?: number
  totalDocs?: number
  totalPages?: number
  page?: number
  limit?: number
}

export interface GridOptions {
  gridId: string
  dbName?: string
  schemaName?: string
  tableName: string
  sortCriterias?: SortCriteria[]
  searchCriterias?: SearchCriteria[]
  dateRange?: Array<{ startDate: string | Date; endDate: string | Date }>
  relations?: unknown
  page?: number
  limit?: number
  viewOptions?: Array<{ id: string; label: string; criteria?: SearchCriteria[] }>
}

export type GridColumnDef<TData> = ColumnDef<TData, unknown> & {
  accessorKey?: string
  id?: string
  header: ColumnDef<TData, unknown>["header"]
  dataType?: "string" | "number" | "datetime" | "boolean" | "display"
  show?: boolean
  searchable?: boolean
  sortable?: boolean
  pinned?: "left" | "right"
  searchOperator?: SearchOperator
}

/**
 * KalviGridV4 props.
 *
 * Interactions:
 * - Quick search applies on Enter and resets to page 1.
 * - Advanced filters apply from the filter panel and reset to page 1.
 * - Sorting, pagination, column visibility, column resize, pinning, refresh, export, and row selection are handled client-side while data operations stay server-driven via fetchData/exportData.
 * - Pagination/search/sort can be URL-synced unless disableQueryStatePagination/disableQueryState is set.
 *
 * Actions:
 * - fetchData receives GridDataParams for every load.
 * - exportData receives the same filters/sorts with page 1 and an effectively unlimited limit, and should return CSV content.
 * - selection callbacks receive selected row data keyed by primaryKeyField.
 */
export interface KalviGridRowAction<TData> {
  label: string
  onClick: (row: TData) => void
  disabled?: boolean | ((row: TData) => boolean)
}

export type KalviGridToolbarActionId = "refresh" | "advancedSearch" | "columns" | "import" | "export" | "clearFilters"

export interface KalviGridMenuActionsConfig {
  /**
   * Ceiling on how many toolbar actions stay as buttons. The grid may still show
   * fewer at narrow widths — the rest fold into the More menu. Omit for fully
   * automatic responsive overflow.
   */
  visibleButtons?: number
  /** Actions that should remain available in the More menu when hidden/overflowed. */
  moreMenuItems?: KalviGridToolbarActionId[]
}

export interface KalviGridV4Props<TData> {
  columns: GridColumnDef<TData>[]
  options?: GridOptions
  refresh?: boolean
  defaultQuickSearchColumn?: string
  fetchData: (params: GridDataParams) => Promise<GridPaginationResult<TData> | TData[]>
  exportData?: (params: GridDataParams) => Promise<string | undefined>
  enableSelection?: boolean
  /** Shows a checkbox selection column as the first column. Defaults to enableSelection. */
  checkbox?: boolean
  showCheckboxColumn?: boolean
  /** Enables/disables checkbox interactions while keeping the checkbox column visible. Defaults to true. */
  checkboxActive?: boolean
  checkboxSelectionActive?: boolean
  selectedRows?: Record<string, boolean>
  disableExport?: boolean
  disableImport?: boolean
  onImport?: () => void
  primaryKeyField?: keyof TData & string
  selectionMode?: "single" | "multiple"
  selectedRowsData?: TData[]
  setSelectedRowsData?: (selectedRows: TData[]) => void
  setRemovedRows?: React.Dispatch<React.SetStateAction<TData[]>> | ((rows: TData[]) => void)
  currentVisibleRows?: TData[]
  setCurrentVisibleRows?: (currentVisibleRows: TData[]) => void
  enableRowSelection?: (row: Row<TData>) => boolean
  disableQueryStatePagination?: boolean
  disableQueryState?: boolean
  gridSlug?: string
  emptyState?: React.ReactNode
  hideToolbarOnEmpty?: boolean
  rowActions?: KalviGridRowAction<TData>[]
  /** Makes the generated row-actions column sticky to the right. */
  lastColumnSticky?: boolean
  /**
   * Shows the footer bar (selection count, rows per page, page indicator, pager).
   * When false the footer is replaced by a centered "Load more" button that grows
   * the page size by the initial limit on each click. Defaults to true.
   */
  footer?: boolean
  /**
   * Column id (or accessorKey) treated as the row's primary column: moved to the
   * front of the grid and pinned left, so it is the first column, or the second
   * when the checkbox column is shown.
   */
  primaryColumn?: string
  /** Placeholder for the quick search input. Defaults to "Search for". */
  searchPlaceholder?: string
  /**
   * Illustration for the built-in zero state. Defaults to the empty-tray SVG.
   * Takes precedence over zeroStateImageUrl.
   */
  zeroStateImage?: React.ReactNode
  /** Image URL for the built-in zero state, used when zeroStateImage is not set. */
  zeroStateImageUrl?: string
  /** Message for the built-in zero state. Defaults to "No details available". */
  zeroStateText?: string
  /** Shows a call-to-action button under the zero-state message. Defaults to false. */
  zeroStateCta?: boolean
  /** Label for that button. Defaults to "Refresh". */
  zeroStateCtaLabel?: string
  /** Handler for that button. Falls back to reloading the grid. */
  onZeroStateCta?: () => void
  /** Controls responsive toolbar action overflow into the More menu. */
  menuActions?: KalviGridMenuActionsConfig
  variant?: "default" | "task-board" | "dashboard-01"
  density?: "default" | "comfortable" | "compact"
  className?: string
}

const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i
const DEFAULT_PAGE_SIZE_OPTIONS = [5, 10, 50, 100]

function makeId() {
  return Math.random().toString(36).slice(2, 9)
}

function getColumnId<TData>(column: GridColumnDef<TData>) {
  return column.id ?? column.accessorKey
}

function getHeaderLabel<TData>(column: GridColumnDef<TData>) {
  return typeof column.header === "string" ? column.header : (getColumnId(column) ?? "Column")
}

function getInitialNumberParam(key: string, fallback: number, disabled: boolean) {
  if (disabled || typeof window === "undefined") return fallback
  const value = Number(new URLSearchParams(window.location.search).get(key))
  return Number.isFinite(value) && value > 0 ? value : fallback
}

function writeUrlParams(updates: Record<string, string | number | null | undefined>, preserveSearch = true) {
  if (typeof window === "undefined") return
  const params = new URLSearchParams(window.location.search)
  Object.entries(updates).forEach(([key, value]) => {
    if (value === null || value === undefined || value === "") params.delete(key)
    else params.set(key, String(value))
  })
  if (!preserveSearch) {
    Array.from(params.keys()).forEach((key) => {
      if (key.startsWith("or[") || key.includes("__")) params.delete(key)
    })
  }
  const next = `${window.location.pathname}${params.toString() ? `?${params}` : ""}`
  window.history.replaceState(null, "", next)
}

function formatCriteria(criteria: SearchCriteria[], columns: GridColumnDef<unknown>[]): SearchCriteria[] {
  return criteria.map((criterion) => {
    const column = columns.find((col) => getColumnId(col) === criterion.columnName)
    const dataType = column?.dataType ?? "string"

    if (criterion.columnOperator === "is_null" || criterion.columnOperator === "is_not_null") {
      return { ...criterion, columnValue: null }
    }

    if (criterion.columnOperator === "between" && typeof criterion.columnValue === "object" && criterion.columnValue !== null && dataType === "datetime") {
      const value = { ...(criterion.columnValue as Record<string, unknown>) }
      if (typeof value.from === "string" && !Number.isNaN(Date.parse(value.from))) value.from = new Date(value.from)
      if (typeof value.to === "string" && !Number.isNaN(Date.parse(value.to))) value.to = new Date(value.to)
      return { ...criterion, columnValue: value }
    }

    if (dataType === "datetime" && typeof criterion.columnValue === "string" && !Number.isNaN(Date.parse(criterion.columnValue)) && !/^\d{4}-\d{2}-\d{2}$/.test(criterion.columnValue)) {
      return { ...criterion, columnValue: new Date(criterion.columnValue) as never }
    }

    return criterion
  })
}

function normalizeGridData<TData>(data: GridPaginationResult<TData> | TData[] | null) {
  if (Array.isArray(data)) return { docs: data, totalRecords: data.length, totalPages: 1 }
  const docs = data?.docs ?? []
  return {
    docs,
    totalRecords: data?.pagination?.total ?? data?.totalDocs ?? data?.total ?? docs.length,
    totalPages: data?.pagination?.totalPages ?? data?.totalPages ?? 1,
  }
}

function downloadCsv(csvContent: string, fileName = "data") {
  const safeFileName = fileName.replace(/\.csv$/i, "").replace(/[^a-z0-9-_]+/gi, "-").replace(/^-+|-+$/g, "")
  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
  const url = URL.createObjectURL(blob)
  const link = document.createElement("a")
  link.href = url
  link.download = `${safeFileName || "data"}.csv`
  link.style.display = "none"
  document.body.appendChild(link)
  link.click()
  link.remove()
  window.setTimeout(() => URL.revokeObjectURL(url), 0)
}

function convertToCSV(data: unknown[]): string {
  if (!data.length || typeof data[0] !== "object" || data[0] === null) return ""
  const headers = Object.keys(data[0] as Record<string, unknown>)
  const formatCell = (value: unknown) => {
    if (value === null || value === undefined) return "\"\""
    const stringValue = typeof value === "object" ? JSON.stringify(value) : String(value)
    return /[",\n\r]/.test(stringValue) ? `"${stringValue.replace(/\r?\n/g, " ").replace(/"/g, "\"\"")}"` : stringValue
  }
  return [headers.map(formatCell).join(","), ...data.map((row) => headers.map((header) => formatCell((row as Record<string, unknown>)[header])).join(","))].join("\n")
}

/**
 * Default zero-state illustration — the empty in-tray, exported verbatim from Figma
 * (file t4roEF44BkgLmIYpWWQsYl, node 43:1243, "Group 4041"). Fixed palette by design:
 * it is an illustration asset, and the light shape reads on both light and dark
 * surfaces. Swap it per-grid with the zeroStateImage / zeroStateImageUrl props.
 */
function ZeroStateIllustration() {
  return (
    <svg width="66.5" height="48" viewBox="0 0 66.5 47.9968" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" className="block">
      <g>
        <path d="M64 47.4968C65.1046 47.4968 66 46.6014 66 45.4968V29.9968H57.5H51.5704C50.9017 29.9968 50.2772 30.331 49.9063 30.8874L48.0937 33.6062C47.7228 34.1626 47.0983 34.4968 46.4296 34.4968H19.1768C18.4505 34.4968 17.7812 34.1031 17.4285 33.4681L16.0715 31.0256C15.7188 30.3906 15.0495 29.9968 14.3232 29.9968H8.5H0.5V45.4968C0.5 46.6014 1.39543 47.4968 2.5 47.4968H64Z" fill="#E3E3E3" />
        <path d="M66 29.9968L55 8.49685V21.9968L57.5 29.9968H66Z" fill="#E3E3E3" />
        <path d="M55 8.49685H11V21.9968H55V8.49685Z" fill="#E3E3E3" />
        <path d="M11 8.49685L0.5 29.9968H8.5L11 21.9968V8.49685Z" fill="#E3E3E3" />
        <path d="M55 21.9968H11L8.5 29.9968H14.3232C15.0495 29.9968 15.7188 30.3906 16.0715 31.0256L17.4285 33.4681C17.7812 34.1031 18.4505 34.4968 19.1768 34.4968H46.4296C47.0983 34.4968 47.7228 34.1626 48.0937 33.6062L49.9063 30.8874C50.2772 30.331 50.9017 29.9968 51.5704 29.9968H57.5L55 21.9968Z" fill="white" />
        <path d="M55 8.49685L66 29.9968V45.4968C66 46.6014 65.1046 47.4968 64 47.4968H2.5C1.39543 47.4968 0.5 46.6014 0.5 45.4968V29.9968L11 8.49685H55ZM0.5 29.9968H8.5M66 29.9968H57.5M11 8.49685V21.9968M55 8.49685V21.9968M55 21.9968H11M55 21.9968L57.5 29.9968M11 21.9968L8.5 29.9968M8.5 29.9968H14.3232C15.0495 29.9968 15.7188 30.3906 16.0715 31.0256L17.4285 33.4681C17.7812 34.1031 18.4505 34.4968 19.1768 34.4968H46.4296C47.0983 34.4968 47.7228 34.1626 48.0937 33.6062L49.9063 30.8874C50.2772 30.331 50.9017 29.9968 51.5704 29.9968H57.5" stroke="#BABABA" />
      </g>
      <g>
        <path d="M23.5 41.9969L28.5 42.9969H37.5L42.5 41.9969" stroke="#BABABA" />
        <circle cx="41" cy="41.9968" r="1.5" fill="#BABABA" />
        <circle cx="25" cy="41.9968" r="1.5" fill="#BABABA" />
      </g>
      <g>
        <path d="M8.12014 7.25559L5.60176 4.3994" stroke="#BABABA" strokeLinecap="round" />
        <path d="M12.8719 5.69674L13.2033 1.90331" stroke="#BABABA" strokeLinecap="round" />
        <path d="M10.3357 6.00069L8.77364 1.25097" stroke="#BABABA" strokeLinecap="round" />
      </g>
    </svg>
  )
}

function GridSkeleton() {
  return (
    <div className="space-y-2 rounded-lg border p-3">
      {Array.from({ length: 8 }).map((_, index) => (
        <Skeleton key={index} className="h-9 w-full" />
      ))}
    </div>
  )
}

interface ToolbarProps<TData> {
  searchableColumns: GridColumnDef<TData>[]
  quickSearchColumns: GridColumnDef<TData>[]
  searchColumn: string
  setSearchColumn: (value: string) => void
  searchText: string
  setSearchText: (value: string) => void
  searchPlaceholder: string
  applyQuickSearch: () => void
  clearSearch: () => void
  searchCriterias: SearchCriteria[]
  advancedSearchCriteria: SearchCriteria[]
  setAdvancedSearchCriteria: React.Dispatch<React.SetStateAction<SearchCriteria[]>>
  applyAdvancedSearch: (criteria: SearchCriteria[]) => void
  handleExport: () => void
  disableExport: boolean
  onImport?: () => void
  disableImport?: boolean
  menuActions?: KalviGridMenuActionsConfig
  handleRefresh: () => void
  isRefreshing: boolean
  table: ReturnType<typeof useReactTable<TData>>
  variant: "default" | "task-board" | "dashboard-01"
}

function GridToolbar<TData>({
  searchableColumns,
  quickSearchColumns,
  searchColumn,
  setSearchColumn,
  searchText,
  setSearchText,
  searchPlaceholder,
  applyQuickSearch,
  clearSearch,
  searchCriterias,
  advancedSearchCriteria,
  setAdvancedSearchCriteria,
  applyAdvancedSearch,
  handleExport,
  disableExport,
  onImport,
  disableImport,
  menuActions,
  handleRefresh,
  isRefreshing,
  table,
  variant,
}: ToolbarProps<TData>) {
  const [advancedOpen, setAdvancedOpen] = React.useState(false)
  const [mobileSearchOpen, setMobileSearchOpen] = React.useState(false)
  const [columnSearchText, setColumnSearchText] = React.useState("")

  const addAdvancedCriteria = () => {
    const columnName = searchableColumns[0] ? (getColumnId(searchableColumns[0]) ?? "") : ""
    setAdvancedSearchCriteria((criteria) => [
      ...criteria,
      { id: makeId(), columnName, columnOperator: "contains", columnValue: "", _advancedSearch: true },
    ])
  }

  const isTaskBoard = variant === "task-board"
  const isDashboard = variant === "dashboard-01"
  const hasActiveFilters = searchCriterias.some((criteria) => criteria._advancedSearch)
  const filteredHideableColumns = React.useMemo(() => {
    const query = columnSearchText.trim().toLowerCase()
    return table.getAllColumns().filter((column) => column.getCanHide() && (!query || column.id.toLowerCase().includes(query)))
  }, [columnSearchText, table])
  const toolbarRef = React.useRef<HTMLDivElement>(null)
  const toolbarActionIds = React.useMemo<KalviGridToolbarActionId[]>(() => {
    const actions: KalviGridToolbarActionId[] = []
    if (onImport) actions.push("import")
    if (!disableExport) actions.push("export")
    return actions
  }, [disableExport, onImport])
  // The toolbar degrades in stages rather than scrolling or clipping: the action
  // buttons fold into the More menu first, then the search collapses to an icon,
  // then the Columns button drops its label.
  const [layout, setLayout] = React.useState({ compactSearch: false, iconOnlyColumns: false, autoVisibleButtonCount: toolbarActionIds.length })
  React.useLayoutEffect(() => {
    const node = toolbarRef.current
    if (!node) return
    const calculate = () => {
      const width = node.getBoundingClientRect().width
      setLayout({
        compactSearch: width < 900,
        iconOnlyColumns: width < 720,
        autoVisibleButtonCount: width < 980 ? 0 : width < 1060 ? 1 : toolbarActionIds.length,
      })
    }
    calculate()
    const observer = new ResizeObserver(calculate)
    observer.observe(node)
    return () => observer.disconnect()
  }, [toolbarActionIds.length])
  const useCompactSearch = layout.compactSearch
  // visibleButtons is a ceiling, not a fixed count: it can only show fewer buttons
  // than the width allows, never force buttons to stay and overflow the toolbar.
  const autoVisibleButtonCount = menuActions?.visibleButtons === undefined
    ? layout.autoVisibleButtonCount
    : Math.min(menuActions.visibleButtons, layout.autoVisibleButtonCount)
  const visibleActionIds = React.useMemo<KalviGridToolbarActionId[]>(() => toolbarActionIds.slice(0, Math.max(0, autoVisibleButtonCount)), [autoVisibleButtonCount, toolbarActionIds])
  const overflowItemIds = React.useMemo<KalviGridToolbarActionId[]>(() => {
    const visible = new Set(visibleActionIds)
    const overflow = toolbarActionIds.filter((id) => !visible.has(id))
    const configured = menuActions?.moreMenuItems ?? []
    return Array.from(new Set([...overflow, ...configured])).filter((id) => id === "import" || id === "export" || id === "clearFilters")
  }, [menuActions?.moreMenuItems, toolbarActionIds, visibleActionIds])
  const isVisibleAction = (id: KalviGridToolbarActionId) => visibleActionIds.includes(id)
  const runToolbarAction = (id: KalviGridToolbarActionId) => {
    if (id === "refresh") handleRefresh()
    if (id === "advancedSearch") setAdvancedOpen(true)
    if (id === "import") onImport?.()
    if (id === "export") handleExport()
    if (id === "clearFilters") clearSearch()
  }
  const getToolbarActionLabel = (id: KalviGridToolbarActionId) => ({ refresh: "Refresh data", advancedSearch: "Advanced Search", columns: "Columns", import: "Import", export: "Export", clearFilters: "Clear filters" })[id]

  return (
    <div className={cn("space-y-3 py-2", (isTaskBoard || isDashboard) && "space-y-4 py-3")}>
      <div ref={toolbarRef} className="flex w-full min-w-0 flex-nowrap items-center gap-3 overflow-hidden">
        <div className="flex shrink-0 items-center gap-2">
          <Button variant="ghost" className={cn("h-8 justify-start px-0 text-sm font-medium text-foreground", isTaskBoard && "text-[15px]")}>All <HugeiconsIcon icon={ArrowDown01Icon} strokeWidth={1} className="size-3.5" /></Button>
        </div>
        <div className={cn("ml-auto flex items-center justify-end", useCompactSearch ? "shrink-0 basis-auto" : "min-w-[220px] shrink basis-[320px]", isDashboard && !useCompactSearch ? "md:basis-[320px] 2xl:basis-[420px]" : "") }>
          {useCompactSearch ? (
            <Button variant="outline" size="icon-sm" aria-label="Open search" onClick={() => setMobileSearchOpen(true)} className="h-8 w-8">
              <HugeiconsIcon icon={Search01Icon} strokeWidth={1} className="size-4" />
            </Button>
          ) : (
          <ButtonGroup className={cn("relative w-full min-w-0", isTaskBoard && "xl:max-w-[570px]")}> 
            <Select value={searchColumn} onValueChange={setSearchColumn}>
              <SelectTrigger aria-label="Search column" className={cn("h-8 w-full rounded-r-none border-r-0", isTaskBoard ? "sm:w-28" : "sm:w-40", isDashboard && "sm:w-36")}> 
                <SelectValue placeholder="Select column" />
              </SelectTrigger>
              <SelectContent>
                {quickSearchColumns.map((column) => {
                  const id = getColumnId(column)
                  if (!id) return null
                  return <SelectItem key={id} value={id}>{getHeaderLabel(column)}</SelectItem>
                })}
              </SelectContent>
            </Select>
            <Input
              aria-label="Quick search"
              placeholder={searchPlaceholder}
              value={searchText}
              onChange={(event) => setSearchText(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === "Enter") applyQuickSearch()
              }}
              className="h-8 min-w-0 flex-1 rounded-l-none border-l-0 pr-8"
            />
            <HugeiconsIcon icon={Search01Icon} strokeWidth={1} className="pointer-events-none absolute right-2 top-2 size-4 text-muted-foreground" />
          </ButtonGroup>
          )}
        </div>

        <div className="flex shrink-0 flex-nowrap items-center justify-end gap-2">
          <ButtonGroup>
            <Button variant="outline" size="icon-sm" onClick={() => setAdvancedOpen(true)} aria-label="Advanced filters" className="relative h-8 w-8">
              <HugeiconsIcon icon={FilterHorizontalIcon} strokeWidth={1} className="size-4" />
              {hasActiveFilters ? <span className="absolute right-1.5 top-1.5 size-1.5 rounded-full bg-primary" /> : null}
            </Button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" aria-label="Columns" className={cn("h-8 shrink-0 text-sm font-medium", layout.iconOnlyColumns ? "w-8 px-0" : "px-3", isTaskBoard ? "rounded-2xl text-[15px]" : "rounded-lg")}>
                  {layout.iconOnlyColumns ? null : "Columns"} <HugeiconsIcon icon={ArrowDown01Icon} strokeWidth={1} className="size-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <div className="p-1">
                  <Input
                    aria-label="Search columns"
                    placeholder="Search columns..."
                    value={columnSearchText}
                    onChange={(event) => setColumnSearchText(event.target.value)}
                    className="h-8"
                  />
                </div>
                <DropdownMenuSeparator />
                {filteredHideableColumns.length ? filteredHideableColumns.map((column) => (
                  <DropdownMenuCheckboxItem key={column.id} checked={column.getIsVisible()} onCheckedChange={(value) => column.toggleVisibility(Boolean(value))}>
                    {column.id}
                  </DropdownMenuCheckboxItem>
                )) : <DropdownMenuItem disabled>No columns found</DropdownMenuItem>}
              </DropdownMenuContent>
            </DropdownMenu>
          </ButtonGroup>
          <ButtonGroup>
            {onImport && isVisibleAction("import") ? (
              <Button variant="outline" size="sm" onClick={onImport} disabled={disableImport} className={cn("h-8 px-3 text-sm font-medium", isTaskBoard && "text-[15px]")}>
                Import
              </Button>
            ) : null}
            {!disableExport && isVisibleAction("export") ? (
              <Button variant="outline" size="sm" onClick={handleExport} className={cn("h-8 px-3 text-sm font-medium", isTaskBoard && "text-[15px]")}>
                Export
              </Button>
            ) : null}
            {overflowItemIds.length > 0 ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="icon-sm" aria-label="More actions" className="h-8 w-8">
                    <HugeiconsIcon icon={MoreHorizontalIcon} strokeWidth={1} className="size-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  {overflowItemIds.map((id) => {
                    if (id === "import" && !onImport) return null
                    if (id === "export" && disableExport) return null
                    return (
                      <DropdownMenuItem key={id} onClick={() => runToolbarAction(id)} disabled={(id === "import" && disableImport) || (id === "clearFilters" && searchCriterias.length === 0)}>
                        {getToolbarActionLabel(id)}
                      </DropdownMenuItem>
                    )
                  })}
                </DropdownMenuContent>
              </DropdownMenu>
            ) : null}
            <Button variant="outline" size="icon-lg" aria-label="Refresh grid" onClick={handleRefresh} disabled={isRefreshing} className={cn("size-8 p-0", isTaskBoard ? "rounded-2xl" : "rounded-lg")}>
              <HugeiconsIcon icon={Refresh01Icon} strokeWidth={1} className={cn("size-4", isRefreshing && "animate-spin")} />
            </Button>
          </ButtonGroup>
        </div>
      </div>

      <Sheet open={mobileSearchOpen} onOpenChange={setMobileSearchOpen}>
        <SheetContent side="bottom" className="gap-0 rounded-t-xl p-0">
          <SheetHeader className="border-b">
            <SheetTitle>Search</SheetTitle>
            <SheetDescription>Search within the selected column.</SheetDescription>
          </SheetHeader>
          <div className="space-y-3 p-4">
            <Select value={searchColumn} onValueChange={setSearchColumn}>
              <SelectTrigger aria-label="Search column" className="w-full"><SelectValue placeholder="Select column" /></SelectTrigger>
              <SelectContent>
                {quickSearchColumns.map((column) => {
                  const id = getColumnId(column)
                  if (!id) return null
                  return <SelectItem key={id} value={id}>{getHeaderLabel(column)}</SelectItem>
                })}
              </SelectContent>
            </Select>
            <Input
              aria-label="Quick search"
              placeholder={searchPlaceholder}
              value={searchText}
              onChange={(event) => setSearchText(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === "Enter") {
                  applyQuickSearch()
                  setMobileSearchOpen(false)
                }
              }}
            />
          </div>
          <SheetFooter>
            <Button variant="outline" size="sm" onClick={() => { clearSearch(); setMobileSearchOpen(false) }}>Clear</Button>
            <Button size="sm" onClick={() => { applyQuickSearch(); setMobileSearchOpen(false) }}>Search</Button>
          </SheetFooter>
        </SheetContent>
      </Sheet>

      <Dialog open={advancedOpen} onOpenChange={setAdvancedOpen}>
        <DialogContent className="max-h-[85vh] gap-0 overflow-hidden p-0 sm:max-w-2xl">
          <DialogHeader className="border-b px-5 py-4">
            <DialogTitle>Advanced filters</DialogTitle>
            <DialogDescription>Define one or more rules to narrow down the grid results.</DialogDescription>
          </DialogHeader>
          <div className="max-h-[58vh] space-y-3 overflow-auto p-5">
            {advancedSearchCriteria.map((criteria, index) => (
              <div key={criteria.id} className="grid gap-3 rounded-lg border bg-background p-3 md:grid-cols-[minmax(0,1fr)_150px_minmax(0,1fr)_auto] md:items-center">
                <Select value={criteria.columnName} onValueChange={(value) => setAdvancedSearchCriteria((items) => items.map((item, i) => i === index ? { ...item, columnName: value } : item))}>
                  <SelectTrigger aria-label="Filter column" className="w-full"><SelectValue placeholder="Column" /></SelectTrigger>
                  <SelectContent>
                    {searchableColumns.map((column) => {
                      const id = getColumnId(column)
                      if (!id) return null
                      return <SelectItem key={id} value={id}>{getHeaderLabel(column)}</SelectItem>
                    })}
                  </SelectContent>
                </Select>
                <Select value={criteria.columnOperator} onValueChange={(value) => setAdvancedSearchCriteria((items) => items.map((item, i) => i === index ? { ...item, columnOperator: value as SearchOperator } : item))}>
                  <SelectTrigger aria-label="Filter operator" className="w-full"><SelectValue placeholder="Operator" /></SelectTrigger>
                  <SelectContent>
                    {(["contains", "equals", "not_equals", "startswith", "endswith", "gt", "gte", "lt", "lte", "is_null", "is_not_null"] as SearchOperator[]).map((operator) => (
                      <SelectItem key={operator} value={operator}>{operator.replace(/_/g, " ")}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Input
                  aria-label="Filter value"
                  placeholder="Value"
                  value={typeof criteria.columnValue === "string" || typeof criteria.columnValue === "number" ? String(criteria.columnValue) : ""}
                  disabled={criteria.columnOperator === "is_null" || criteria.columnOperator === "is_not_null"}
                  onChange={(event) => setAdvancedSearchCriteria((items) => items.map((item, i) => i === index ? { ...item, columnValue: event.target.value } : item))}
                />
                <Button variant="ghost" size="icon-sm" aria-label="Remove filter" onClick={() => setAdvancedSearchCriteria((items) => items.filter((_, i) => i !== index))}>
                  <HugeiconsIcon icon={Cancel02Icon} strokeWidth={2} />
                </Button>
              </div>
            ))}
            {advancedSearchCriteria.length === 0 ? <div className="rounded-lg border border-dashed bg-muted/20 p-8 text-center text-sm text-muted-foreground">No filters added. Add a rule to begin filtering.</div> : null}
          </div>
          <DialogFooter className="m-0 rounded-none">
            <Button variant="outline" size="sm" onClick={addAdvancedCriteria}>Add filter</Button>
            <Button variant="outline" size="sm" onClick={() => { setAdvancedSearchCriteria([]); applyAdvancedSearch([]); setAdvancedOpen(false) }} disabled={!hasActiveFilters && advancedSearchCriteria.length === 0}>Clear filters</Button>
            <Button size="sm" onClick={() => { applyAdvancedSearch(advancedSearchCriteria); setAdvancedOpen(false) }}>Apply filters</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

export function KalviGridV4<TData extends Record<string, unknown>>({
  columns,
  options,
  refresh,
  defaultQuickSearchColumn,
  fetchData,
  exportData,
  enableSelection = false,
  checkbox,
  showCheckboxColumn,
  checkboxActive,
  checkboxSelectionActive = true,
  selectedRows = {},
  disableExport = false,
  primaryKeyField = "id" as keyof TData & string,
  selectionMode = "multiple",
  selectedRowsData = [],
  setSelectedRowsData,
  setRemovedRows,
  currentVisibleRows = [],
  setCurrentVisibleRows,
  enableRowSelection,
  disableQueryStatePagination = false,
  disableQueryState = false,
  emptyState,
  hideToolbarOnEmpty = false,
  disableImport = false,
  onImport,
  rowActions = [],
  lastColumnSticky = false,
  footer = true,
  primaryColumn,
  searchPlaceholder = "Search for",
  zeroStateImage,
  zeroStateImageUrl,
  zeroStateText,
  zeroStateCta = false,
  zeroStateCtaLabel = "Refresh",
  onZeroStateCta,
  menuActions,
  variant = "dashboard-01",
  density = "compact",
  className,
}: KalviGridV4Props<TData>) {
  const [isPending, startTransition] = React.useTransition()
  const shouldShowCheckboxColumn = checkbox ?? showCheckboxColumn ?? enableSelection
  const isCheckboxSelectionActive = checkboxActive ?? checkboxSelectionActive
  const disableUrlState = disableQueryState || disableQueryStatePagination
  const isTaskBoard = variant === "task-board"
  const isDashboard = variant === "dashboard-01"
  const densityClasses = {
    compact: {
      header: "h-11 px-3 text-sm",
      row: "h-12",
      cell: "px-3 py-2 text-sm",
      footer: "text-sm",
    },
    default: {
      header: "h-12 px-3.5 text-sm",
      row: "h-14",
      cell: "px-3.5 py-2.5 text-sm",
      footer: "text-sm",
    },
    comfortable: {
      header: isTaskBoard ? "h-[58px] px-4 text-[15px]" : isDashboard ? "h-10 px-2 text-sm" : "h-14 px-4 text-sm",
      row: isTaskBoard ? "h-[76px]" : isDashboard ? "h-[53px]" : "h-16",
      cell: isTaskBoard ? "px-4 py-3 text-[15px]" : isDashboard ? "px-2 py-2 text-sm" : "px-4 py-3 text-sm",
      footer: isTaskBoard ? "text-[15px]" : "text-sm",
    },
  }[density]

  const [searchCriterias, setSearchCriterias] = React.useState<SearchCriteria[]>([])
  const [searchText, setSearchText] = React.useState("")
  const [searchColumn, setSearchColumn] = React.useState(defaultQuickSearchColumn ?? "")
  const [advancedSearchCriteria, setAdvancedSearchCriteria] = React.useState<SearchCriteria[]>([])
  const [page, setPageState] = React.useState(() => getInitialNumberParam("page", options?.page ?? 1, disableUrlState))
  const [limit, setLimitState] = React.useState(() => getInitialNumberParam("pageSize", options?.limit ?? 50, disableUrlState))
  const basePageSizeRef = React.useRef(options?.limit ?? 50)
  const [sortCriterias, setSortCriterias] = React.useState<SortCriteria[]>(options?.sortCriterias ?? [])
  const [sorting, setSorting] = React.useState<SortingState>(() => (options?.sortCriterias ?? []).map((sort) => ({ id: sort.columnName, desc: sort.columnOrder === "desc" })))
  const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>([])
  const [columnResizeMode] = React.useState<ColumnResizeMode>("onChange")
  const [gridData, setGridData] = React.useState<GridPaginationResult<TData> | TData[] | null>(null)
  const [isLoading, setIsLoading] = React.useState(true)
  const [isLoadingMore, setIsLoadingMore] = React.useState(false)
  const hasLoadedOnceRef = React.useRef(false)
  const [error, setError] = React.useState<Error | null>(null)
  const [rowSelection, setRowSelection] = React.useState<Record<string, boolean>>(selectedRows)

  const [columnVisibility, setColumnVisibility] = React.useState<VisibilityState>(() => {
    const visibility: VisibilityState = {}
    columns.forEach((column) => {
      const id = getColumnId(column)
      if (id) visibility[id] = column.show !== false
    })
    return visibility
  })

  React.useEffect(() => {
    if (Object.keys(selectedRows).length > 0) setRowSelection(selectedRows)
  }, [selectedRows])

  const searchableColumns = React.useMemo(() => columns.filter((column) => column.searchable !== false && column.dataType !== "display" && typeof getColumnId(column) === "string"), [columns])
  const quickSearchColumns = React.useMemo(() => searchableColumns.filter((column) => column.dataType !== "datetime"), [searchableColumns])

  React.useEffect(() => {
    if (!searchColumn && quickSearchColumns[0]) setSearchColumn(getColumnId(quickSearchColumns[0]) ?? "")
  }, [quickSearchColumns, searchColumn])

  const setPage = React.useCallback((value: number) => {
    setPageState(value)
    if (!disableUrlState) writeUrlParams({ page: value })
  }, [disableUrlState])

  const setLimit = React.useCallback((value: number) => {
    setLimitState(value)
    if (!disableUrlState) writeUrlParams({ pageSize: value, page: 1 })
  }, [disableUrlState])

  const docs = React.useMemo(() => normalizeGridData(gridData).docs, [gridData])
  const totalRecords = normalizeGridData(gridData).totalRecords
  const totalPages = normalizeGridData(gridData).totalPages

  React.useEffect(() => {
    setCurrentVisibleRows?.(docs)
  }, [docs, setCurrentVisibleRows])

  const memoizedColumns = React.useMemo<ColumnDef<TData, unknown>[]>(() => {
    const normalized = columns.map((column) => ({
      ...column,
      enableSorting: column.sortable === false ? false : column.enableSorting,
    })) as ColumnDef<TData, unknown>[]

    if (primaryColumn) {
      const index = normalized.findIndex((column) => getColumnId(column as GridColumnDef<TData>) === primaryColumn)
      if (index > -1) {
        const [column] = normalized.splice(index, 1)
        const promoted: GridColumnDef<TData> = { ...(column as GridColumnDef<TData>), pinned: "left", enableHiding: false }
        normalized.unshift(promoted as ColumnDef<TData, unknown>)
      }
    }

    if (!shouldShowCheckboxColumn) return normalized

    return [
      {
        id: "select",
        header: ({ table }) => (
          <Checkbox
            checked={table.getIsAllPageRowsSelected() || (table.getIsSomePageRowsSelected() && "indeterminate")}
            onCheckedChange={(value) => table.toggleAllPageRowsSelected(Boolean(value))}
            disabled={!isCheckboxSelectionActive}
            aria-label="Select all rows"
          />
        ),
        cell: ({ row }) => (
          <Checkbox
            checked={row.getIsSelected()}
            disabled={!isCheckboxSelectionActive || !row.getCanSelect()}
            onCheckedChange={(value) => row.toggleSelected(Boolean(value))}
            aria-label="Select row"
          />
        ),
        enableSorting: false,
        enableHiding: false,
        size: 40,
      },
      ...normalized,
    ]
  }, [columns, isCheckboxSelectionActive, primaryColumn, shouldShowCheckboxColumn])

  const getInitialColumnPinning = React.useCallback((cols: ColumnDef<TData, unknown>[]): ColumnPinningState => {
    const left: string[] = []
    const right: string[] = []
    cols.forEach((column) => {
      const gridColumn = column as GridColumnDef<TData>
      const id = gridColumn.id ?? gridColumn.accessorKey
      if (!id) return
      if (id === "select") left.unshift(id)
      else if (gridColumn.pinned === "left") left.push(id)
      if (gridColumn.pinned === "right") right.push(id)
    })
    return { left, right }
  }, [])

  const [columnPinning, setColumnPinning] = React.useState<ColumnPinningState>(() => getInitialColumnPinning(memoizedColumns))

  React.useEffect(() => {
    setColumnPinning(getInitialColumnPinning(memoizedColumns))
  }, [getInitialColumnPinning, memoizedColumns])

  const buildParams = React.useCallback((override?: Partial<GridDataParams>): GridDataParams => ({
    gridId: options?.gridId,
    dbName: options?.dbName,
    tableName: options?.tableName,
    schemaName: options?.schemaName,
    relations: options?.relations,
    searchCriterias: formatCriteria([...(options?.searchCriterias ?? []), ...searchCriterias], columns as GridColumnDef<unknown>[]),
    page,
    limit,
    sortCriterias,
    dateRange: options?.dateRange,
    ...override,
  }), [columns, limit, options, page, searchCriterias, sortCriterias])

  const loadData = React.useCallback(async () => {
    setIsLoading(true)
    setError(null)
    try {
      const data = await fetchData(buildParams())
      setGridData(data)
    } catch (err) {
      const nextError = err instanceof Error ? err : new Error("Unknown error occurred")
      setError(nextError)
      toast.error(`Failed to fetch data: ${nextError.message}`)
    } finally {
      hasLoadedOnceRef.current = true
      setIsLoading(false)
      setIsLoadingMore(false)
    }
  }, [buildParams, fetchData])

  React.useEffect(() => {
    startTransition(() => {
      void loadData()
    })
  }, [loadData])

  React.useEffect(() => {
    if (refresh) startTransition(() => { void loadData() })
  }, [loadData, refresh])

  const handleSortingChange = React.useCallback((updaterOrValue: Updater<SortingState>) => {
    setSorting((current) => {
      const next = typeof updaterOrValue === "function" ? updaterOrValue(current) : updaterOrValue
      const nextCriteria = next.map((sort) => ({ columnName: sort.id, columnOrder: sort.desc ? "desc" : "asc" }) satisfies SortCriteria)
      setSortCriterias(nextCriteria)
      if (!disableUrlState) writeUrlParams({ sortBy: next.map((sort) => sort.id).join(","), sortOrder: next.map((sort) => sort.desc ? "desc" : "asc").join(",") })
      return next
    })
  }, [disableUrlState])

  const applyQuickSearch = React.useCallback(() => {
    if (!searchText.trim() || !searchColumn) {
      setSearchCriterias((criteria) => criteria.filter((item) => !item._quickSearch))
      return
    }

    const selectedColumn = columns.find((column) => getColumnId(column) === searchColumn)
    const dataType = selectedColumn?.dataType ?? "string"
    const trimmed = searchText.trim()
    let columnOperator: SearchOperator = selectedColumn?.searchOperator ?? "contains"
    let columnValue: SearchCriteria["columnValue"] = trimmed

    if (UUID_PATTERN.test(trimmed)) columnOperator = "equals"
    else if (dataType === "number") { columnOperator = "equals"; columnValue = Number(trimmed) }
    else if (dataType === "boolean") { columnOperator = "equals"; columnValue = trimmed.toLowerCase() === "true" }
    else if (dataType === "datetime" && !Number.isNaN(Date.parse(trimmed))) { columnOperator = "equals"; columnValue = new Date(trimmed) as never }

    setSearchCriterias((criteria) => [...criteria.filter((item) => !item._quickSearch), { id: makeId(), columnName: searchColumn, columnOperator, columnValue, _quickSearch: true }])
    setPage(1)
  }, [columns, searchColumn, searchText, setPage])

  const applyAdvancedSearch = React.useCallback((criteria: SearchCriteria[]) => {
    const normalized = criteria
      .filter((criterion) => criterion.columnName && (criterion.columnOperator === "is_null" || criterion.columnOperator === "is_not_null" || criterion.columnValue !== ""))
      .map((criterion) => ({ ...criterion, _advancedSearch: true }))
    setAdvancedSearchCriteria(normalized)
    setSearchCriterias((current) => [...current.filter((criterion) => criterion._quickSearch), ...normalized])
    setPage(1)
    toast.success(`Applied ${normalized.length} ${normalized.length === 1 ? "filter" : "filters"}`)
  }, [setPage])

  const clearSearch = React.useCallback(() => {
    setSearchCriterias([])
    setAdvancedSearchCriteria([])
    setSearchText("")
    setSearchColumn(defaultQuickSearchColumn ?? (quickSearchColumns[0] ? getColumnId(quickSearchColumns[0]) : "") ?? "")
    setPage(1)
    toast.success("Search filters cleared")
  }, [defaultQuickSearchColumn, quickSearchColumns, setPage])

  const handleExport = React.useCallback(async () => {
    try {
      const params = buildParams({ page: 1, limit: Number.MAX_SAFE_INTEGER })
      const csv = exportData ? await exportData(params) : convertToCSV(docs)
      if (!csv) return
      downloadCsv(csv, options?.tableName ?? options?.gridId ?? "data")
      toast.success("Data exported successfully")
    } catch (err) {
      toast.error(`Failed to export data: ${err instanceof Error ? err.message : "Unknown error"}`)
    }
  }, [buildParams, docs, exportData, options?.gridId, options?.tableName])

  const handleLoadMore = React.useCallback(() => {
    setIsLoadingMore(true)
    setLimit(limit + basePageSizeRef.current)
    setPage(1)
  }, [limit, setLimit, setPage])

  const handleRowSelectionData = React.useCallback((tableRows: Row<TData>[]) => {
    if (!setSelectedRowsData) return
    const currentSelectedRowsData = tableRows.map((row) => row.original)
    if (selectionMode === "single") {
      setSelectedRowsData(currentSelectedRowsData.slice(0, 1))
      return
    }

    const visibleKeys = new Set((currentVisibleRows.length ? currentVisibleRows : docs).map((row) => String(row[primaryKeyField])))
    const selectedKeys = new Set(selectedRowsData.map((row) => String(row[primaryKeyField])))
    const currentSelectedKeys = new Set(currentSelectedRowsData.map((row) => String(row[primaryKeyField])))
    const rowsToAdd = currentSelectedRowsData.filter((row) => visibleKeys.has(String(row[primaryKeyField])) && !selectedKeys.has(String(row[primaryKeyField])))
    const rowsToRemove = selectedRowsData.filter((row) => visibleKeys.has(String(row[primaryKeyField])) && !currentSelectedKeys.has(String(row[primaryKeyField])))
    const removedKeys = new Set(rowsToRemove.map((row) => String(row[primaryKeyField])))
    setSelectedRowsData([...selectedRowsData.filter((row) => !removedKeys.has(String(row[primaryKeyField]))), ...rowsToAdd])
    if (rowsToRemove.length && setRemovedRows) {
      if (typeof setRemovedRows === "function") {
        ;(setRemovedRows as React.Dispatch<React.SetStateAction<TData[]>>)((previous) => Array.isArray(previous) ? [...previous, ...rowsToRemove] : rowsToRemove)
      }
    }
  }, [currentVisibleRows, docs, primaryKeyField, selectedRowsData, selectionMode, setRemovedRows, setSelectedRowsData])

  const table = useReactTable({
    data: docs,
    columns: memoizedColumns,
    manualPagination: true,
    pageCount: totalPages,
    manualSorting: true,
    manualFiltering: true,
    columnResizeMode,
    enableColumnPinning: true,
    defaultColumn: { size: 150 },
    getRowId: (row) => String(row[primaryKeyField] ?? row.id),
    state: {
      sorting,
      columnFilters,
      columnVisibility,
      columnPinning,
      rowSelection,
      pagination: { pageIndex: page - 1, pageSize: limit },
    },
    onSortingChange: handleSortingChange,
    onColumnFiltersChange: setColumnFilters,
    onColumnVisibilityChange: setColumnVisibility,
    onColumnPinningChange: setColumnPinning,
    onRowSelectionChange: (updaterOrValue) => {
      setRowSelection((current) => {
        const updated = typeof updaterOrValue === "function" ? updaterOrValue(current) : updaterOrValue
        return selectionMode === "single" ? (Object.keys(updated).find((key) => updated[key]) ? { [Object.keys(updated).find((key) => updated[key]) as string]: true } : {}) : updated
      })
      window.setTimeout(() => handleRowSelectionData(table.getSelectedRowModel().rows), 0)
    },
    enableRowSelection: shouldShowCheckboxColumn && isCheckboxSelectionActive ? enableRowSelection : false,
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
  })

  const getPinnedStyles = React.useCallback((column: ReturnType<typeof table.getAllColumns>[number]) => {
    const pinned = column.getIsPinned()
    if (!pinned) return { style: { position: "relative" as const }, className: "" }
    const isLeft = pinned === "left"
    return {
      style: {
        position: "sticky" as const,
        left: isLeft ? `${column.getStart("left")}px` : undefined,
        right: !isLeft ? `${column.getStart("right")}px` : undefined,
        zIndex: isLeft ? 1 : 2,
      },
      className: cn(isLeft ? "sticky z-[1]" : "sticky z-[2] border-l border-border"),
    }
  }, [])

  const shouldShowCustomEmptyState = Boolean(emptyState) && !docs.length
  // Only the very first load gets the skeleton. Sorting, paging, searching and
  // load-more all refetch, and swapping the whole grid out each time reads as a
  // full page refresh — so those keep the current rows on screen and just dim.
  const showSkeleton = isLoading && !hasLoadedOnceRef.current
  const isRefetching = isLoading && hasLoadedOnceRef.current
  const hasMoreRows = docs.length < totalRecords
  // A zero state reached by searching says something different from a grid that is
  // simply empty — but an explicit zeroStateText always wins.
  const hasActiveSearch = searchCriterias.length > 0
  const zeroStateMessage = zeroStateText ?? (hasActiveSearch ? "No matching results!" : "No details available!")
  const showZeroState = !docs.length && !shouldShowCustomEmptyState

  return (
    <div className={cn("w-full", className)}>
      {!(hideToolbarOnEmpty && shouldShowCustomEmptyState) ? (
        <GridToolbar
          searchableColumns={searchableColumns}
          quickSearchColumns={quickSearchColumns}
          searchColumn={searchColumn}
          setSearchColumn={setSearchColumn}
          searchText={searchText}
          setSearchText={setSearchText}
          searchPlaceholder={searchPlaceholder}
          applyQuickSearch={applyQuickSearch}
          clearSearch={clearSearch}
          searchCriterias={searchCriterias}
          advancedSearchCriteria={advancedSearchCriteria}
          setAdvancedSearchCriteria={setAdvancedSearchCriteria}
          applyAdvancedSearch={applyAdvancedSearch}
          handleExport={handleExport}
          disableExport={disableExport || isPending}
          onImport={onImport}
          disableImport={disableImport}
          menuActions={menuActions}
          handleRefresh={() => startTransition(() => { void loadData() })}
          isRefreshing={isLoading || isPending}
          table={table}
          variant={variant}
        />
      ) : null}

      {showSkeleton ? <GridSkeleton /> : null}

      {!showSkeleton && error ? (
        <Empty className="min-h-40 border">
          <EmptyHeader>
            <EmptyMedia variant="icon"><HugeiconsIcon icon={Cancel02Icon} strokeWidth={2} /></EmptyMedia>
            <EmptyTitle>Error loading data</EmptyTitle>
            <EmptyDescription>{error.message}</EmptyDescription>
          </EmptyHeader>
        </Empty>
      ) : null}

      {!showSkeleton && !error && shouldShowCustomEmptyState ? emptyState : null}

      {!showSkeleton && !error && !shouldShowCustomEmptyState ? (
        <>
          {showZeroState ? (
            <Empty aria-busy={isRefetching} className={cn("min-h-[420px] justify-center border border-dashed transition-opacity", isRefetching && "opacity-60")}>
              <EmptyHeader>
                <EmptyMedia className="mb-6">
                  {zeroStateImage ?? (zeroStateImageUrl ? <img src={zeroStateImageUrl} alt="" className="h-12 w-auto object-contain" /> : <ZeroStateIllustration />)}
                </EmptyMedia>
                <EmptyDescription>{zeroStateMessage}</EmptyDescription>
              </EmptyHeader>
              {zeroStateCta ? (
                <EmptyContent>
                  <Button variant="outline" size="sm" onClick={onZeroStateCta ?? (() => startTransition(() => { void loadData() }))}>{zeroStateCtaLabel}</Button>
                </EmptyContent>
              ) : hasActiveSearch ? (
                <EmptyContent>
                  <Button variant="outline" size="sm" onClick={clearSearch}>Clear filters</Button>
                </EmptyContent>
              ) : null}
            </Empty>
          ) : (
          <div aria-busy={isRefetching} className={cn("w-full overflow-auto rounded-lg border transition-opacity", isDashboard && "overflow-hidden", isRefetching && "opacity-60")}>
            <Table className="w-max min-w-full">
              <TableHeader className={cn("sticky top-0 z-10 border-b", isDashboard ? "bg-muted" : "bg-background/95 shadow-sm backdrop-blur", isTaskBoard && "border-border/80")}> 
                {table.getHeaderGroups().map((headerGroup) => (
                  <TableRow key={headerGroup.id}>
                    {headerGroup.headers.map((header) => {
                      const pinned = getPinnedStyles(header.column)
                      const sortable = header.column.getCanSort()
                      // A non-sortable header can hold a control of its own (the select-all checkbox), so it
                      // must not be a button: interactive controls cannot nest.
                      const HeaderControl = sortable ? "button" : "div"
                      const sortDirection = header.column.getIsSorted()
                      const sortIcon = sortDirection === "asc" ? ArrowUp01Icon : sortDirection === "desc" ? ArrowDown01Icon : ArrowUpDownIcon
                      return (
                        <TableHead key={header.id} aria-sort={sortable ? (sortDirection === "asc" ? "ascending" : sortDirection === "desc" ? "descending" : "none") : undefined} style={{ width: `${header.getSize()}px`, minWidth: `${header.getSize()}px`, ...pinned.style }} className={cn(densityClasses.header, "font-medium text-muted-foreground", isDashboard && "bg-muted", pinned.className)}> 
                          <HeaderControl
                            {...(sortable ? { type: "button" as const } : {})}
                            className={cn("flex w-full items-center text-left", sortable ? "cursor-pointer select-none" : "cursor-default", isDashboard && "gap-1")} 
                            onClick={sortable ? header.column.getToggleSortingHandler() : undefined}
                          >
                            {header.isPlaceholder ? null : flexRender(header.column.columnDef.header, header.getContext())}
                            {sortable ? <HugeiconsIcon icon={sortIcon} strokeWidth={sortDirection ? 2 : 1} className={cn(sortDirection ? "text-foreground" : "text-muted-foreground", isDashboard ? "ml-1 size-3.5" : "ml-2 size-4")} /> : null}
                          </HeaderControl>
                          <div
                            onMouseDown={header.getResizeHandler()}
                            onTouchStart={header.getResizeHandler()}
                            className={cn("absolute right-0 top-0 h-full w-px cursor-col-resize select-none touch-none", header.column.getIsResizing() ? "bg-primary" : "bg-border")} 
                          />
                        </TableHead>
                      )
                    })}
                    {rowActions.length > 0 ? (
                      <TableHead className={cn(densityClasses.header, "w-[52px] bg-muted text-right font-medium text-muted-foreground", lastColumnSticky && "sticky right-0 z-[3] border-l border-border")}>
                        <span className="sr-only">Actions</span>
                      </TableHead>
                    ) : null}
                  </TableRow>
                ))}
              </TableHeader>
              <TableBody>
                {table.getRowModel().rows.length ? table.getRowModel().rows.map((row) => (
                  <TableRow key={row.id} data-state={row.getIsSelected() ? "selected" : undefined} className={cn(densityClasses.row, "border-b border-border/70 hover:bg-muted/10")}>
                    {row.getVisibleCells().map((cell) => {
                      const pinned = getPinnedStyles(cell.column)
                      return (
                        <TableCell key={cell.id} style={{ width: `${cell.column.getSize()}px`, minWidth: `${cell.column.getSize()}px`, ...pinned.style }} className={cn(densityClasses.cell, pinned.className, pinned.className && "bg-background")}> 
                          {flexRender(cell.column.columnDef.cell, cell.getContext())}
                        </TableCell>
                      )
                    })}
                    {rowActions.length > 0 ? (
                      <TableCell className={cn("w-[52px] bg-background text-right", densityClasses.cell, lastColumnSticky && "sticky right-0 z-[3] border-l border-border")}>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon-sm" aria-label="Row actions" className="size-7 text-muted-foreground hover:bg-transparent data-[state=open]:bg-muted">
                              <HugeiconsIcon icon={isDashboard ? MoreVerticalIcon : MoreHorizontalIcon} strokeWidth={1} className="size-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="w-40">
                            {rowActions.map((action) => {
                              const disabled = typeof action.disabled === "function" ? action.disabled(row.original) : action.disabled
                              return (
                                <DropdownMenuItem key={action.label} disabled={disabled} onClick={() => action.onClick(row.original)}>
                                  {action.label}
                                </DropdownMenuItem>
                              )
                            })}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    ) : null}
                  </TableRow>
                )) : (
                  <TableRow>
                    <TableCell colSpan={memoizedColumns.length + (rowActions.length > 0 ? 1 : 0)} className="h-24 text-center text-muted-foreground">{zeroStateMessage}</TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
          )}

          {footer ? (
          <div className={cn("flex flex-col gap-3 md:flex-row md:items-center md:justify-between", isDashboard ? "px-4 py-4" : "py-5")}>
            <div className={cn(densityClasses.footer, "text-muted-foreground")}>{Object.keys(rowSelection).filter((key) => rowSelection[key]).length} of {totalRecords} row(s) selected.</div>
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
              <div className={cn("flex items-center gap-3 text-muted-foreground", densityClasses.footer)}>
                <span>Rows per page</span>
                <Select value={String(limit)} onValueChange={(value) => { setLimit(Number(value)); setPage(1) }}>
                  <SelectTrigger aria-label="Rows per page" className={cn("h-8 w-20", isDashboard ? "rounded-lg" : "rounded-2xl")}><SelectValue placeholder="Rows per page" /></SelectTrigger>
                  <SelectContent>
                    {DEFAULT_PAGE_SIZE_OPTIONS.map((size) => <SelectItem key={size} value={String(size)}>{size}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className={cn(densityClasses.footer, "text-muted-foreground")}>Page {page} of {totalPages || 1}</div>
              <div className="flex gap-2">
                <Button variant="outline" size="icon-sm" className="hidden lg:flex" disabled={page === 1} onClick={() => setPage(1)} aria-label="First page">‹‹</Button>
                <Button variant="outline" size="icon-sm" disabled={page === 1} onClick={() => setPage(Math.max(1, page - 1))} aria-label="Previous page">
                  <HugeiconsIcon icon={ArrowLeft01Icon} strokeWidth={1} className="size-4" />
                </Button>
                <Button variant="outline" size="icon-sm" disabled={page >= totalPages} onClick={() => setPage(page + 1)} aria-label="Next page">
                  <HugeiconsIcon icon={ArrowRight01Icon} strokeWidth={1} className="size-4" />
                </Button>
                <Button variant="outline" size="icon-sm" className="hidden lg:flex" disabled={page >= totalPages} onClick={() => setPage(totalPages)} aria-label="Last page">››</Button>
              </div>
            </div>
          </div>
          ) : hasMoreRows ? (
            <div className={cn("flex justify-center", isDashboard ? "px-4 py-4" : "py-5")}>
              <Button variant="outline" size="sm" onClick={handleLoadMore} disabled={isLoadingMore} className={cn(densityClasses.footer, "h-8 px-4 font-medium")}>
                {isLoadingMore ? <HugeiconsIcon icon={Refresh01Icon} strokeWidth={1} className="size-4 animate-spin" /> : null}
                Load more
              </Button>
            </div>
          ) : null}
        </>
      ) : null}
    </div>
  )
}

export { convertToCSV, downloadCsv }
