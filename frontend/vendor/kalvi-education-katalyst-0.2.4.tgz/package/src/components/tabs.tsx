"use client"

import * as React from "react"
import { cva, type VariantProps } from "class-variance-authority"
import { Tabs as TabsPrimitive } from "radix-ui"

import { cn } from "@kalvi-education/katalyst/lib/utils"

/** Which tab is active and which have been opened, for `TabsContent keepMounted`. */
const TabsStateContext = React.createContext<{ value?: string; opened: Set<string> } | null>(null)

function readParam(name: string): string | null {
  try {
    return new URLSearchParams(window.location.search).get(name)
  } catch {
    return null
  }
}

function writeParam(name: string, value: string) {
  try {
    const url = new URL(window.location.href)
    url.searchParams.set(name, value)
    window.history.replaceState(window.history.state, "", url)
  } catch {
    // A sandboxed frame can refuse history changes; the tab still switches.
  }
}

function Tabs({
  className,
  orientation = "horizontal",
  value: valueProp,
  defaultValue,
  onValueChange,
  urlParam,
  ...props
}: React.ComponentProps<typeof TabsPrimitive.Root> & {
  /**
   * Keep the active tab in this query parameter (for example `tab`), so a refresh, a shared link and the Back
   * button restore it. A value with no enabled trigger is ignored.
   */
  urlParam?: string
}) {
  const rootRef = React.useRef<HTMLDivElement>(null)
  const [internal, setInternal] = React.useState(defaultValue)
  const value = valueProp ?? internal
  const [opened, setOpened] = React.useState<Set<string>>(() => new Set(value ? [value] : []))

  const change = React.useCallback(
    (next: string) => {
      if (valueProp === undefined) setInternal(next)
      if (urlParam) writeParam(urlParam, next)
      onValueChange?.(next)
    },
    [valueProp, urlParam, onValueChange]
  )

  // Read the URL after mount so server and client render the same first frame.
  React.useEffect(() => {
    if (!urlParam) return
    const apply = () => {
      const fromUrl = readParam(urlParam)
      if (!fromUrl || !rootRef.current) return
      const trigger = rootRef.current.querySelector(
        `[data-slot="tabs-trigger"][data-value="${CSS.escape(fromUrl)}"]:not(:disabled)`
      )
      if (!trigger) return
      if (valueProp === undefined) setInternal(fromUrl)
      else if (fromUrl !== valueProp) onValueChange?.(fromUrl)
    }
    apply()
    window.addEventListener("popstate", apply)
    return () => window.removeEventListener("popstate", apply)
    // Only the parameter decides when to re-read; the handlers read the latest props.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [urlParam])

  React.useEffect(() => {
    if (!value) return
    setOpened((previous) => (previous.has(value) ? previous : new Set(previous).add(value)))
  }, [value])

  return (
    <TabsStateContext.Provider value={{ value, opened }}>
      <TabsPrimitive.Root
        ref={rootRef}
        data-slot="tabs"
        data-orientation={orientation}
        orientation={orientation}
        value={value}
        onValueChange={change}
        className={cn(
          "group/tabs flex gap-2 data-horizontal:flex-col",
          className
        )}
        {...props}
      />
    </TabsStateContext.Provider>
  )
}

const tabsListVariants = cva(
  "group/tabs-list inline-flex w-fit items-center justify-center rounded-lg p-[3px] text-muted-foreground group-data-horizontal/tabs:h-8 group-data-vertical/tabs:h-fit group-data-vertical/tabs:flex-col group-data-vertical/tabs:items-stretch data-[variant=line]:rounded-none",
  {
    variants: {
      variant: {
        default: "bg-muted",
        line: "gap-1 bg-transparent group-data-vertical/tabs:border-r group-data-vertical/tabs:border-border group-data-vertical/tabs:pr-1",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  }
)

function TabsList({
  className,
  variant = "default",
  ...props
}: React.ComponentProps<typeof TabsPrimitive.List> &
  VariantProps<typeof tabsListVariants>) {
  return (
    <TabsPrimitive.List
      data-slot="tabs-list"
      data-variant={variant}
      className={cn(tabsListVariants({ variant }), className)}
      {...props}
    />
  )
}

/** True when the children hold no text, so the trigger shows an icon alone. */
function hasNoText(children: React.ReactNode) {
  return React.Children.toArray(children).every(
    (child) => typeof child !== "string" && typeof child !== "number"
  )
}

/**
 * A trigger with an `aria-label` and no text children renders as a square icon tab. The label is also shown as
 * the native tooltip.
 */
function TabsTrigger({
  className,
  children,
  title,
  ...props
}: React.ComponentProps<typeof TabsPrimitive.Trigger>) {
  const label = props["aria-label"]
  const iconOnly = Boolean(label) && hasNoText(children)

  return (
    <TabsPrimitive.Trigger
      data-slot="tabs-trigger"
      data-value={props.value}
      data-icon-only={iconOnly || undefined}
      title={title ?? (iconOnly ? label : undefined)}
      className={cn(
        "group/tabs-trigger relative inline-flex h-[calc(100%-1px)] flex-1 items-center justify-center gap-1.5 rounded-md border border-transparent px-1.5 py-0.5 text-sm font-medium whitespace-nowrap text-foreground/60 transition-all group-data-vertical/tabs:w-full group-data-vertical/tabs:justify-start group-data-vertical/tabs:px-2 group-data-vertical/tabs:py-1.5 hover:text-foreground focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50 focus-visible:outline-1 focus-visible:outline-ring disabled:pointer-events-none disabled:opacity-50 has-data-[icon=inline-end]:pr-1 has-data-[icon=inline-start]:pl-1 dark:text-muted-foreground dark:hover:text-foreground group-data-[variant=default]/tabs-list:data-active:shadow-sm group-data-[variant=line]/tabs-list:data-active:shadow-none [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",
        "data-icon-only:aspect-square data-icon-only:flex-none data-icon-only:px-0 group-data-vertical/tabs:data-icon-only:w-auto group-data-vertical/tabs:data-icon-only:justify-center group-data-vertical/tabs:data-icon-only:px-0",
        "group-data-[variant=line]/tabs-list:bg-transparent group-data-[variant=line]/tabs-list:data-active:bg-transparent dark:group-data-[variant=line]/tabs-list:data-active:border-transparent dark:group-data-[variant=line]/tabs-list:data-active:bg-transparent group-data-[variant=line]/tabs-list:hover:bg-muted/60",
        "data-active:bg-background data-active:text-foreground dark:data-active:border-input dark:data-active:bg-input/30 dark:data-active:text-foreground",
        "after:absolute after:bg-foreground after:opacity-0 after:transition-opacity group-data-horizontal/tabs:after:inset-x-0 group-data-horizontal/tabs:after:bottom-[-5px] group-data-horizontal/tabs:after:h-0.5 group-data-vertical/tabs:after:inset-y-0 group-data-vertical/tabs:after:-right-[5px] group-data-vertical/tabs:after:w-0.5 group-data-[variant=line]/tabs-list:data-active:after:opacity-100",
        className
      )}
      {...props}
    >
      {children}
    </TabsPrimitive.Trigger>
  )
}

/** A count or short status after a trigger's label. It turns solid on the active tab. */
function TabsBadge({ className, ...props }: React.ComponentProps<"span">) {
  return (
    <span
      data-slot="tabs-badge"
      className={cn(
        "inline-flex h-4.5 min-w-4.5 items-center justify-center rounded-full bg-foreground/8 px-1.5 text-[11px] leading-none font-medium text-muted-foreground tabular-nums transition-colors group-data-active/tabs-trigger:bg-primary group-data-active/tabs-trigger:text-primary-foreground",
        className
      )}
      {...props}
    />
  )
}

function TabsContent({
  className,
  keepMounted = false,
  forceMount,
  value,
  ...props
}: React.ComponentProps<typeof TabsPrimitive.Content> & {
  /**
   * Mount the panel the first time it opens and keep it mounted (hidden) after, so its state, scroll and
   * fetched data survive a switch. Panels without it unmount when they close.
   */
  keepMounted?: boolean
}) {
  const state = React.useContext(TabsStateContext)
  const keep = keepMounted && (state?.opened.has(value) || state?.value === value)

  return (
    <TabsPrimitive.Content
      data-slot="tabs-content"
      value={value}
      forceMount={keep ? true : forceMount}
      className={cn("flex-1 text-sm outline-none data-[state=inactive]:hidden", className)}
      {...props}
    />
  )
}

export { Tabs, TabsList, TabsTrigger, TabsBadge, TabsContent, tabsListVariants }
