"use client"

import * as React from "react"
import { HugeiconsIcon } from "@hugeicons/react"
import {
  Add01Icon,
  ArrowDown01Icon,
  Cancel01Icon,
} from "@hugeicons/core-free-icons"

import { cn } from "@kalvi-education/katalyst/lib/utils"
import { Badge } from "@kalvi-education/katalyst/components/badge"
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@kalvi-education/katalyst/components/command"
import {
  Popover,
  PopoverAnchor,
  PopoverContent,
  PopoverTrigger,
} from "@kalvi-education/katalyst/components/popover"

type MultiSelectOption = {
  value: string
  label?: string
  disabled?: boolean
}

type MultiSelectProps = Omit<
  React.ComponentProps<"div">,
  "defaultValue" | "onChange" | "children"
> & {
  /** The choices. A bare string is both the value and the label. */
  options: Array<string | MultiSelectOption>
  /** Selected values (controlled). */
  value?: string[]
  /** Initial selection when uncontrolled. */
  defaultValue?: string[]
  /** Called with the full next selection whenever it changes. */
  onValueChange?: (value: string[]) => void
  placeholder?: string
  searchPlaceholder?: string
  emptyText?: string
  /** How many chips show before the rest collapse into a "+N more" chip. */
  maxVisible?: number
  /** Let people add a value that is not in `options` by typing it. */
  allowCreate?: boolean
  disabled?: boolean
  invalid?: boolean
  /** Id for the trigger, so a `Field` label can point at it. */
  id?: string
  "aria-label"?: string
}

function normalize(option: string | MultiSelectOption): MultiSelectOption {
  return typeof option === "string" ? { value: option, label: option } : option
}

function MultiSelect({
  options,
  value: valueProp,
  defaultValue = [],
  onValueChange,
  placeholder = "Select values",
  searchPlaceholder = "Search…",
  emptyText = "No results found.",
  maxVisible = 3,
  allowCreate = false,
  disabled = false,
  invalid = false,
  id,
  "aria-label": ariaLabel,
  className,
  ...props
}: MultiSelectProps) {
  const [internal, setInternal] = React.useState<string[]>(defaultValue)
  const [open, setOpen] = React.useState(false)
  const [query, setQuery] = React.useState("")
  const [showAll, setShowAll] = React.useState(false)

  const selected = valueProp ?? internal
  const known = React.useMemo(() => options.map(normalize), [options])
  const labelFor = (value: string) =>
    known.find((o) => o.value === value)?.label ?? value

  const commit = (next: string[]) => {
    if (valueProp === undefined) setInternal(next)
    onValueChange?.(next)
  }
  const toggle = (value: string) =>
    commit(
      selected.includes(value)
        ? selected.filter((v) => v !== value)
        : [...selected, value]
    )

  const trimmed = query.trim()
  const canCreate =
    allowCreate &&
    trimmed.length > 0 &&
    !known.some((o) => o.value.toLowerCase() === trimmed.toLowerCase()) &&
    !selected.some((v) => v.toLowerCase() === trimmed.toLowerCase())

  const visible = showAll ? selected : selected.slice(0, maxVisible)
  const hidden = selected.length - visible.length

  return (
    <Popover
      open={open}
      onOpenChange={(next) => {
        setOpen(next)
        if (!next) setQuery("")
      }}
    >
      <PopoverAnchor asChild>
        <div
          data-slot="multi-select"
          data-disabled={disabled || undefined}
          aria-invalid={invalid || undefined}
          className={cn(
            "flex min-h-8 w-full flex-wrap items-center gap-1 rounded-lg border border-input bg-transparent px-1.5 py-1 text-sm transition-colors focus-within:border-ring focus-within:ring-3 focus-within:ring-ring/50 aria-invalid:border-destructive aria-invalid:ring-3 aria-invalid:ring-destructive/20 data-disabled:pointer-events-none data-disabled:opacity-50 dark:bg-input/30 dark:aria-invalid:border-destructive/50 dark:aria-invalid:ring-destructive/40",
            className
          )}
          {...props}
        >
          {visible.map((value) => (
            <Badge
              key={value}
              variant="secondary"
              data-slot="multi-select-chip"
              className="h-6 gap-1 pr-1"
            >
              <span className="max-w-40 truncate">{labelFor(value)}</span>
              <button
                type="button"
                disabled={disabled}
                aria-label={`Remove ${labelFor(value)}`}
                onClick={() => toggle(value)}
                className="inline-flex size-4 items-center justify-center rounded-full outline-none hover:bg-foreground/10 focus-visible:ring-2 focus-visible:ring-ring"
              >
                <HugeiconsIcon icon={Cancel01Icon} strokeWidth={2} className="size-3" />
              </button>
            </Badge>
          ))}
          {hidden > 0 && (
            <button
              type="button"
              disabled={disabled}
              onClick={() => setShowAll(true)}
              className="inline-flex h-6 shrink-0 items-center rounded-4xl px-2 text-xs font-medium whitespace-nowrap text-muted-foreground outline-none hover:bg-muted focus-visible:ring-2 focus-visible:ring-ring"
            >
              +{hidden} more
            </button>
          )}
          {showAll && selected.length > maxVisible && (
            <button
              type="button"
              disabled={disabled}
              onClick={() => setShowAll(false)}
              className="inline-flex h-6 shrink-0 items-center rounded-4xl px-2 text-xs font-medium whitespace-nowrap text-muted-foreground outline-none hover:bg-muted focus-visible:ring-2 focus-visible:ring-ring"
            >
              Show less
            </button>
          )}
          <PopoverTrigger asChild>
            <button
              type="button"
              id={id}
              role="combobox"
              aria-expanded={open}
              aria-haspopup="listbox"
              aria-label={ariaLabel}
              disabled={disabled}
              className={cn(
                "flex h-6 min-w-24 flex-1 items-center justify-between gap-2 rounded-md px-1 text-left outline-none",
                selected.length === 0
                  ? "text-muted-foreground"
                  : "text-muted-foreground/70"
              )}
            >
              <span className="truncate">
                {selected.length === 0 ? placeholder : "Add more"}
              </span>
              <HugeiconsIcon
                icon={ArrowDown01Icon}
                strokeWidth={2}
                className="size-4 shrink-0 text-muted-foreground"
              />
            </button>
          </PopoverTrigger>
        </div>
      </PopoverAnchor>
      <PopoverContent
        align="start"
        className="w-(--radix-popover-trigger-width) min-w-56 p-0"
      >
        <Command>
          <CommandInput
            placeholder={searchPlaceholder}
            value={query}
            onValueChange={setQuery}
          />
          <CommandList>
            <CommandEmpty>{emptyText}</CommandEmpty>
            <CommandGroup>
              {known.map((option) => (
                <CommandItem
                  key={option.value}
                  value={option.label ?? option.value}
                  keywords={[option.value]}
                  disabled={option.disabled}
                  data-checked={selected.includes(option.value)}
                  onSelect={() => toggle(option.value)}
                >
                  <span className="truncate">{option.label ?? option.value}</span>
                </CommandItem>
              ))}
              {canCreate && (
                <CommandItem
                  value={`create ${trimmed}`}
                  onSelect={() => {
                    toggle(trimmed)
                    setQuery("")
                  }}
                >
                  <HugeiconsIcon icon={Add01Icon} strokeWidth={2} />
                  <span className="truncate">Add “{trimmed}”</span>
                </CommandItem>
              )}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  )
}

export { MultiSelect }
export type { MultiSelectOption, MultiSelectProps }
