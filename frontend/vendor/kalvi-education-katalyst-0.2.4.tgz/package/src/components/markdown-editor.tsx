"use client"

import * as React from "react"
import { Extension } from "@tiptap/core"
import { Plugin } from "@tiptap/pm/state"
import { EditorContent, useEditor, useEditorState } from "@tiptap/react"
import Image from "@tiptap/extension-image"
import Placeholder from "@tiptap/extension-placeholder"
import Subscript from "@tiptap/extension-subscript"
import Superscript from "@tiptap/extension-superscript"
import { Table, TableCell, TableHeader, TableRow } from "@tiptap/extension-table"
import TextAlign from "@tiptap/extension-text-align"
import StarterKit from "@tiptap/starter-kit"
import DOMPurify from "dompurify"
import { marked } from "marked"
import TurndownService from "turndown"
import { HugeiconsIcon } from "@hugeicons/react"
import {
  Add01Icon,
  ArrowDown01Icon,
  CodeIcon,
  Delete02Icon,
  DeleteColumnIcon,
  DeleteRowIcon,
  Image01Icon,
  InsertColumnLeftIcon,
  InsertColumnRightIcon,
  InsertRowDownIcon,
  InsertRowUpIcon,
  LeftToRightListBulletIcon,
  LeftToRightListNumberIcon,
  Link01Icon,
  MinusSignIcon,
  MoreHorizontalIcon,
  RedoIcon,
  SourceCodeSquareIcon,
  Table02Icon,
  TextAlignCenterIcon,
  TextAlignJustifyCenterIcon,
  TextAlignLeftIcon,
  TextAlignRightIcon,
  TextBoldIcon,
  TextItalicIcon,
  TextStrikethroughIcon,
  TextSubscriptIcon,
  TextSuperscriptIcon,
  TextUnderlineIcon,
  UndoIcon,
  Unlink01Icon,
} from "@hugeicons/core-free-icons"

import { cn } from "@kalvi-education/katalyst/lib/utils"
import { Button } from "@kalvi-education/katalyst/components/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@kalvi-education/katalyst/components/dialog"
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuSeparator,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuTrigger,
} from "@kalvi-education/katalyst/components/dropdown-menu"
import { Input } from "@kalvi-education/katalyst/components/input"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@kalvi-education/katalyst/components/select"
import { Toggle } from "@kalvi-education/katalyst/components/toggle"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@kalvi-education/katalyst/components/tooltip"

/* -------------------------------------------------------------------------- */
/* Markdown <-> HTML                                                          */
/* -------------------------------------------------------------------------- */

/**
 * Markdown to the HTML the editor loads. Content that is already HTML is passed
 * through untouched. Everything else goes through `marked` (GFM) and is sanitised, so
 * this must run in the browser — DOMPurify needs a DOM.
 */
function markdownToHtml(markdown: string): string {
  if (!markdown) return ""
  if (markdown.trim().startsWith("<") && markdown.includes("</")) {
    return markdown
  }
  const rawHtml = marked.parse(markdown, { async: false, gfm: true }) as string
  return DOMPurify.sanitize(rawHtml)
}

let turndown: TurndownService | undefined

function getTurndown(): TurndownService {
  if (turndown) return turndown

  const service = new TurndownService({
    headingStyle: "atx",
    hr: "---",
    bulletListMarker: "-",
    codeBlockStyle: "fenced",
    emDelimiter: "*",
    strongDelimiter: "**",
  })

  const image = (_content: string, node: Node) => {
    const el = node as HTMLElement
    return `![${el.getAttribute("alt") || ""}](${el.getAttribute("src") || ""})`
  }
  service.addRule("image", { filter: "img", replacement: image })

  // Markdown has no syntax for these, so they are kept as inline HTML.
  const inlineHtml = (name: string, tag: string, nodeNames: string[]) =>
    service.addRule(name, {
      filter: (node) => nodeNames.includes(node.nodeName),
      replacement: (content) => `<${tag}>${content}</${tag}>`,
    })
  inlineHtml("strikethrough", "s", ["DEL", "S", "STRIKE"])
  inlineHtml("underline", "u", ["U"])
  inlineHtml("subscript", "sub", ["SUB"])
  inlineHtml("superscript", "sup", ["SUP"])

  // The editor wraps list-item text in a paragraph, which Markdown would render as a
  // loose list. Unwrap it so a tight list stays tight across a round trip.
  service.addRule("listItemParagraph", {
    filter: (node) => node.nodeName === "P" && node.parentNode?.nodeName === "LI",
    replacement: (content, node) => (node.nextSibling ? `${content}\n` : content),
  })

  // Centred / right / justified blocks keep their alignment as inline HTML.
  service.addRule("textAlign", {
    filter: (node) => {
      if (node.nodeName !== "P" && !/^H[1-6]$/.test(node.nodeName)) return false
      return (node.getAttribute("style") || "").includes("text-align")
    },
    replacement: (content, node) => {
      const el = node as HTMLElement
      const align = (el.getAttribute("style") || "").match(
        /text-align:\s*(center|right|justify)/
      )
      if (!align) return `${content}\n\n`
      const tag = el.nodeName.toLowerCase()
      return `<${tag} style="text-align: ${align[1]}">${content.trim()}</${tag}>\n\n`
    },
  })

  // GFM tables.
  service.addRule("tableCell", {
    filter: ["td", "th"],
    replacement: (content) => ` ${content.replace(/\n/g, " ").trim()} |`,
  })
  service.addRule("tableRow", {
    filter: "tr",
    replacement: (content) => `|${content}\n`,
  })
  service.addRule("table", {
    filter: "table",
    replacement: (content) => {
      const lines = content
        .trim()
        .split("\n")
        .filter((line) => line.trim().length > 0)
      if (lines.length === 0) return content

      const columns = (lines[0]?.match(/\|/g) || []).length - 1
      if (columns > 0) {
        lines.splice(1, 0, `|${Array(columns).fill(" --- ").join("|")}|`)
      }
      return `\n\n${lines.join("\n")}\n\n`
    },
  })

  turndown = service
  return service
}

/** HTML from the editor to the Markdown that `MarkdownEditor` emits. */
function htmlToMarkdown(html: string): string {
  return getTurndown().turndown(html)
}

function normalizeUrl(url: string): string {
  const trimmed = url.trim()
  return /^[a-zA-Z][a-zA-Z\d+\-.]*:/.test(trimmed) ? trimmed : `https://${trimmed}`
}

/* -------------------------------------------------------------------------- */
/* Editor extensions                                                          */
/* -------------------------------------------------------------------------- */

/**
 * Turns a run of pipe-delimited paragraphs into a real table when Enter is pressed on
 * the last row, so a table can be typed as Markdown.
 */
const MarkdownTableHandler = Extension.create({
  name: "markdownTableHandler",

  addProseMirrorPlugins() {
    const { editor } = this

    return [
      new Plugin({
        props: {
          handleKeyDown(view, event) {
            if (event.key !== "Enter" || event.shiftKey) return false

            const { state } = view
            const { $from } = state.selection
            const currentLine = $from.parent.textContent.trim()

            if (!currentLine.startsWith("|") || !currentLine.endsWith("|")) {
              return false
            }

            const doc = state.doc
            const currentIndex = $from.index(0)
            if (currentIndex < 0) return false

            const currentStart = $from.before($from.depth)
            const rows = [
              {
                from: currentStart,
                to: currentStart + doc.child(currentIndex).nodeSize,
                text: currentLine,
              },
            ]

            for (let i = currentIndex - 1; i >= 0; i--) {
              const child = doc.child(i)
              const text = child.textContent.trim()
              const isRow =
                (child.type.name === "paragraph" ||
                  child.type.name === "heading") &&
                text.startsWith("|") &&
                text.endsWith("|")
              if (!isRow) break

              let from = 0
              for (let j = 0; j < i; j++) from += doc.child(j).nodeSize
              rows.unshift({ from, to: from + child.nodeSize, text })
            }

            if (rows.length < 2) return false
            if (!rows.some((row) => /^\|(\s*:?-+:?\s*\|)+$/.test(row.text))) {
              return false
            }

            const html = markdownToHtml(rows.map((row) => row.text).join("\n"))
            if (!html.includes("<table")) return false

            event.preventDefault()

            const rangeFrom = rows[0]!.from
            const rangeTo = rows[rows.length - 1]!.to

            editor
              .chain()
              .command(({ tr, dispatch }) => {
                if (dispatch) tr.delete(rangeFrom, rangeTo)
                return true
              })
              .insertContentAt(rangeFrom, html)
              .focus()
              .run()

            return true
          },
        },
      }),
    ]
  },
})

/** Pasting Markdown text inserts it as formatted content rather than literal text. */
const MarkdownPasteHandler = Extension.create({
  name: "markdownPasteHandler",

  addProseMirrorPlugins() {
    const { editor } = this

    return [
      new Plugin({
        props: {
          handlePaste(_view, event) {
            const text = event.clipboardData?.getData("text/plain")
            if (!text) return false
            if (!/^(?:[#*+\-_`>|]|(?:[0-9]+\.)\s)/m.test(text.trim())) {
              return false
            }

            const html = markdownToHtml(text)
            if (!html || html === text) return false

            editor.commands.insertContent(`<div>${html}</div>`)
            event.preventDefault()
            return true
          },
        },
      }),
    ]
  },
})

/* -------------------------------------------------------------------------- */
/* Config                                                                     */
/* -------------------------------------------------------------------------- */

/**
 * Which features the editor offers. **Every feature is off unless set to `true`**, so a
 * config lists exactly what authors may use.
 *
 * Switching a feature off removes it from the document, not only the toolbar: its
 * shortcuts and Markdown shortcuts stop working, and existing content that uses it is
 * flattened when loaded (an `h5` becomes a paragraph, `**bold**` becomes plain text) and
 * saved that way on the next edit.
 */
type MarkdownEditorConfig = {
  history?: { undo?: boolean; redo?: boolean }
  typography?: {
    paragraph?: boolean
    heading1?: boolean
    heading2?: boolean
    heading3?: boolean
    heading4?: boolean
    heading5?: boolean
    heading6?: boolean
    quote?: boolean
    codeBlock?: boolean
  }
  style?: {
    bold?: boolean
    italic?: boolean
    underline?: boolean
    strike?: boolean
    subscript?: boolean
    superscript?: boolean
    code?: boolean
  }
  link?: boolean
  align?: { left?: boolean; center?: boolean; right?: boolean; justify?: boolean }
  list?: { bullet?: boolean; ordered?: boolean }
  insert?: {
    horizontalLine?: boolean
    /** Inserts an image from a URL. File upload is not supported yet. */
    image?: boolean
    table?: boolean
  }
}

/** Every feature on. Spread it and switch things off. */
const fullMarkdownEditorConfig = {
  history: { undo: true, redo: true },
  typography: {
    paragraph: true,
    heading1: true,
    heading2: true,
    heading3: true,
    heading4: true,
    heading5: true,
    heading6: true,
    quote: true,
    codeBlock: true,
  },
  style: {
    bold: true,
    italic: true,
    underline: true,
    strike: true,
    subscript: true,
    superscript: true,
    code: true,
  },
  link: true,
  align: { left: true, center: true, right: true, justify: true },
  list: { bullet: true, ordered: true },
  insert: { horizontalLine: true, image: true, table: true },
} as const satisfies MarkdownEditorConfig

/** Base text size of the document. Headings scale from it. */
type MarkdownEditorFontSize = "sm" | "base" | "lg" | "xl"

const FONT_SIZES: Record<MarkdownEditorFontSize, string> = {
  sm: "0.875rem",
  base: "1rem",
  lg: "1.125rem",
  xl: "1.25rem",
}

const HEADING_LEVELS = [1, 2, 3, 4, 5, 6] as const
type HeadingLevel = (typeof HEADING_LEVELS)[number]

function resolveConfig(config: MarkdownEditorConfig | undefined) {
  const t = config?.typography
  const headings = HEADING_LEVELS.filter((level) => !!t?.[`heading${level}`])

  return {
    undo: !!config?.history?.undo,
    redo: !!config?.history?.redo,
    paragraph: !!t?.paragraph,
    headings,
    quote: !!t?.quote,
    codeBlock: !!t?.codeBlock,
    bold: !!config?.style?.bold,
    italic: !!config?.style?.italic,
    underline: !!config?.style?.underline,
    strike: !!config?.style?.strike,
    subscript: !!config?.style?.subscript,
    superscript: !!config?.style?.superscript,
    code: !!config?.style?.code,
    link: !!config?.link,
    alignLeft: !!config?.align?.left,
    alignCenter: !!config?.align?.center,
    alignRight: !!config?.align?.right,
    alignJustify: !!config?.align?.justify,
    bulletList: !!config?.list?.bullet,
    orderedList: !!config?.list?.ordered,
    horizontalLine: !!config?.insert?.horizontalLine,
    image: !!config?.insert?.image,
    table: !!config?.insert?.table,
  }
}

type ResolvedConfig = ReturnType<typeof resolveConfig>

/* -------------------------------------------------------------------------- */
/* Styling                                                                    */
/* -------------------------------------------------------------------------- */

// Katalyst does not ship @tailwindcss/typography, so the document styles live here as
// descendant variants on the ProseMirror root, built from the same tokens as the rest
// of the system. Sizes are in `em`, so they follow the `fontSize` prop.
const documentClasses = cn(
  "min-h-64 px-6 py-5 leading-relaxed text-foreground outline-none",
  "[&>:first-child]:mt-0",
  "[&_p]:my-2",
  "[&_:is(h1,h2,h3,h4,h5,h6)]:mt-6 [&_:is(h1,h2,h3,h4,h5,h6)]:mb-2 [&_:is(h1,h2,h3,h4,h5,h6)]:font-heading [&_:is(h1,h2,h3,h4,h5,h6)]:font-semibold [&_:is(h1,h2,h3,h4,h5,h6)]:leading-tight",
  "[&_h1]:text-[1.714em] [&_h2]:text-[1.43em] [&_h3]:text-[1.286em] [&_h4]:text-[1.143em] [&_h5]:text-[1em] [&_h6]:text-[0.857em]",
  "[&_ul]:my-2 [&_ul]:list-disc [&_ul]:pl-6 [&_ol]:my-2 [&_ol]:list-decimal [&_ol]:pl-6 [&_li]:my-1 [&_li>p]:my-0",
  "[&_blockquote]:my-3 [&_blockquote]:border-l-2 [&_blockquote]:border-border [&_blockquote]:pl-4 [&_blockquote]:text-muted-foreground",
  "[&_hr]:my-6 [&_hr]:border-border",
  "[&_a]:text-primary [&_a]:underline [&_a]:underline-offset-2",
  "[&_img]:my-3 [&_img]:h-auto [&_img]:max-w-full [&_img]:rounded-lg [&_img.ProseMirror-selectednode]:ring-3 [&_img.ProseMirror-selectednode]:ring-ring/50",
  "[&_code]:rounded-sm [&_code]:bg-muted [&_code]:px-1 [&_code]:py-0.5 [&_code]:font-mono [&_code]:text-[0.85em]",
  "[&_pre]:my-3 [&_pre]:overflow-x-auto [&_pre]:rounded-lg [&_pre]:bg-muted [&_pre]:p-3 [&_pre_code]:bg-transparent [&_pre_code]:p-0",
  "[&_p.is-editor-empty:first-child]:before:pointer-events-none [&_p.is-editor-empty:first-child]:before:float-left [&_p.is-editor-empty:first-child]:before:h-0 [&_p.is-editor-empty:first-child]:before:text-muted-foreground [&_p.is-editor-empty:first-child]:before:content-[attr(data-placeholder)]",
  "[&_table]:my-4 [&_table]:w-full [&_table]:table-fixed [&_table]:border-collapse",
  "[&_:is(td,th)]:relative [&_:is(td,th)]:min-w-20 [&_:is(td,th)]:border [&_:is(td,th)]:border-border [&_:is(td,th)]:px-3 [&_:is(td,th)]:py-2 [&_:is(td,th)]:align-top [&_:is(td,th)>p]:my-0",
  "[&_th]:bg-muted [&_th]:text-left [&_th]:font-semibold",
  "[&_.selectedCell]:bg-primary/10",
  "[&_.tableWrapper]:overflow-x-auto",
  "[&_.column-resize-handle]:pointer-events-none [&_.column-resize-handle]:absolute [&_.column-resize-handle]:top-0 [&_.column-resize-handle]:-right-0.5 [&_.column-resize-handle]:-bottom-0.5 [&_.column-resize-handle]:w-1 [&_.column-resize-handle]:bg-primary",
  "[&.resize-cursor]:cursor-col-resize"
)

/* -------------------------------------------------------------------------- */
/* Toolbar pieces                                                             */
/* -------------------------------------------------------------------------- */

type IconData = React.ComponentProps<typeof HugeiconsIcon>["icon"]

/** Width a separator takes in the toolbar row: 1px line, 2 × mx-1, 2 × gap-0.5. */
const SEPARATOR_WIDTH = 13

function ToolbarSeparator() {
  return (
    <div
      role="separator"
      aria-orientation="vertical"
      className="mx-1 h-5 w-px shrink-0 bg-border"
    />
  )
}

function ToolbarToggle({
  icon,
  label,
  pressed,
  disabled,
  onPressedChange,
}: {
  icon: IconData
  label: string
  pressed: boolean
  disabled?: boolean
  onPressedChange: () => void
}) {
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <Toggle
          size="sm"
          aria-label={label}
          pressed={pressed}
          disabled={disabled}
          onPressedChange={onPressedChange}
        >
          <HugeiconsIcon icon={icon} strokeWidth={2} />
        </Toggle>
      </TooltipTrigger>
      <TooltipContent>{label}</TooltipContent>
    </Tooltip>
  )
}

function ToolbarAction({
  icon,
  label,
  disabled,
  destructive,
  onClick,
}: {
  icon: IconData
  label: string
  disabled?: boolean
  destructive?: boolean
  onClick: () => void
}) {
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <Button
          type="button"
          variant="ghost"
          size="icon-sm"
          aria-label={label}
          disabled={disabled}
          onClick={onClick}
          className={cn(destructive && "text-destructive hover:text-destructive")}
        >
          <HugeiconsIcon icon={icon} strokeWidth={2} />
        </Button>
      </TooltipTrigger>
      <TooltipContent>{label}</TooltipContent>
    </Tooltip>
  )
}

/** A toggle shown as a checkable row in the overflow menu. */
function MenuToggle({
  label,
  checked,
  disabled,
  onToggle,
}: {
  label: string
  checked: boolean
  disabled?: boolean
  onToggle: () => void
}) {
  return (
    <DropdownMenuCheckboxItem
      checked={checked}
      disabled={disabled}
      onCheckedChange={onToggle}
    >
      {label}
    </DropdownMenuCheckboxItem>
  )
}

/**
 * One toolbar group, drawn two ways: `inline` in the toolbar row, and `menu` as rows of
 * the overflow menu when the group no longer fits.
 */
type ToolbarGroup = {
  key: string
  inline: React.ReactNode
  menu: React.ReactNode
}

/* -------------------------------------------------------------------------- */
/* MarkdownEditor                                                             */
/* -------------------------------------------------------------------------- */

type BlockFormat =
  | "p"
  | "h1"
  | "h2"
  | "h3"
  | "h4"
  | "h5"
  | "h6"
  | "blockquote"
  | "codeBlock"

const BLOCK_LABELS: Record<BlockFormat, string> = {
  p: "Paragraph",
  h1: "Heading 1",
  h2: "Heading 2",
  h3: "Heading 3",
  h4: "Heading 4",
  h5: "Heading 5",
  h6: "Heading 6",
  blockquote: "Quote",
  codeBlock: "Code block",
}

function buildExtensions(cfg: ResolvedConfig, placeholder: string) {
  const hasList = cfg.bulletList || cfg.orderedList

  return [
    StarterKit.configure({
      heading: cfg.headings.length ? { levels: [...cfg.headings] } : false,
      blockquote: cfg.quote ? undefined : false,
      codeBlock: cfg.codeBlock ? undefined : false,
      bold: cfg.bold ? undefined : false,
      italic: cfg.italic ? undefined : false,
      underline: cfg.underline ? undefined : false,
      strike: cfg.strike ? undefined : false,
      code: cfg.code ? undefined : false,
      link: cfg.link ? { openOnClick: false } : false,
      bulletList: cfg.bulletList ? undefined : false,
      orderedList: cfg.orderedList ? undefined : false,
      listItem: hasList ? undefined : false,
      listKeymap: hasList ? undefined : false,
      horizontalRule: cfg.horizontalLine ? undefined : false,
      undoRedo: cfg.undo || cfg.redo ? { depth: 100 } : false,
    }),
    Placeholder.configure({ placeholder }),
    ...(cfg.image ? [Image.configure({ inline: false, allowBase64: false })] : []),
    ...(cfg.subscript ? [Subscript] : []),
    ...(cfg.superscript ? [Superscript] : []),
    ...(cfg.alignLeft || cfg.alignCenter || cfg.alignRight || cfg.alignJustify
      ? [TextAlign.configure({ types: ["heading", "paragraph"] })]
      : []),
    ...(cfg.table
      ? [
          Table.configure({ resizable: true }),
          TableRow,
          TableHeader,
          TableCell,
          MarkdownTableHandler,
        ]
      : []),
    MarkdownPasteHandler,
  ]
}

type MarkdownEditorProps = {
  /** Markdown content. Pass it with `onChange` to control the editor. */
  value?: string
  /** Initial Markdown when uncontrolled. */
  defaultValue?: string
  /** Called with the Markdown on every edit. */
  onChange?: (markdown: string) => void
  /**
   * Which features are offered. Everything is off unless enabled here; see
   * `fullMarkdownEditorConfig` for a starting point.
   */
  config?: MarkdownEditorConfig
  /**
   * `bordered` draws a frame around the editor. `borderless` removes only that outer
   * frame (border, rounding and focus ring), so the editor can sit inside another
   * surface. The toolbar and document look the same in both.
   */
  variant?: "bordered" | "borderless"
  /** Base text size of the document; headings scale from it. */
  fontSize?: MarkdownEditorFontSize
  /** Shown while the document is empty. */
  placeholder?: string
  /** Makes the document read-only and disables the toolbar. */
  disabled?: boolean
  /** Accessible name for the editing area. */
  "aria-label"?: string
  className?: string
  /** Classes for the scrolling document area, e.g. to change its minimum height. */
  contentClassName?: string
}

function MarkdownEditor({
  value,
  defaultValue,
  onChange,
  config,
  variant = "bordered",
  fontSize = "sm",
  placeholder = "Start writing…",
  disabled = false,
  "aria-label": ariaLabel = "Document",
  className,
  contentClassName,
}: MarkdownEditorProps) {
  const cfg = resolveConfig(config)

  const [linkOpen, setLinkOpen] = React.useState(false)
  const [linkUrl, setLinkUrl] = React.useState("")
  const [imageOpen, setImageOpen] = React.useState(false)
  const [imageUrl, setImageUrl] = React.useState("")
  const [imageAlt, setImageAlt] = React.useState("")
  const [imageError, setImageError] = React.useState(false)

  // The last Markdown the editor and its parent agree on. A `value` that matches it is
  // the echo of our own `onChange`, so re-applying it would reset the caret.
  const lastMarkdown = React.useRef<string | null>(null)
  const syncedEditor = React.useRef<unknown>(null)
  const onChangeRef = React.useRef(onChange)
  onChangeRef.current = onChange

  const editor = useEditor(
    {
      // Required for SSR frameworks: the document is created on the client only.
      immediatelyRender: false,
      editable: !disabled,
      extensions: buildExtensions(cfg, placeholder),
      editorProps: {
        attributes: {
          class: documentClasses,
          role: "textbox",
          "aria-multiline": "true",
          "aria-label": ariaLabel,
        },
      },
      onUpdate: ({ editor }) => {
        const markdown = htmlToMarkdown(editor.getHTML())
        lastMarkdown.current = markdown
        onChangeRef.current?.(markdown)
      },
    },
    // The schema comes from the config, so a changed config builds a new editor.
    [JSON.stringify(cfg), placeholder]
  )

  React.useEffect(() => {
    if (!editor) return

    const isNewEditor = syncedEditor.current !== editor
    if (!isNewEditor && (value === undefined || value === lastMarkdown.current)) {
      return
    }

    const markdown = value ?? lastMarkdown.current ?? defaultValue ?? ""
    syncedEditor.current = editor
    lastMarkdown.current = markdown
    editor.commands.setContent(markdownToHtml(markdown), { emitUpdate: false })
  }, [editor, value, defaultValue])

  React.useEffect(() => {
    editor?.setEditable(!disabled)
  }, [editor, disabled])

  const state = useEditorState({
    editor,
    selector: ({ editor }) => {
      if (!editor) return null
      let block: BlockFormat = "p"
      for (const level of HEADING_LEVELS) {
        if (editor.isActive("heading", { level })) block = `h${level}`
      }
      if (editor.isActive("blockquote")) block = "blockquote"
      if (editor.isActive("codeBlock")) block = "codeBlock"

      const align = (["left", "center", "right", "justify"] as const).find((a) =>
        editor.isActive({ textAlign: a })
      )

      return {
        block,
        align: align ?? "",
        bold: editor.isActive("bold"),
        italic: editor.isActive("italic"),
        underline: editor.isActive("underline"),
        strike: editor.isActive("strike"),
        subscript: editor.isActive("subscript"),
        superscript: editor.isActive("superscript"),
        code: editor.isActive("code"),
        link: editor.isActive("link"),
        bulletList: editor.isActive("bulletList"),
        orderedList: editor.isActive("orderedList"),
        table: editor.isActive("table"),
        canUndo: cfg.undo && editor.can().undo(),
        canRedo: cfg.redo && editor.can().redo(),
      }
    },
  })

  const run = () => editor?.chain().focus()

  const blocks: BlockFormat[] = [
    ...(cfg.paragraph ? (["p"] as const) : []),
    ...cfg.headings.map((level: HeadingLevel) => `h${level}` as BlockFormat),
    ...(cfg.quote ? (["blockquote"] as const) : []),
    ...(cfg.codeBlock ? (["codeBlock"] as const) : []),
  ]
  const currentBlock = blocks.includes(state?.block ?? "p") ? (state?.block ?? "p") : ""

  const setBlock = (next: string) => {
    const chain = run()
    if (!chain || !editor) return
    switch (next as BlockFormat) {
      case "p":
        if (editor.isActive("blockquote")) chain.toggleBlockquote().run()
        else if (editor.isActive("codeBlock")) chain.toggleCodeBlock().run()
        else chain.setParagraph().run()
        break
      case "blockquote":
        chain.toggleBlockquote().run()
        break
      case "codeBlock":
        chain.toggleCodeBlock().run()
        break
      default:
        chain.toggleHeading({ level: Number(next[1]) as HeadingLevel }).run()
    }
  }

  const openLinkDialog = () => {
    if (!editor) return
    setLinkUrl((editor.getAttributes("link").href as string | undefined) ?? "")
    setLinkOpen(true)
  }

  const applyLink = () => {
    const url = linkUrl.trim()
    const chain = run()?.extendMarkRange("link")
    if (!chain) return
    if (url) chain.setLink({ href: normalizeUrl(url) }).run()
    else chain.unsetLink().run()
    setLinkOpen(false)
  }

  const removeLink = () => {
    run()?.extendMarkRange("link").unsetLink().run()
    setLinkOpen(false)
  }

  const openImageDialog = () => {
    setImageUrl("")
    setImageAlt("")
    setImageError(false)
    setImageOpen(true)
  }

  const insertImage = () => {
    let url: URL | null = null
    try {
      url = new URL(imageUrl.trim())
    } catch {
      url = null
    }
    if (!url || (url.protocol !== "https:" && url.protocol !== "http:")) {
      setImageError(true)
      return
    }
    run()?.setImage({ src: url.toString(), alt: imageAlt.trim() }).run()
    setImageOpen(false)
  }

  const locked = disabled || !editor
  const showInsert = cfg.horizontalLine || cfg.image || cfg.table

  /* ---------------------------------------------------------------------- */
  /* Toolbar groups                                                         */
  /* ---------------------------------------------------------------------- */

  // A group exists only when at least one of its controls is enabled.
  const groups: ToolbarGroup[] = []

  if (cfg.undo || cfg.redo) {
    groups.push({
      key: "history",
      inline: (
        <>
          {cfg.undo && (
            <ToolbarAction
              icon={UndoIcon}
              label="Undo"
              disabled={locked || !state?.canUndo}
              onClick={() => run()?.undo().run()}
            />
          )}
          {cfg.redo && (
            <ToolbarAction
              icon={RedoIcon}
              label="Redo"
              disabled={locked || !state?.canRedo}
              onClick={() => run()?.redo().run()}
            />
          )}
        </>
      ),
      menu: (
        <>
          {cfg.undo && (
            <DropdownMenuItem
              disabled={locked || !state?.canUndo}
              onSelect={() => run()?.undo().run()}
            >
              Undo
            </DropdownMenuItem>
          )}
          {cfg.redo && (
            <DropdownMenuItem
              disabled={locked || !state?.canRedo}
              onSelect={() => run()?.redo().run()}
            >
              Redo
            </DropdownMenuItem>
          )}
        </>
      ),
    })
  }

  if (blocks.length) {
    groups.push({
      key: "typography",
      inline: (
        <Select value={currentBlock} onValueChange={setBlock} disabled={locked}>
          <SelectTrigger size="sm" aria-label="Text style" className="w-32">
            <SelectValue placeholder="Text style" />
          </SelectTrigger>
          <SelectContent>
            {blocks.map((block) => (
              <SelectItem key={block} value={block}>
                {BLOCK_LABELS[block]}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      ),
      menu: (
        <DropdownMenuSub>
          <DropdownMenuSubTrigger disabled={locked}>Text style</DropdownMenuSubTrigger>
          <DropdownMenuSubContent>
            <DropdownMenuRadioGroup value={currentBlock} onValueChange={setBlock}>
              {blocks.map((block) => (
                <DropdownMenuRadioItem key={block} value={block}>
                  {BLOCK_LABELS[block]}
                </DropdownMenuRadioItem>
              ))}
            </DropdownMenuRadioGroup>
          </DropdownMenuSubContent>
        </DropdownMenuSub>
      ),
    })
  }

  const marks = [
    { on: cfg.bold, icon: TextBoldIcon, label: "Bold", pressed: state?.bold, toggle: () => run()?.toggleBold().run() },
    { on: cfg.italic, icon: TextItalicIcon, label: "Italic", pressed: state?.italic, toggle: () => run()?.toggleItalic().run() },
    { on: cfg.underline, icon: TextUnderlineIcon, label: "Underline", pressed: state?.underline, toggle: () => run()?.toggleUnderline().run() },
    { on: cfg.strike, icon: TextStrikethroughIcon, label: "Strikethrough", pressed: state?.strike, toggle: () => run()?.toggleStrike().run() },
    { on: cfg.subscript, icon: TextSubscriptIcon, label: "Subscript", pressed: state?.subscript, toggle: () => run()?.toggleSubscript().run() },
    { on: cfg.superscript, icon: TextSuperscriptIcon, label: "Superscript", pressed: state?.superscript, toggle: () => run()?.toggleSuperscript().run() },
    { on: cfg.code, icon: CodeIcon, label: "Inline code", pressed: state?.code, toggle: () => run()?.toggleCode().run() },
  ].filter((mark) => mark.on)

  if (marks.length) {
    groups.push({
      key: "style",
      inline: marks.map((mark) => (
        <ToolbarToggle
          key={mark.label}
          icon={mark.icon}
          label={mark.label}
          pressed={!!mark.pressed}
          disabled={locked}
          onPressedChange={mark.toggle}
        />
      )),
      menu: marks.map((mark) => (
        <MenuToggle
          key={mark.label}
          label={mark.label}
          checked={!!mark.pressed}
          disabled={locked}
          onToggle={mark.toggle}
        />
      )),
    })
  }

  if (cfg.link) {
    groups.push({
      key: "link",
      inline: (
        <ToolbarToggle
          icon={Link01Icon}
          label="Link"
          pressed={!!state?.link}
          disabled={locked}
          onPressedChange={openLinkDialog}
        />
      ),
      menu: (
        <DropdownMenuItem disabled={locked} onSelect={openLinkDialog}>
          Link…
        </DropdownMenuItem>
      ),
    })
  }

  const aligns = [
    { on: cfg.alignLeft, icon: TextAlignLeftIcon, label: "Align left", value: "left" },
    { on: cfg.alignCenter, icon: TextAlignCenterIcon, label: "Align center", value: "center" },
    { on: cfg.alignRight, icon: TextAlignRightIcon, label: "Align right", value: "right" },
    { on: cfg.alignJustify, icon: TextAlignJustifyCenterIcon, label: "Justify", value: "justify" },
  ].filter((align) => align.on)

  if (aligns.length) {
    groups.push({
      key: "align",
      inline: aligns.map((align) => (
        <ToolbarToggle
          key={align.value}
          icon={align.icon}
          label={align.label}
          pressed={state?.align === align.value}
          disabled={locked}
          onPressedChange={() => run()?.setTextAlign(align.value).run()}
        />
      )),
      menu: (
        <DropdownMenuSub>
          <DropdownMenuSubTrigger disabled={locked}>Alignment</DropdownMenuSubTrigger>
          <DropdownMenuSubContent>
            <DropdownMenuRadioGroup
              value={state?.align ?? ""}
              onValueChange={(next) => run()?.setTextAlign(next).run()}
            >
              {aligns.map((align) => (
                <DropdownMenuRadioItem key={align.value} value={align.value}>
                  {align.label}
                </DropdownMenuRadioItem>
              ))}
            </DropdownMenuRadioGroup>
          </DropdownMenuSubContent>
        </DropdownMenuSub>
      ),
    })
  }

  if (cfg.bulletList || cfg.orderedList) {
    groups.push({
      key: "list",
      inline: (
        <>
          {cfg.bulletList && (
            <ToolbarToggle
              icon={LeftToRightListBulletIcon}
              label="Bullet list"
              pressed={!!state?.bulletList}
              disabled={locked}
              onPressedChange={() => run()?.toggleBulletList().run()}
            />
          )}
          {cfg.orderedList && (
            <ToolbarToggle
              icon={LeftToRightListNumberIcon}
              label="Numbered list"
              pressed={!!state?.orderedList}
              disabled={locked}
              onPressedChange={() => run()?.toggleOrderedList().run()}
            />
          )}
        </>
      ),
      menu: (
        <>
          {cfg.bulletList && (
            <MenuToggle
              label="Bullet list"
              checked={!!state?.bulletList}
              disabled={locked}
              onToggle={() => run()?.toggleBulletList().run()}
            />
          )}
          {cfg.orderedList && (
            <MenuToggle
              label="Numbered list"
              checked={!!state?.orderedList}
              disabled={locked}
              onToggle={() => run()?.toggleOrderedList().run()}
            />
          )}
        </>
      ),
    })
  }

  if (showInsert) {
    const insertItems = (
      <>
        {cfg.image && (
          <DropdownMenuItem onSelect={openImageDialog}>
            <HugeiconsIcon icon={Image01Icon} strokeWidth={2} />
            Image
          </DropdownMenuItem>
        )}
        {cfg.horizontalLine && (
          <DropdownMenuItem onSelect={() => run()?.setHorizontalRule().run()}>
            <HugeiconsIcon icon={MinusSignIcon} strokeWidth={2} />
            Horizontal line
          </DropdownMenuItem>
        )}
        {cfg.table && (
          <DropdownMenuItem
            onSelect={() =>
              run()?.insertTable({ rows: 3, cols: 3, withHeaderRow: true }).run()
            }
          >
            <HugeiconsIcon icon={Table02Icon} strokeWidth={2} />
            Table
          </DropdownMenuItem>
        )}
      </>
    )

    groups.push({
      key: "insert",
      inline: (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button type="button" variant="outline" size="sm" disabled={locked}>
              <HugeiconsIcon icon={Add01Icon} strokeWidth={2} />
              Insert
              <HugeiconsIcon icon={ArrowDown01Icon} strokeWidth={2} />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start">{insertItems}</DropdownMenuContent>
        </DropdownMenu>
      ),
      menu: (
        <DropdownMenuSub>
          <DropdownMenuSubTrigger disabled={locked}>Insert</DropdownMenuSubTrigger>
          <DropdownMenuSubContent>{insertItems}</DropdownMenuSubContent>
        </DropdownMenuSub>
      ),
    })
  }

  /* ---------------------------------------------------------------------- */
  /* Responsive overflow                                                    */
  /* ---------------------------------------------------------------------- */

  // The toolbar never wraps or scrolls. A hidden copy of every group is measured, and the
  // groups that do not fit (leaving room for the More button) move into the More menu,
  // last group first. `null` means "not measured yet": show everything.
  const toolbarRef = React.useRef<HTMLDivElement>(null)
  const measureRef = React.useRef<HTMLDivElement>(null)
  const [visibleCount, setVisibleCount] = React.useState<number | null>(null)
  const groupKeys = groups.map((group) => group.key).join()

  React.useLayoutEffect(() => {
    const bar = toolbarRef.current
    const measure = measureRef.current
    if (!bar || !measure) return

    const compute = () => {
      const style = getComputedStyle(bar)
      const available =
        bar.clientWidth -
        Number.parseFloat(style.paddingLeft) -
        Number.parseFloat(style.paddingRight)

      const origin = measure.getBoundingClientRect().left
      const edges = Array.from(
        measure.querySelectorAll<HTMLElement>("[data-measure-group]")
      ).map((el) => el.getBoundingClientRect().right - origin)
      const moreEl = measure.querySelector<HTMLElement>("[data-measure-more]")
      const reserve = (moreEl?.getBoundingClientRect().width ?? 0) + SEPARATOR_WIDTH

      let count = edges.length
      if (edges.length && edges[edges.length - 1]! > available) {
        count = 0
        edges.forEach((edge, index) => {
          if (edge + reserve <= available) count = index + 1
        })
      }
      setVisibleCount(count)
    }

    compute()
    const observer = new ResizeObserver(compute)
    observer.observe(bar)
    observer.observe(measure)
    return () => observer.disconnect()
  }, [groupKeys])

  const inlineGroups = visibleCount === null ? groups : groups.slice(0, visibleCount)
  const overflowGroups = visibleCount === null ? [] : groups.slice(visibleCount)

  const withSeparators = (items: ToolbarGroup[], node: (group: ToolbarGroup) => React.ReactNode) =>
    items.map((group, index) => (
      <React.Fragment key={group.key}>
        {index > 0 && <ToolbarSeparator />}
        {node(group)}
      </React.Fragment>
    ))

  const moreButton = (
    <Button
      type="button"
      variant="ghost"
      size="icon-sm"
      aria-label="More formatting options"
      disabled={locked}
    >
      <HugeiconsIcon icon={MoreHorizontalIcon} strokeWidth={2} />
    </Button>
  )

  /* ---------------------------------------------------------------------- */
  /* Render                                                                 */
  /* ---------------------------------------------------------------------- */

  return (
    <TooltipProvider>
      <div
        data-slot="markdown-editor"
        data-variant={variant}
        data-disabled={disabled || undefined}
        className={cn(
          "flex min-h-0 flex-col bg-background data-disabled:opacity-60",
          variant === "bordered" &&
            "overflow-hidden rounded-lg border border-input transition-colors focus-within:border-ring focus-within:ring-3 focus-within:ring-ring/50",
          className
        )}
      >
        {groups.length > 0 && (
          <div
            ref={toolbarRef}
            role="toolbar"
            aria-label="Formatting"
            data-slot="markdown-editor-toolbar"
            className="relative flex min-w-0 flex-nowrap items-center gap-0.5 overflow-hidden border-b bg-muted/30 px-2 py-1.5"
          >
            {withSeparators(inlineGroups, (group) => group.inline)}

            {overflowGroups.length > 0 && (
              <>
                {inlineGroups.length > 0 && <ToolbarSeparator />}
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>{moreButton}</DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-48">
                    {overflowGroups.map((group, index) => (
                      <React.Fragment key={group.key}>
                        {index > 0 && <DropdownMenuSeparator />}
                        {group.menu}
                      </React.Fragment>
                    ))}
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            )}

            {/* Hidden, never focusable: every group at natural width, for measuring. */}
            <div
              ref={measureRef}
              aria-hidden="true"
              className="pointer-events-none invisible absolute top-0 left-0 flex w-max flex-nowrap items-center gap-0.5"
            >
              {groups.map((group, index) => (
                <React.Fragment key={group.key}>
                  {index > 0 && <ToolbarSeparator />}
                  <div data-measure-group className="flex items-center gap-0.5">
                    {group.inline}
                  </div>
                </React.Fragment>
              ))}
              <div data-measure-more>{moreButton}</div>
            </div>
          </div>
        )}

        {cfg.table && state?.table && !disabled && (
          <div
            role="toolbar"
            aria-label="Table"
            data-slot="markdown-editor-table-toolbar"
            className="flex flex-wrap items-center gap-0.5 border-b bg-muted/60 px-2 py-1"
          >
            <span className="mr-2 text-xs font-medium text-muted-foreground">
              Table
            </span>
            <ToolbarAction
              icon={InsertRowUpIcon}
              label="Add row above"
              onClick={() => run()?.addRowBefore().run()}
            />
            <ToolbarAction
              icon={InsertRowDownIcon}
              label="Add row below"
              onClick={() => run()?.addRowAfter().run()}
            />
            <ToolbarAction
              icon={InsertColumnLeftIcon}
              label="Add column left"
              onClick={() => run()?.addColumnBefore().run()}
            />
            <ToolbarAction
              icon={InsertColumnRightIcon}
              label="Add column right"
              onClick={() => run()?.addColumnAfter().run()}
            />
            <ToolbarSeparator />
            <ToolbarAction
              icon={DeleteRowIcon}
              label="Delete row"
              destructive
              onClick={() => run()?.deleteRow().run()}
            />
            <ToolbarAction
              icon={DeleteColumnIcon}
              label="Delete column"
              destructive
              onClick={() => run()?.deleteColumn().run()}
            />
            <ToolbarAction
              icon={Delete02Icon}
              label="Delete table"
              destructive
              onClick={() => run()?.deleteTable().run()}
            />
          </div>
        )}

        <div
          data-slot="markdown-editor-content"
          style={{ fontSize: FONT_SIZES[fontSize] }}
          className={cn("min-h-0 flex-1 overflow-auto", contentClassName)}
        >
          <EditorContent editor={editor} />
        </div>

        {cfg.link && (
          <Dialog open={linkOpen} onOpenChange={setLinkOpen}>
            <DialogContent className="sm:max-w-md">
              <form
                className="flex flex-col gap-4"
                onSubmit={(event) => {
                  event.preventDefault()
                  applyLink()
                }}
              >
                <DialogHeader>
                  <DialogTitle>Link</DialogTitle>
                  <DialogDescription>
                    Where the selected text should point. Leave it empty to remove the
                    link.
                  </DialogDescription>
                </DialogHeader>
                <Input
                  autoFocus
                  type="text"
                  inputMode="url"
                  aria-label="Link URL"
                  placeholder="https://example.com"
                  value={linkUrl}
                  onChange={(event) => setLinkUrl(event.target.value)}
                />
                <DialogFooter>
                  {state?.link && (
                    <Button type="button" variant="outline" onClick={removeLink}>
                      <HugeiconsIcon icon={Unlink01Icon} strokeWidth={2} />
                      Remove link
                    </Button>
                  )}
                  <Button type="submit">Apply</Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        )}

        {cfg.image && (
          <Dialog open={imageOpen} onOpenChange={setImageOpen}>
            <DialogContent className="sm:max-w-md">
              <form
                className="flex flex-col gap-4"
                onSubmit={(event) => {
                  event.preventDefault()
                  insertImage()
                }}
              >
                <DialogHeader>
                  <DialogTitle>Insert image</DialogTitle>
                  <DialogDescription>
                    Paste the address of an image that is already hosted online.
                  </DialogDescription>
                </DialogHeader>
                <div className="flex flex-col gap-2">
                  <Input
                    autoFocus
                    type="text"
                    inputMode="url"
                    aria-label="Image URL"
                    aria-invalid={imageError || undefined}
                    placeholder="https://cdn.example.com/photo.jpg"
                    value={imageUrl}
                    onChange={(event) => {
                      setImageUrl(event.target.value)
                      setImageError(false)
                    }}
                  />
                  {imageError && (
                    <p role="alert" className="text-xs text-destructive">
                      Enter a full http(s) address.
                    </p>
                  )}
                  <Input
                    type="text"
                    aria-label="Alt text"
                    placeholder="Alt text (describe the image)"
                    value={imageAlt}
                    onChange={(event) => setImageAlt(event.target.value)}
                  />
                </div>
                <DialogFooter>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setImageOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button type="submit">Insert</Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </div>
    </TooltipProvider>
  )
}

export {
  MarkdownEditor,
  fullMarkdownEditorConfig,
  htmlToMarkdown,
  markdownToHtml,
}
export type {
  MarkdownEditorConfig,
  MarkdownEditorFontSize,
  MarkdownEditorProps,
}
