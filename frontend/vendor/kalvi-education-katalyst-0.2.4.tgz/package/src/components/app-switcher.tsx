"use client"

import * as React from "react"
import { HugeiconsIcon, type IconSvgElement } from "@hugeicons/react"
import { Grid02Icon } from "@hugeicons/core-free-icons"

import { cn } from "@kalvi-education/katalyst/lib/utils"
import { Button } from "@kalvi-education/katalyst/components/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from "@kalvi-education/katalyst/components/dropdown-menu"

type AppSwitcherApp = {
  /** Unique id. Compared with `current`. */
  id: string
  name: string
  /** One line about what the app is for. */
  description?: string
  href: string
  icon?: IconSvgElement
  /** Open the app in a new tab. */
  external?: boolean
}

type AppSwitcherProps = Omit<React.ComponentProps<typeof DropdownMenuContent>, "children"> & {
  /** The apps to offer. The caller decides which belong to the current environment. */
  apps: AppSwitcherApp[]
  /** `id` of the app the person is in. It is marked and not offered as a destination. */
  current?: string
  /** Heading in the menu. */
  label?: string
  /** Replaces the default icon button. It must be a single focusable element. */
  trigger?: React.ReactNode
}

function AppSwitcher({
  apps,
  current,
  label = "Switch app",
  trigger,
  align = "end",
  className,
  ...props
}: AppSwitcherProps) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        {trigger ?? (
          <Button type="button" variant="ghost" size="icon" aria-label={label}>
            <HugeiconsIcon icon={Grid02Icon} strokeWidth={2} />
          </Button>
        )}
      </DropdownMenuTrigger>
      <DropdownMenuContent data-slot="app-switcher" align={align} className={cn("w-64", className)} {...props}>
        <DropdownMenuLabel>{label}</DropdownMenuLabel>
        {apps.map((app) => {
          const isCurrent = app.id === current
          return (
            <DropdownMenuItem
              key={app.id}
              asChild
              disabled={isCurrent}
              className="items-start gap-2.5 py-2"
            >
              <a
                href={app.href}
                aria-current={isCurrent ? "page" : undefined}
                {...(app.external ? { target: "_blank", rel: "noopener noreferrer" } : {})}
              >
                {app.icon && (
                  <span className="flex size-8 shrink-0 items-center justify-center rounded-md bg-muted text-muted-foreground">
                    <HugeiconsIcon icon={app.icon} strokeWidth={2} />
                  </span>
                )}
                <span className="flex min-w-0 flex-col">
                  <span className="truncate font-medium">{app.name}</span>
                  {(app.description || isCurrent) && (
                    <span className="text-xs text-muted-foreground">
                      {isCurrent ? "You are here" : app.description}
                    </span>
                  )}
                </span>
              </a>
            </DropdownMenuItem>
          )
        })}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}

export { AppSwitcher }
export type { AppSwitcherApp, AppSwitcherProps }
