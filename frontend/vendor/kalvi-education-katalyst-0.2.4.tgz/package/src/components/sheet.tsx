"use client"

import * as React from "react"
import { Dialog as SheetPrimitive } from "radix-ui"

import { cn } from "@kalvi-education/katalyst/lib/utils"
import { Button } from "@kalvi-education/katalyst/components/button"
import { HugeiconsIcon } from "@hugeicons/react"
import { Cancel01Icon } from "@hugeicons/core-free-icons"

type SheetSide = "top" | "right" | "bottom" | "left"
type SheetSize = "sm" | "md" | "lg" | "xl" | "full"
type SheetFooterAlign = "start" | "end" | "between"

/**
 * Sheets that come in from the left or right are panels: a wide column with a header, a body that scrolls and
 * a footer that stays put. Sheets from the top or bottom keep their compact, edge-hugging layout. The parts read
 * which one they are from here, so each part has one set of classes per kind and no caller has to pass a flag.
 */
const SheetContext = React.createContext<{ panel: boolean }>({ panel: true })

/**
 * Panel widths, from 24rem to the full viewport. Plain classes, not `data-[side=...]` ones, so a caller's own
 * `sm:max-w-*` in `className` replaces them through tailwind-merge instead of losing to higher specificity.
 */
const SIZES: Record<SheetSize, string> = {
  sm: "sm:max-w-sm",
  md: "sm:max-w-lg",
  lg: "sm:max-w-170",
  xl: "sm:max-w-4xl",
  full: "sm:max-w-none",
}

const ALIGN: Record<SheetFooterAlign, string> = {
  start: "justify-start",
  end: "justify-end",
  between: "justify-between",
}

function Sheet({ ...props }: React.ComponentProps<typeof SheetPrimitive.Root>) {
  return <SheetPrimitive.Root data-slot="sheet" {...props} />
}

function SheetTrigger({
  ...props
}: React.ComponentProps<typeof SheetPrimitive.Trigger>) {
  return <SheetPrimitive.Trigger data-slot="sheet-trigger" {...props} />
}

function SheetClose({
  ...props
}: React.ComponentProps<typeof SheetPrimitive.Close>) {
  return <SheetPrimitive.Close data-slot="sheet-close" {...props} />
}

function SheetPortal({
  ...props
}: React.ComponentProps<typeof SheetPrimitive.Portal>) {
  return <SheetPrimitive.Portal data-slot="sheet-portal" {...props} />
}

function SheetOverlay({
  className,
  ...props
}: React.ComponentProps<typeof SheetPrimitive.Overlay>) {
  return (
    <SheetPrimitive.Overlay
      data-slot="sheet-overlay"
      className={cn(
        "fixed inset-0 z-50 bg-black/10 duration-100 supports-backdrop-filter:backdrop-blur-xs data-open:animate-in data-open:fade-in-0 data-closed:animate-out data-closed:fade-out-0",
        className
      )}
      {...props}
    />
  )
}

function SheetContent({
  className,
  children,
  side = "right",
  size = "lg",
  showCloseButton = true,
  ...props
}: React.ComponentProps<typeof SheetPrimitive.Content> & {
  /** Edge of the screen the sheet slides in from. */
  side?: SheetSide
  /**
   * Width of a sheet that comes in from the left or right: `sm` 24rem, `md` 32rem, `lg` 42.5rem (the default),
   * `xl` 56rem, `full` the whole viewport. Always the full width on a phone. Ignored for `top` and `bottom`.
   */
  size?: SheetSize
  /** Shows the close button. Turn it off only when something else in the sheet closes it. */
  showCloseButton?: boolean
}) {
  const panel = side === "left" || side === "right"

  return (
    <SheetPortal>
      <SheetOverlay />
      <SheetPrimitive.Content
        data-slot="sheet-content"
        data-side={side}
        data-size={panel ? size : undefined}
        className={cn(
          // The spacing every part reads: one variable, so a panel is roomy and a top or bottom sheet is compact.
          panel
            ? "[--sheet-spacing:calc(var(--spacing)*8)] h-full w-full gap-0"
            : "[--sheet-spacing:calc(var(--spacing)*4)] gap-4",
          panel && SIZES[size],
          "fixed z-50 flex flex-col bg-popover bg-clip-padding text-sm text-popover-foreground transition duration-200 ease-in-out data-[side=bottom]:inset-x-0 data-[side=bottom]:bottom-0 data-[side=bottom]:h-auto data-[side=bottom]:border-t data-[side=left]:inset-y-0 data-[side=left]:left-0 data-[side=left]:border-r data-[side=right]:inset-y-0 data-[side=right]:right-0 data-[side=right]:border-l data-[side=top]:inset-x-0 data-[side=top]:top-0 data-[side=top]:h-auto data-[side=top]:border-b data-open:animate-in data-open:fade-in-0 data-[side=bottom]:data-open:slide-in-from-bottom-10 data-[side=left]:data-open:slide-in-from-left-10 data-[side=right]:data-open:slide-in-from-right-10 data-[side=top]:data-open:slide-in-from-top-10 data-closed:animate-out data-closed:fade-out-0 data-[side=bottom]:data-closed:slide-out-to-bottom-10 data-[side=left]:data-closed:slide-out-to-left-10 data-[side=right]:data-closed:slide-out-to-right-10 data-[side=top]:data-closed:slide-out-to-top-10",
          className
        )}
        {...props}
      >
        <SheetContext.Provider value={{ panel }}>
          {children}
        </SheetContext.Provider>
        {/* A direct child of the content, so an app can hide it with `[&>button]:hidden`. */}
        {showCloseButton && (
          <SheetPrimitive.Close data-slot="sheet-close" asChild>
            <Button
              variant="ghost"
              className={cn("absolute", panel ? "top-6 right-6" : "top-3 right-3")}
              size="icon-sm"
            >
              <HugeiconsIcon icon={Cancel01Icon} strokeWidth={2} />
              <span className="sr-only">Close</span>
            </Button>
          </SheetPrimitive.Close>
        )}
      </SheetPrimitive.Content>
    </SheetPortal>
  )
}

/**
 * The title block. In a panel it is a tinted band with a hairline under it, roomy, with space on the right for
 * the close button. In a top or bottom sheet it is plain.
 */
function SheetHeader({ className, ...props }: React.ComponentProps<"div">) {
  const { panel } = React.useContext(SheetContext)
  return (
    <div
      data-slot="sheet-header"
      className={cn(
        "flex shrink-0 flex-col px-(--sheet-spacing)",
        panel
          ? "gap-1 border-b border-border bg-muted/50 py-6 pr-16"
          : "gap-0.5 py-4",
        className
      )}
      {...props}
    />
  )
}

/**
 * The region between header and footer. It is the one part that scrolls, so a long form never pushes the footer
 * off the screen. Put the fields in it, not the actions.
 */
function SheetBody({ className, ...props }: React.ComponentProps<"div">) {
  const { panel } = React.useContext(SheetContext)
  return (
    <div
      data-slot="sheet-body"
      className={cn(
        "flex min-h-0 flex-1 flex-col gap-4 overflow-y-auto px-(--sheet-spacing)",
        panel ? "py-8" : "py-4",
        className
      )}
      {...props}
    />
  )
}

/**
 * The actions. In a panel it is fixed to the bottom, on the same surface as the sheet, under a dashed hairline,
 * with the primary action first. In a top or bottom sheet it stacks.
 */
function SheetFooter({
  className,
  align = "start",
  ...props
}: React.ComponentProps<"div"> & {
  /** Where the actions sit in a panel's footer. The primary action goes first when `start`, last when `end`. */
  align?: SheetFooterAlign
}) {
  const { panel } = React.useContext(SheetContext)
  return (
    <div
      data-slot="sheet-footer"
      data-align={panel ? align : undefined}
      className={cn(
        "mt-auto flex shrink-0 px-(--sheet-spacing)",
        panel
          ? cn(
              "flex-row flex-wrap items-center gap-4 border-t border-dashed border-border bg-popover py-6",
              ALIGN[align]
            )
          : "flex-col gap-2 py-4",
        className
      )}
      {...props}
    />
  )
}

function SheetTitle({
  className,
  ...props
}: React.ComponentProps<typeof SheetPrimitive.Title>) {
  const { panel } = React.useContext(SheetContext)
  return (
    <SheetPrimitive.Title
      data-slot="sheet-title"
      className={cn(
        "font-heading font-medium text-foreground",
        panel ? "text-xl" : "text-base",
        className
      )}
      {...props}
    />
  )
}

function SheetDescription({
  className,
  ...props
}: React.ComponentProps<typeof SheetPrimitive.Description>) {
  return (
    <SheetPrimitive.Description
      data-slot="sheet-description"
      className={cn("text-sm text-muted-foreground", className)}
      {...props}
    />
  )
}

export {
  Sheet,
  SheetTrigger,
  SheetClose,
  SheetContent,
  SheetHeader,
  SheetBody,
  SheetFooter,
  SheetTitle,
  SheetDescription,
}
