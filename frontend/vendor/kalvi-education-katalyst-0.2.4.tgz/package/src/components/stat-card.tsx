"use client"

import * as React from "react"
import { HugeiconsIcon, type IconSvgElement } from "@hugeicons/react"
import {
  ArrowDownRight01Icon,
  ArrowRight01Icon,
  ArrowUpRight01Icon,
} from "@hugeicons/core-free-icons"
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  Cell,
  Line,
  LineChart,
  PolarAngleAxis,
  RadialBar,
  RadialBarChart,
  YAxis,
} from "recharts"

import { cn } from "@kalvi-education/katalyst/lib/utils"
import {
  Card,
  CardAction,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@kalvi-education/katalyst/components/card"
import { ChartContainer, type ChartConfig } from "@kalvi-education/katalyst/components/chart"
import { Skeleton } from "@kalvi-education/katalyst/components/skeleton"

type StatCardTrend = {
  /** The change as it should read: "12%", "+38", "2 days". */
  value: string
  direction: "up" | "down" | "flat"
  /** Which direction is good news. Defaults to "up"; use "down" for dropouts, late submissions, wait times. */
  good?: "up" | "down"
  /** What the change is against, for screen readers and the tooltip: "vs last week". */
  label?: string
}

type StatCardChart = {
  /** `area` and `line` for a trend over time, `bar` for discrete periods (days, weeks). */
  type: "area" | "line" | "bar"
  /** The series, oldest first. The last point is the current period and is drawn in the accent. */
  data: number[]
}

type StatCardProgress = {
  value: number
  /** Defaults to 100. */
  max?: number
  /** Read out with the ring: "of 95% target". */
  label?: string
}

type StatCardProps = Omit<React.ComponentProps<typeof Card>, "title"> & {
  /** What is measured: "Active learners". */
  title: string
  /** The figure. Pass a formatted string or node; numbers are formatted with the viewer's locale. */
  value: React.ReactNode
  /** One line of context under the figure: a period, a comparison, a source. */
  description?: React.ReactNode
  /** An icon that hints at the metric. It is decorative. Hidden when `progress` takes its place. */
  icon?: IconSvgElement
  /** A change chip after the figure, coloured by whether the movement is good. */
  trend?: StatCardTrend
  /** A small chart along the bottom of the card. */
  chart?: StatCardChart
  /** A ring beside the figure for a metric with a target. */
  progress?: StatCardProgress
  /** Show a placeholder in place of the figure while it loads. */
  loading?: boolean
}

const sparkConfig = {
  value: { label: "Value", color: "var(--chart-1)" },
} satisfies ChartConfig

function StatCardTrendChip({ value, direction, good = "up", label }: StatCardTrend) {
  const tone = direction === "flat" ? "flat" : direction === good ? "good" : "bad"
  const icon =
    direction === "up" ? ArrowUpRight01Icon : direction === "down" ? ArrowDownRight01Icon : ArrowRight01Icon
  const spoken = direction === "flat" ? `No change, ${value}` : `${direction === "up" ? "Up" : "Down"} ${value}`

  return (
    <span
      data-slot="stat-card-trend"
      data-tone={tone}
      title={label}
      className="inline-flex h-5 items-center gap-0.5 rounded-full px-1.5 text-xs font-medium text-foreground data-[tone=bad]:bg-red-soft data-[tone=flat]:bg-muted data-[tone=good]:bg-green-soft"
    >
      <HugeiconsIcon
        icon={icon}
        strokeWidth={2.5}
        aria-hidden
        className={cn(
          "size-3.5",
          tone === "good" && "text-green-bold dark:text-green-main",
          tone === "bad" && "text-red-bold dark:text-red-main",
          tone === "flat" && "text-muted-foreground"
        )}
      />
      <span aria-hidden>{value}</span>
      <span className="sr-only">
        {spoken}
        {label ? ` ${label}` : ""}
      </span>
    </span>
  )
}

function StatCardSparkline({ type, data }: StatCardChart) {
  const rows = data.map((value, index) => ({ index, value }))
  const last = rows.length - 1
  const gradientId = React.useId().replace(/:/g, "")

  return (
    <ChartContainer
      config={sparkConfig}
      aria-hidden
      className="aspect-auto h-10 w-full [&_.recharts-surface]:overflow-visible"
      initialDimension={{ width: 240, height: 40 }}
    >
      {type === "bar" ? (
        <BarChart data={rows} margin={{ top: 2, right: 0, bottom: 0, left: 0 }} barCategoryGap={2}>
          <Bar dataKey="value" radius={[3, 3, 0, 0]} maxBarSize={12} isAnimationActive={false}>
            {rows.map((row) => (
              <Cell
                key={row.index}
                fill={row.index === last ? "var(--color-value)" : "var(--muted-foreground)"}
                fillOpacity={row.index === last ? 1 : 0.25}
              />
            ))}
          </Bar>
        </BarChart>
      ) : type === "area" ? (
        <AreaChart data={rows} margin={{ top: 4, right: 4, bottom: 0, left: 4 }}>
          <defs>
            <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="var(--color-value)" stopOpacity={0.2} />
              <stop offset="100%" stopColor="var(--color-value)" stopOpacity={0} />
            </linearGradient>
          </defs>
          <YAxis hide domain={["dataMin", "dataMax"]} />
          <Area
            dataKey="value"
            type="monotone"
            stroke="var(--color-value)"
            strokeWidth={2}
            fill={`url(#${gradientId})`}
            dot={false}
            activeDot={false}
            isAnimationActive={false}
          />
        </AreaChart>
      ) : (
        <LineChart data={rows} margin={{ top: 4, right: 4, bottom: 4, left: 4 }}>
          <YAxis hide domain={["dataMin", "dataMax"]} />
          <Line
            dataKey="value"
            type="monotone"
            stroke="var(--color-value)"
            strokeWidth={2}
            isAnimationActive={false}
            dot={(props: { cx?: number; cy?: number; index?: number }) =>
              props.index === last ? (
                <circle
                  key="last"
                  cx={props.cx}
                  cy={props.cy}
                  r={4}
                  fill="var(--color-value)"
                  stroke="var(--card)"
                  strokeWidth={2}
                />
              ) : (
                <g key={props.index} />
              )
            }
          />
        </LineChart>
      )}
    </ChartContainer>
  )
}

function StatCardRing({ value, max = 100, label, title }: StatCardProgress & { title: string }) {
  const share = max > 0 ? Math.min(1, Math.max(0, value / max)) : 0

  return (
    <div
      data-slot="stat-card-progress"
      role="img"
      aria-label={`${title}: ${Math.round(share * 100)}%${label ? ` ${label}` : ""}`}
      className="relative size-12 shrink-0"
    >
      <ChartContainer
        config={sparkConfig}
        className="aspect-square size-12"
        initialDimension={{ width: 48, height: 48 }}
      >
        <RadialBarChart
          data={[{ value: share * 100 }]}
          startAngle={90}
          endAngle={-270}
          innerRadius="78%"
          outerRadius="100%"
          barSize={5}
        >
          <PolarAngleAxis type="number" domain={[0, 100]} tick={false} axisLine={false} />
          <RadialBar
            dataKey="value"
            fill="var(--color-value)"
            background
            cornerRadius={4}
            isAnimationActive={false}
          />
        </RadialBarChart>
      </ChartContainer>
      <span
        aria-hidden
        className="absolute inset-0 flex items-center justify-center text-[11px] font-medium"
      >
        {Math.round(share * 100)}%
      </span>
    </div>
  )
}

function StatCard({
  title,
  value,
  description,
  icon,
  trend,
  chart,
  progress,
  loading = false,
  size = "sm",
  className,
  ...props
}: StatCardProps) {
  return (
    <Card data-slot="stat-card" size={size} className={className} {...props}>
      <CardHeader>
        <CardTitle className="text-sm font-medium text-muted-foreground">{title}</CardTitle>
        {icon && !progress && (
          <CardAction>
            <HugeiconsIcon icon={icon} strokeWidth={2} className="size-4 text-muted-foreground" aria-hidden />
          </CardAction>
        )}
      </CardHeader>
      <CardContent className="flex flex-col gap-3">
        <div className="flex items-end justify-between gap-3">
          <div className="flex min-w-0 flex-col gap-1">
            {loading ? (
              <Skeleton className="h-8 w-24" aria-label={`${title} is loading`} />
            ) : (
              <div className="flex flex-wrap items-center gap-2">
                <p className="text-2xl font-semibold">
                  {typeof value === "number" ? new Intl.NumberFormat().format(value) : value}
                </p>
                {trend && <StatCardTrendChip {...trend} />}
              </div>
            )}
            {description && <CardDescription className="text-xs">{description}</CardDescription>}
          </div>
          {progress &&
            (loading ? (
              <Skeleton className="size-12 rounded-full" />
            ) : (
              <StatCardRing {...progress} title={title} />
            ))}
        </div>
        {chart &&
          chart.data.length > 1 &&
          (loading ? <Skeleton className="h-10 w-full" /> : <StatCardSparkline {...chart} />)}
      </CardContent>
    </Card>
  )
}

export { StatCard }
export type { StatCardChart, StatCardProgress, StatCardProps, StatCardTrend }
