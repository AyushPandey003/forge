"use client"

import * as React from "react"
import { Dialog as DialogPrimitive } from "radix-ui"
import { HugeiconsIcon } from "@hugeicons/react"
import { Cancel01Icon } from "@hugeicons/core-free-icons"

import { cn } from "@kalvi-education/katalyst/lib/utils"
import { Button } from "@kalvi-education/katalyst/components/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@kalvi-education/katalyst/components/dialog"

type FullscreenModalProps = Omit<React.ComponentProps<typeof DialogContent>, "title" | "showCloseButton"> & {
  open: boolean
  onOpenChange: (open: boolean) => void
  /** Names the dialog for assistive technology. Always required, even when `hideTitle` keeps it off screen. */
  title: string
  /** One line of context for assistive technology. */
  description?: string
  /** Keep the title off screen when the content shows its own heading. */
  hideTitle?: boolean
  /** Content pinned above the scrolling area, such as a timer or a progress bar. */
  topSlot?: React.ReactNode
  /**
   * Block every way out except the page's own controls: the close button, Escape and a click outside.
   * Use for a timed or proctored task, and give people an explicit way to finish.
   */
  locked?: boolean
}

function FullscreenModal({
  open,
  onOpenChange,
  title,
  description,
  hideTitle = false,
  topSlot,
  locked = false,
  className,
  children,
  ...props
}: FullscreenModalProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        data-slot="fullscreen-modal"
        showCloseButton={false}
        onEscapeKeyDown={locked ? (event) => event.preventDefault() : undefined}
        onPointerDownOutside={locked ? (event) => event.preventDefault() : undefined}
        onInteractOutside={locked ? (event) => event.preventDefault() : undefined}
        className={cn(
          "top-0 left-0 flex h-dvh w-screen max-w-none translate-x-0 translate-y-0 flex-col gap-0 rounded-none bg-background p-0 text-foreground ring-0 sm:max-w-none",
          className
        )}
        {...props}
      >
        <DialogTitle className={hideTitle ? "sr-only" : "px-4 pt-4 pr-14 text-base font-medium"}>{title}</DialogTitle>
        <DialogDescription className="sr-only">{description ?? title}</DialogDescription>
        {topSlot}
        {!locked && (
          <DialogPrimitive.Close asChild>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="absolute top-3 right-3 z-10"
              aria-label="Close"
            >
              <HugeiconsIcon icon={Cancel01Icon} strokeWidth={2} />
            </Button>
          </DialogPrimitive.Close>
        )}
        <div data-slot="fullscreen-modal-body" className="min-h-0 flex-1 overflow-auto">
          {children}
        </div>
      </DialogContent>
    </Dialog>
  )
}

export { FullscreenModal }
export type { FullscreenModalProps }
