"use client"

import * as React from "react"
import { HugeiconsIcon } from "@hugeicons/react"
import {
  AlertCircleIcon,
  CheckmarkCircle02Icon,
  Download04Icon,
} from "@hugeicons/core-free-icons"

import { cn } from "@kalvi-education/katalyst/lib/utils"
import {
  saveCsv,
  parseCsv,
  sampleCsv,
  validateCsv,
  type CsvColumn,
  type CsvRow,
  type CsvRowValidator,
  type CsvValidation,
} from "@kalvi-education/katalyst/lib/csv"
import { Alert, AlertDescription, AlertTitle } from "@kalvi-education/katalyst/components/alert"
import { Badge } from "@kalvi-education/katalyst/components/badge"
import { Button } from "@kalvi-education/katalyst/components/button"
import {
  FileUpload,
  type FileUploadItem,
} from "@kalvi-education/katalyst/components/file-upload"
import { Spinner } from "@kalvi-education/katalyst/components/spinner"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@kalvi-education/katalyst/components/table"

type CsvUploadProps = Omit<React.ComponentProps<"div">, "onError"> & {
  /** The columns the file must have. */
  columns: CsvColumn[]
  /** Extra checks run on every row once the headers are right. Return a message to reject the row. */
  rules?: CsvRowValidator[]
  /** Called with the parsed rows when the person confirms. Throw or reject to show a failure. */
  onImport: (rows: CsvRow[]) => void | Promise<void>
  /** File name for the downloadable template, without extension. */
  templateName?: string
  /** What is being imported, plural, for the button and messages ("learners"). */
  noun?: string
  /** The singular of `noun` ("learner"), used when there is exactly one row. Defaults to `noun`. */
  nounSingular?: string
  /** Largest file in bytes. Defaults to 5 MB. */
  maxSize?: number
  /** Rows shown in the preview. Defaults to 5. */
  previewRows?: number
}

type Parsed = { rows: CsvRow[]; validation: CsvValidation }

const MAX_LISTED_ERRORS = 10

function CsvUpload({
  columns,
  rules,
  onImport,
  templateName = "template",
  noun = "rows",
  nounSingular,
  maxSize = 5 * 1024 * 1024,
  previewRows = 5,
  className,
  ...props
}: CsvUploadProps) {
  const [item, setItem] = React.useState<FileUploadItem | null>(null)
  const [parsed, setParsed] = React.useState<Parsed | null>(null)
  const [parseError, setParseError] = React.useState<string | null>(null)
  const [state, setState] = React.useState<"idle" | "importing" | "done" | "failed">("idle")
  const [failure, setFailure] = React.useState<string | null>(null)

  const required = columns.filter((c) => c.required)

  const reset = () => {
    setItem(null)
    setParsed(null)
    setParseError(null)
    setState("idle")
    setFailure(null)
  }

  const onFilesAdded = async (files: File[]) => {
    const file = files[0]
    if (!file) return
    reset()
    setItem({ id: file.name, name: file.name, size: file.size, status: "idle" })
    try {
      const rows = parseCsv(await file.text())
      const validation = validateCsv(rows, columns, rules)
      setParsed({ rows, validation })
      if (!validation.valid) {
        setItem({ id: file.name, name: file.name, size: file.size, status: "error", error: "Needs changes" })
      }
    } catch (error) {
      setParseError(error instanceof Error ? error.message : "The file could not be read.")
      setItem({ id: file.name, name: file.name, size: file.size, status: "error", error: "Could not be read" })
    }
  }

  const runImport = async () => {
    if (!parsed) return
    setState("importing")
    setFailure(null)
    try {
      await onImport(parsed.rows)
      setState("done")
      setItem((current) => (current ? { ...current, status: "complete" } : current))
    } catch (error) {
      setState("failed")
      setFailure(error instanceof Error ? error.message : "The import did not finish.")
    }
  }

  const counted = (n: number) => `${n} ${n === 1 ? (nounSingular ?? noun) : noun}`
  const preview = parsed?.rows.slice(0, previewRows) ?? []
  const headers = parsed?.rows[0] ? Object.keys(parsed.rows[0]) : []
  const validation = parsed?.validation

  return (
    <div data-slot="csv-upload" className={cn("flex flex-col gap-4", className)} {...props}>
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="text-sm text-muted-foreground">
          {required.length} of {columns.length} columns are required:{" "}
          <span className="text-foreground">{required.map((c) => c.name).join(", ")}</span>
        </p>
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={() => saveCsv(`${templateName}.csv`, sampleCsv(columns))}
        >
          <HugeiconsIcon icon={Download04Icon} strokeWidth={2} data-icon="inline-start" />
          Download template
        </Button>
      </div>

      <FileUpload
        files={item ? [item] : []}
        onFilesAdded={onFilesAdded}
        onRemove={reset}
        accept={[".csv"]}
        maxSize={maxSize}
        maxFiles={1}
        multiple={false}
        title="Drop a CSV file here, or choose it"
        disabled={state === "importing"}
      />

      {parseError && (
        <Alert variant="destructive">
          <HugeiconsIcon icon={AlertCircleIcon} strokeWidth={2} />
          <AlertTitle>The file could not be read</AlertTitle>
          <AlertDescription>{parseError} Check that it is a CSV file and try again.</AlertDescription>
        </Alert>
      )}

      {validation && !validation.valid && (
        <Alert variant="destructive">
          <HugeiconsIcon icon={AlertCircleIcon} strokeWidth={2} />
          <AlertTitle>{validation.error ?? "Fix these problems and upload the file again"}</AlertTitle>
          <AlertDescription>
            {validation.missingColumns.length > 0 && (
              <p>Missing columns: {validation.missingColumns.join(", ")}.</p>
            )}
            {validation.rowErrors.length > 0 && (
              <ul className="mt-1 list-disc pl-4">
                {validation.rowErrors.slice(0, MAX_LISTED_ERRORS).map((message) => (
                  <li key={message}>{message}</li>
                ))}
                {validation.rowErrors.length > MAX_LISTED_ERRORS && (
                  <li>and {validation.rowErrors.length - MAX_LISTED_ERRORS} more</li>
                )}
              </ul>
            )}
          </AlertDescription>
        </Alert>
      )}

      {validation?.valid && parsed && (
        <div className="flex flex-col gap-3">
          <div className="flex flex-wrap items-center gap-2 text-sm">
            <HugeiconsIcon
              icon={CheckmarkCircle02Icon}
              strokeWidth={2}
              className="size-4 text-green-bold"
              aria-hidden
            />
            <span>
              {counted(parsed.rows.length)} ready to import
            </span>
            {validation.extraColumns.length > 0 && (
              <Badge variant="outline">
                {validation.extraColumns.length} extra {validation.extraColumns.length === 1 ? "column" : "columns"} kept
              </Badge>
            )}
          </div>

          <div className="overflow-hidden rounded-lg border border-border">
            <Table>
              <TableHeader>
                <TableRow>
                  {headers.map((header) => (
                    <TableHead key={header}>{header}</TableHead>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody>
                {preview.map((row, index) => (
                  <TableRow key={index}>
                    {headers.map((header) => (
                      <TableCell key={header} className="max-w-48 truncate">
                        {row[header]}
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          {parsed.rows.length > preview.length && (
            <p className="text-xs text-muted-foreground">
              Showing the first {preview.length} of {counted(parsed.rows.length)}.
            </p>
          )}

          {state === "failed" && failure && (
            <Alert variant="destructive">
              <HugeiconsIcon icon={AlertCircleIcon} strokeWidth={2} />
              <AlertTitle>The import did not finish</AlertTitle>
              <AlertDescription>{failure} Try again, or contact support if it keeps failing.</AlertDescription>
            </Alert>
          )}
          {state === "done" ? (
            <Alert>
              <HugeiconsIcon icon={CheckmarkCircle02Icon} strokeWidth={2} />
              <AlertTitle>Imported {counted(parsed.rows.length)}</AlertTitle>
            </Alert>
          ) : (
            <div className="flex justify-end">
              <Button type="button" onClick={runImport} disabled={state === "importing"}>
                {state === "importing" ? (
                  <>
                    <Spinner data-icon="inline-start" />
                    Importing…
                  </>
                ) : (
                  `Import ${counted(parsed.rows.length)}`
                )}
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

export { CsvUpload }
export type { CsvUploadProps }
