"use client"

import * as React from "react"
import { HugeiconsIcon } from "@hugeicons/react"
import { Calendar03Icon, Clock01Icon } from "@hugeicons/core-free-icons"
import type { Matcher } from "react-day-picker"

import { cn } from "@kalvi-education/katalyst/lib/utils"
import { Button } from "@kalvi-education/katalyst/components/button"
import { Calendar } from "@kalvi-education/katalyst/components/calendar"
import { Input } from "@kalvi-education/katalyst/components/input"
import { Label } from "@kalvi-education/katalyst/components/label"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@kalvi-education/katalyst/components/popover"

type DateTimePickerProps = Omit<
  React.ComponentProps<typeof Button>,
  "value" | "defaultValue" | "onChange" | "children"
> & {
  /** The selected moment (controlled). */
  value?: Date
  /** Initial moment when uncontrolled. */
  defaultValue?: Date
  /** Called with the new Date, or `undefined` when the value is cleared. */
  onValueChange?: (value: Date | undefined) => void
  /** Show the time field. Turn off for a plain date picker. */
  showTime?: boolean
  /** Include seconds in the time field. */
  showSeconds?: boolean
  /** Time given to a day that is picked before any time was chosen. Defaults to 09:00. */
  defaultTime?: string
  placeholder?: string
  /** What the date is for ("Deadline"). Read out with the chosen value, so the button never loses its value to a bare label. */
  label?: string
  /** Dates that cannot be picked: a Date, a range, or a function. */
  disabledDates?: Matcher | Matcher[]
  fromDate?: Date
  toDate?: Date
  /** BCP 47 tag for the button text. Defaults to the viewer's locale. */
  locale?: string
}

/** "HH:mm" or "HH:mm:ss" for a Date, in local time. */
function toTimeString(date: Date, seconds: boolean) {
  const pad = (n: number) => String(n).padStart(2, "0")
  const base = `${pad(date.getHours())}:${pad(date.getMinutes())}`
  return seconds ? `${base}:${pad(date.getSeconds())}` : base
}

function withTime(day: Date, time: string) {
  const [h = "0", m = "0", s = "0"] = time.split(":")
  const next = new Date(day)
  next.setHours(Number(h), Number(m), Number(s), 0)
  return next
}

function DateTimePicker({
  value: valueProp,
  defaultValue,
  onValueChange,
  showTime = true,
  showSeconds = false,
  defaultTime = "09:00",
  placeholder,
  label: contextLabel,
  disabledDates,
  fromDate,
  toDate,
  locale,
  className,
  disabled,
  ...props
}: DateTimePickerProps) {
  const [internal, setInternal] = React.useState<Date | undefined>(defaultValue)
  const [open, setOpen] = React.useState(false)
  const timeId = React.useId()
  const value = valueProp !== undefined ? valueProp : internal

  const commit = (next: Date | undefined) => {
    if (valueProp === undefined) setInternal(next)
    onValueChange?.(next)
  }

  const label = React.useMemo(() => {
    if (!value) return null
    return new Intl.DateTimeFormat(locale, {
      dateStyle: "medium",
      ...(showTime ? { timeStyle: showSeconds ? "medium" : "short" } : {}),
    }).format(value)
  }, [value, locale, showTime, showSeconds])

  const matchers: Matcher[] = [
    ...(disabledDates ? ([] as Matcher[]).concat(disabledDates) : []),
    ...(fromDate ? [{ before: fromDate }] : []),
    ...(toDate ? [{ after: toDate }] : []),
  ]

  const fallback = placeholder ?? (showTime ? "Pick a date and time" : "Pick a date")

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          type="button"
          variant="outline"
          data-slot="date-time-picker"
          data-empty={!label || undefined}
          aria-label={contextLabel ? `${contextLabel}, ${label ?? "none chosen"}` : undefined}
          disabled={disabled}
          className={cn(
            "w-64 justify-start text-left font-normal data-empty:text-muted-foreground",
            className
          )}
          {...props}
        >
          <HugeiconsIcon icon={Calendar03Icon} strokeWidth={2} data-icon="inline-start" />
          <span className="truncate tabular-nums">{label ?? fallback}</span>
        </Button>
      </PopoverTrigger>
      <PopoverContent align="start" className="w-auto gap-0 p-0">
        <Calendar
          mode="single"
          defaultMonth={value}
          selected={value}
          onSelect={(day) => {
            if (!day) return commit(undefined)
            const time = value ? toTimeString(value, showSeconds) : defaultTime
            commit(showTime ? withTime(day, time) : withTime(day, "00:00"))
            if (!showTime) setOpen(false)
          }}
          disabled={matchers.length ? matchers : undefined}
        />
        {showTime && (
          <div className="flex items-center gap-2 border-t border-border p-3">
            <Label htmlFor={timeId} className="gap-1.5 text-muted-foreground">
              <HugeiconsIcon icon={Clock01Icon} strokeWidth={2} className="size-4" />
              Time
            </Label>
            <Input
              id={timeId}
              type="time"
              step={showSeconds ? 1 : 60}
              disabled={!value}
              value={value ? toTimeString(value, showSeconds) : ""}
              onChange={(event) => {
                if (value && event.target.value) {
                  commit(withTime(value, event.target.value))
                }
              }}
              className="h-8 w-auto flex-1 tabular-nums"
            />
          </div>
        )}
      </PopoverContent>
    </Popover>
  )
}

export { DateTimePicker }
export type { DateTimePickerProps }
