import * as React from "react"

import { cn } from "@kalvi-education/katalyst/lib/utils"

/**
 * The Kalvium mark, drawn to a 32×32 box. Used where the wordmark will not fit —
 * a collapsed sidebar rail, a favicon-sized slot, an avatar position.
 */
const MARK_PATH =
  "M3.25.61v30.78h25.5V.61zm3.303 27.54v-10.5l18.894 10.5zm18.894-3.835L9.93 15.969l15.517-8.238zM6.553 14.35V3.907h18.894z"

/** The mark plus the Kalvium wordmark, drawn to a 151×32 box. */
const WORDMARK_PATH =
  "M0 0v31.986h26.453V0zm3.427 28.618V17.71l19.6 10.91zm19.6-3.984L6.93 15.96 23.027 7.4zM3.427 14.28V3.427h19.6zm45.221 14.338L42.1 18.194l-3.007 3.416v7.006h-5.378V3.8h5.378v11.05l9.22-11.05h6.248l-8.953 10.249 9.287 14.57zm6.45-5.089c0-2.789 1.537-5.055 5.946-5.438l3.674-.314c1.437-.139 1.837-.592 1.837-1.36 0-1.533-.902-2.404-2.638-2.404-1.737 0-2.639.801-2.807 2.405h-5.077c0-3.73 2.272-6.136 7.817-6.136 5.546 0 7.818 2.406 7.818 6.136v7.599c0 2.44.2 4.008.534 4.6H67.56c-.468-.626-.736-1.324-.736-2.51-.968 1.883-2.572 2.86-5.445 2.86-4.109 0-6.28-2.127-6.28-5.44zm11.458-2.162v-1.01c-.233.278-.902.453-1.837.557l-1.87.14c-1.905.174-2.64.976-2.64 2.09 0 1.36.803 2.267 2.673 2.267 2.339 0 3.675-1.848 3.675-4.044m7.646 7.251V3.799h5.111v24.819zm12.497 0L80.52 10.63h5.312l3.975 13.385 3.975-13.385h5.312l-6.18 17.987zM99.96 5.681c0-1.533 1.036-2.683 2.874-2.683s2.906 1.15 2.906 2.683c0 1.534-1.035 2.684-2.906 2.684s-2.873-1.15-2.873-2.684m.335 22.937V10.63h5.111v17.987zm7.649-6.1V10.63h5.112v10.841c0 2.091.735 3.207 2.471 3.207 1.938 0 3.207-1.429 3.207-4.009V10.63h5.112v17.987h-4.844v-2.719c-.902 1.743-2.372 3.068-5.112 3.068-3.942 0-5.946-2.091-5.946-6.448m38.013 6.1v-10.98c0-2.128-.701-3.069-2.071-3.069-1.537 0-2.84 1.29-2.84 3.835v10.213h-4.877v-10.98c0-2.127-.735-3.068-2.071-3.068-1.57 0-2.839 1.29-2.839 3.834v10.213h-4.877V10.63h4.844v2.72c.868-1.744 2.204-3.069 4.543-3.069 2.472 0 4.075 1.011 4.844 3.137.868-1.847 2.506-3.137 4.844-3.137 3.575 0 5.412 2.092 5.412 6.449v11.886h-4.912"

const LOGO_GEOMETRY = {
  mark: { viewBox: "0 0 32 32", path: MARK_PATH },
  wordmark: { viewBox: "0 0 151 32", path: WORDMARK_PATH },
} as const

/**
 * The Kalvium logo.
 *
 * Drawn inline rather than shipped as a file: Katalyst publishes `dist` only and has
 * no asset pipeline, and an inline path recolours, scales and tree-shakes without one.
 *
 * The brand red is `--color-kalvium-red`, which is what the token is for. It is
 * deliberately the same value in light and dark — a brand colour does not invert.
 * The paths use `currentColor`, so `className="text-foreground"` gives you the
 * monochrome lockup for a print or single-colour context.
 *
 * Height drives the size; width follows the aspect ratio. Override with `className`.
 */
function KalviumLogo({
  variant = "wordmark",
  label = "Kalvium",
  className,
  ...props
}: Omit<React.ComponentProps<"svg">, "viewBox" | "children"> & {
  /** `mark` is the 1:1 glyph; `wordmark` is the glyph plus the Kalvium lettering. */
  variant?: "mark" | "wordmark"
  /**
   * Accessible name. Pass `null` when the logo sits beside the word "Kalvium" or
   * inside an already-labelled control — a decorative logo should not be announced.
   */
  label?: string | null
}) {
  const { viewBox, path } = LOGO_GEOMETRY[variant]

  return (
    <svg
      data-slot="kalvium-logo"
      data-variant={variant}
      viewBox={viewBox}
      fill="currentColor"
      xmlns="http://www.w3.org/2000/svg"
      role={label ? "img" : undefined}
      aria-label={label ?? undefined}
      aria-hidden={label ? undefined : true}
      focusable="false"
      className={cn("h-8 w-auto shrink-0 text-kalvium-red", className)}
      {...props}
    >
      <path d={path} />
    </svg>
  )
}

/**
 * Shorthand for `<KalviumLogo variant="mark" />`. The glyph alone, on a 1:1 box —
 * what a collapsed rail, a square slot or a compact header wants.
 */
function KalviumMark(props: Omit<React.ComponentProps<typeof KalviumLogo>, "variant">) {
  return <KalviumLogo variant="mark" {...props} />
}

export { KalviumLogo, KalviumMark }
