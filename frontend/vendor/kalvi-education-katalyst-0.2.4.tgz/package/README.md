# Katalyst

Kalvium's design system for React apps. One package gives you:

- **Components**, from buttons and form fields to `DataTable`, `FileUpload`, `Sheet`, charts and the
  `AppShell` page layout. Each one has a contract in `contracts/` describing its props and usage.
- **The theme**: colour, type, spacing and radius tokens for light and dark mode, matched to the
  Katalyst Figma file.
- **Guides for AI agents** so Claude, Cursor or Copilot build screens the Katalyst way (see
  [Agent guidance](#agent-guidance)).

Built on shadcn/ui (`radix-nova` style, Figtree, Hugeicons) and published to GitHub Packages for
Kalvi-Education repos. Changes are listed in [CHANGELOG.md](https://github.com/Kalvi-Education/katalyst/blob/main/packages/katalyst/CHANGELOG.md).

## Install

The `@kalvi-education` scope is **already routed** in every nucleus-apps `.npmrc`
and CI workflow, so most consumers need no registry setup at all:

```bash
yarn add @kalvi-education/katalyst
```

In a repo that doesn't yet consume any `@kalvi-education` package, add to `.npmrc`:

```
@kalvi-education:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${NODE_AUTH_TOKEN}
```

`NODE_AUTH_TOKEN` is a classic GitHub PAT with `read:packages` (`write:packages` to publish).

## Usage

Import the theme once (e.g. in your root layout / global stylesheet):

```css
/* prebuilt, self-contained theme, includes the Figtree @import */
@import "@kalvi-education/katalyst/katalyst.css";
```

```tsx
import { Button } from "@kalvi-education/katalyst/components/button";
```

For a Next.js app, transpile the package:

```ts
// next.config
transpilePackages: ["@kalvi-education/katalyst"]
```

### Choosing a theme entry point

| You write | Import | Why |
|---|---|---|
| Only Katalyst components | `@kalvi-education/katalyst/katalyst.css` | Prebuilt and self-contained. |
| Your own role or palette utilities too (`bg-muted`, `text-muted-foreground`, `bg-violet-soft`) | `@kalvi-education/katalyst/globals.css` | The source theme. It brings Tailwind, the tokens and every utility, and scans Katalyst's own source. |

The prebuilt file only holds the utilities Katalyst's components happen to use, so a class that no
component uses (the palette tints, for one) does not exist in it. If your app styles with tokens,
use `globals.css` and let your Tailwind build generate the rest:

```css
/* src/app/globals.css: this one import brings in Tailwind as well */
@import "@kalvi-education/katalyst/globals.css";
```

If you do use the prebuilt file, import it **before** Tailwind and any other rule. CSS requires
`@import` to come first, and a build that reorders it silently drops the font.

### The font in Next.js

Katalyst's family is Figtree, normally pulled in by an `@import` at the top of `katalyst.css`. Next.js's
CSS pipeline removes external `@import`s, so in a Next app load the font yourself and point Katalyst at it:

```tsx
// app/layout.tsx
import { Figtree } from "next/font/google";
const figtree = Figtree({ subsets: ["latin"], variable: "--font-figtree", display: "swap" });
// <html className={figtree.variable}>
```

```css
/* after the Katalyst import */
:root {
  --font-sans: var(--font-figtree), ui-sans-serif, system-ui, sans-serif;
}
```

### Dark mode

Dark mode is the `.dark` class on `<html>`, not the operating system setting. Set it yourself, for
example with `next-themes` (`attribute="class"`). `Toaster` reads `next-themes`, so mount it inside the
same provider.

If you prefer to compile from source rather than use the prebuilt theme, the
package also ships raw source under a `source` export condition. Scan it from
your Tailwind entry instead of importing `katalyst.css`:

```css
@source "../../node_modules/@kalvi-education/katalyst/src/**/*.{ts,tsx}";
```

## Agent guidance

The package ships guidance for AI agents so they build UI the Katalyst way: five plain
Markdown guides (design, components, product pages, review, Figma), a machine-readable component
catalog, and adapters for the common agents. They are generated on every build, with the
catalog taken from `contracts/index.json`, so they cannot drift from the library.

Install them into a project, in the layout your agent reads:

```bash
npx katalyst-skills install --agent claude      # .claude/skills/
npx katalyst-skills install --agent cursor      # .cursor/rules/
npx katalyst-skills install --agent copilot     # .github/instructions/
npx katalyst-skills install --agent agents      # a marked block in AGENTS.md
npx katalyst-skills install --agent all --dry-run
```

Or point any agent at `node_modules/@kalvi-education/katalyst/skills/AGENTS.md`. Re-run the
command after upgrading the package. It only overwrites files it generated.

To change the guidance, edit `skills-src/` (never `skills/`, which is build output) and run
`yarn build`. The build fails if a guide names a token that does not exist, contains a colour
literal in prose, or leaves a component out of the catalog groups.

## Adding components

```bash
cd packages/katalyst
npx shadcn@latest add <component>
```

`components.json` aliases resolve to `@kalvi-education/katalyst/*`, so generated
files import correctly with no hand-editing.

> **Note:** components self-import by package name (e.g.
> `@kalvi-education/katalyst/components/button`). `tsconfig.json` maps that name onto `src/`, which
> would make esbuild inline a private copy of every imported component, so `tsup.config.ts` has a plugin
> (`keepKatalystExternal`) that leaves these imports as they are. They persist into `dist/` and resolve
> at run time through this package's own `exports` map, so each component, and each React context such
> as the sidebar's, exists exactly once. `scripts/check-dist-single-instance.mjs` fails the build if a
> module is ever defined twice. If the package is ever renamed, `src/`, `package.json.name`,
> `tsconfig.json` `paths`, `components.json` and the plugin's pattern must all change together.

## Build & release

```bash
yarn build                                  # tsup -> dist + dist/katalyst.css
yarn changeset                              # record a version bump (in each PR)
yarn run version                            # apply pending changesets (repo root; not `yarn version`)
```

Publishing is done by CI when a GitHub Release tagged `v<version>` is published; see the
**Publishing** section of the root README. To publish by hand you need a classic token with
`write:packages` as `NODE_AUTH_TOKEN` and a local (gitignored) `.npmrc`, then `yarn release`
from the repo root.

### Using it from a Next.js app

Import components from their own paths, and server-usable utilities from theirs:

```tsx
import { Button } from "@kalvi-education/katalyst/components/button";
import { cn } from "@kalvi-education/katalyst/lib/utils";
```

The package root is marked `"use client"` (it re-exports hook-using components), so import
from it only in client code. Add `transpilePackages: ["@kalvi-education/katalyst"]`, and either
import `@kalvi-education/katalyst/katalyst.css` or register the shipped source with Tailwind
(`@source` on the package's `src` folder). Importing the full theme changes global variables, so
check existing screens before adopting it in an app that already has its own theme.
